# CoinStats - Crypto Portfolio Tracker

# What it does

Cryptocurrency live price and portfolio tracker.
Welcome to Coin Stats, the #1 FREE Bitcoin and cryptocurrency portfolio tracker app. Stay informed on the latest live crypto prices in real-time, view essential market data at a glance and effectively monitor your investments. Coin Stats gives you the ability to track and sync your entire cryptocurrency portfolio, all centralized in a single app.

Sophisticated enough for professional investors but simple enough to use for enthusiastic first timers, Coin Stats has everything you need to manage and grow your crypto portfolio. Measure your performance, learn about and anticipate crypto value changes and know instantly when crypto prices move, Coin Stats helps you make better decisions about your investments.

Track Bitcoin, Ethereum, Litecoin, and over 8,000 cryptocurrency prices from 350+ exchanges. Use your local currency and sync your favourite exchanges and wallets automatically to your Coin Stats portfolio so you don’t have to manually add transactions. See prices, values & changes in real-time, Coin Stats brings all the crypto related news from over 40 sources to a single screen and much more!

# What it shows

## COIN RESEARCH
Find the next great coin. Advanced filtering, sorting and research makes it easier to find your next crypto investment. Access the latest data about any cryptocurrency, such as Bitcoin, links to their website, reddit, twitter and read up to date news in order to get as much information as possible.

## TRACK EVERY COIN AND BITCOIN PRICE
Never miss a buying or selling opportunity. Easily track and follow live prices of 5,000+ cryptocurrencies in real-time and access charts & analytical data. Select the exchange you’re using, look at average prices across all exchanges and ‘favorite’ the coins you want to keep an eye on. 

## COIN INSIGHTS
See how much others hold, buy or sell Bitcoin or other cryptocurrencies using CoinStats Insights.

## YOUR PORTFOLIO
See all your portfolios on one screen. Set up your portfolio in Coin Stats by manually adding your buy/sell transactions or syncing your exchange account and wallets for a live view. Coin Stats allows you to connect it automatically, for easier transaction history entry with read-only API keys. All major exchanges are listed; Binance, Bitfinex, Bittrex, HitBTC, Coinbase, Kucoin, Bitstamp and others. 