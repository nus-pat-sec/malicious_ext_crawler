var SaveEntryDlg = (function()
{
    var this_dialog;
    
    var selectedContainerId;
    var selectedFolderId;
    var selectedContainerIsUnLocked;

    function OpenMessageBox()
    {
        if(!document.body)
            return;

        if(GetDlgOpen())
            return;
        SetDlgOpen(true);

        //add polyfill css into current page
        var polyfill_sheet = document.createElement('style');
        polyfill_sheet.innerHTML = "dialog {position: absolute;" +
            "left: 0; right: 0;" +
            "width: -moz-fit-content;" +
            "width: -webkit-fit-content;" +
            "width: fit-content;" +
            "height: -moz-fit-content;" +
            "height: -webkit-fit-content;" +
            "height: fit-content;" +
            "margin: auto;" +
            "border: solid;" +
            "padding: 1em;" +
            "background: #fafafa;" +
            "color: black;" +
            "display: block;} " +
            "dialog:not([open]) {display: none;} " +
            "dialog + .backdrop {position: fixed;" +
            "top: 0; right: 0; bottom: 0; left: 0;" +
            "background: rgba(0,0,0,0.1);} " +
            "._dialog_overlay {position: fixed;" +
            "top: 0; right: 0; bottom: 0; left: 0;} " +
            "dialog.fixed {position: fixed;top: 50%;transform: translate(0, -50%);}";

        document.body.appendChild(polyfill_sheet);

        var dialog = document.createElement("dialog");
        dialog.id = "enpast_entry_dlg";
        SetStyle(dialog, {
            'font-family':'sans-serif',
            'font-size':'medium',
            'padding':'0px',
            'background':'#fafafa',
            'border':'2px solid rgb(150, 150, 150)',
            'height':'auto',
            'text-align': 'left'
        });

        //add title bar main icon
        var title_bar = document.createElement('div');
        SetStyle(title_bar, {
            'background':'#292929',
            'height':'45px',
            'padding':'2px',
            'margin':'0px',
            'display':'flex'
        });
        var iconImg = document.createElement('img');
        SetStyle(iconImg, {
            'margin':'0px 0px 0px 14px',
            'padding':'4px 0px 0px 0px',
            'width':'74px',
            'height':'36px',
            'display':'-webkit-box'
        });
        iconImg.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAAAuCAYAAAAr3zfuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAACrlJREFUeNrsnHmQVcUVxn9vBhgcRAYFRYdVXMAFVDSiCBKBSGJMRLFUYjIuSSrBxKCJCZSyCCYFMRWxlCwarYQCJUOByGgIoohLUAY3UJYCUcCRTQQUUINg54/3XebQc+979773QGsyp6rr9e3u031vnz6nz/m6Z1LOORroq02NAEilcuVvAhwLHAmUAeVAW6AVcARQqjEcsAfYBXwEbALWA1uB7frdXNAve/FF6NWrHgkpHqWAC4GTgROAs4FuElC+9AWwDnhNaR2wFHizQY+yC+kMYBDQAzhLWnMwqAjopHSFKV8JvA68BFQBa/8fhZRyzllz1wwYDPQF+gHtsvAvBVYAHwAfAtuAjTJfHwOfS0tSQDFQArQEjlFqKdN4nLSybZbxVgBzgOeA2RlbPvUUDBhQr4R0NTAE6JXBfK0FngJeVn41UFPg9zkVOB44CRggk3pURNt3gJnAbaG1NTVQXl4/VMk5h4ObHDgvvedgloMbHLR32v0PcSpx0M3BKAfzHOz23nFFKN/w4envqicpEFJbB9PMxw92kPqSBJMptXQw3rznb+q0adasXgnIOUeRFOoDpYD+o28uBB0mV70QtB1YZZ7ren+TJtU7xyEQ0n/lSQX0vTz7bay9YgHwPrABeByoKMA79zb59w+oOftsqKiod0Ky3l1n4G2VzwO+kWOfnYBngQ4R9U8D35LnlwvVKGjeCbTWAkvTkiXQrZttex7Q0XiYyEKkgM/0LrvymL9LgTO1KFMm5lsP/E0e7EDgH4VwHIK0QbZ+bR77xofe5v6qNnhbNjPHvruYPqbXqd+xw7fn811mWuWca5rHfvGpc67KOfeAc+5BpYedc2ucc393zh3pnBuqtn2cc21yGccPZlcpYO0AtNeKSEK3Gxd+HfBt4C09DwBmAM0VIPfXSk5Cp5n8GwfUlJVBkzpbXwA1zdXYxZJnW+AO4EQ9NzUuPwqgq6SppwHLFP8huOssYB+wUNrkU0vFjD8F/gT0BB4BXtB7NFaAvlb8ZdLET4DH1Hck4jBT0A/A+TkI6Sf63Q2c4zkj87QnzdRzRQ5C6m/yCw+o6doVDjusjqHQ72zgQa/ujmAnA/4pEzpH5moUsBz4HTBF8xCY7/lCYG4EtgAPaDEUa3KLtQiHS1jTZfq2yYE6QUH9cvHukAPkFB9WA39VXaiQ5gD3mgmZlhBsLVP+VU9AAc0CPpXH1yUH69xHvxu179VS9+6Z+P4AjPPeFWCY3qNcaMaTEtKZwClCVB4GbhAqslkCWqfyoZrkFhIOZr87Beguwc0CLtZimWPeYxAwUpqa0u+7vtfqC+ltTcCxQiB+lMAVd6Zt0wxeX7DB7k0ooNOBrgHGXddd6ZQtDCjR2CnPuy1V/hM5PY1kcprLKx0uId0lzUHPgUD6R4y5VVtGtZ6P1PejxdwLuAb4ukBrpwXSUgv5rSghOUE/FfqwPsLJ4tDnWmnNtdq6A0u8NjcaAS5NKCQLvD5Rp7ZdKMwYFD4E/NCDn94C/ghcp7KOmlAH/Eradbi05jngegNHzZeAuwCjgTXeaUE7Cf8laWWwUCq0D90q+Gu5zOkSaVy59sOTpH2RKPg0E88MTSAkgHuASVL9BcCV2neKgWuB+03bhxIKaYjJz61T27FjGM9UTbIPxi6TW5zSbyN98581Wev0fjVmHkbqO+4xC/o+nRR0NwIKaLD2zUC4IxU73iyNuhb4GvBzhQFO5XcDlZlc8CBtl5v7ifCzJG7yYuMmf6CyDp4Lfl/CPnsY3qrQNpMnR7uxe/fiKitxl1yCGzECV1NTW7dtWzKXePVq3Pjx6T4ztXvtNdzKlel8VRWuujpe/zt34hYtCsXu/HS3mZSfJZzQpg4+Fu9ilR1l+luaQ3xUafgvC21TWorr3Dk8tWlzYNvi4nT5ySensb7LL8ctXVp3wior6/YV9NG3b7igJk7EnXpqbTvLM2pUbbtJk3D9+tXtv0WLdFvTp3+eZG154H4vlw1PAjXtkg1+FrhI5VsUdyyWmselw4UuBHFPmwS858nl3eMjLZq3TfLq0g7BddfBnXdC+/Ywdy4MHBi0b654Zp9M0gZgPh07wpgxaSjqlVfSv8uXo7joRDNuEx3xrKZnz/QRyowZ1iw29lCRFTi3JJu5w8HrZvWeWQBU4E2VbXfQJEF/w0x/ExJq4PyQIxg/7XHwgINm+/mGDMEVFdl+xobwle6vHzy4VgPSaV5I+wVZ5sqmB+OYOxxcapieTzAx/Q3fvab8X6Y8yfnUDsPXNqGQHo0hpCC9k6GfVSHtr8nQfmrEGEd77cZGtJsQdlQRRlUGZe5tPJhsdJzJbzD5TR5sEoduVqCIUIGkJ8Eu5Ph9gTzWZSHA8LiQPgLT5dP3E4wbUA/veWAc/qIsH/kLk/9LzImxl1UsrPShyTeLubf93jyPKADqf72Cx77C5K7SXhDQj0N4fhDR1zeBo3NAzQNqQfpeR+zzpCiaYc6ZenpnOVHUOkKT7JFA8xj9jBJKEMRU7xZASP64lQYRCBZPiXkuMcEugszWx9QmTPC7VfmrTPlVZqz3hO3lJCR/dU2O0b40Qnt2JNCklorkMRhbISgMTzzaMzMWge4nLzWg0cDz5vmmGGMulGcXQEMnmUVvge3P8hHSC0oBdDIyS/sjTH61yVtNOCpLH9NN/q48D+YsDQAuEG52iRCJ4039Gg9TvNXkq0nfvn3T28eyhSe7zWEqGtsi+h/JWkWazrg3WIdIJQHGAo96A0eZlFlmhZRHOBdhY/UzcdFICkd3Z6m318PKzHtgoKUngAmm/MoQJ8TSPkFjgTXo7OGKLwvHbBT3ZDZTGm1cxOoM7d6I4e5OieBt7GCvaXdhnreLHknggo/zeK81dbu8OhsH1YSMO8XUT3XQwjw/7WCIN24r713GZzqZzUR3CsVupwO9kREuaxNF2i6DiY0ys4+bc5kZCcHdOLRO5qWRxtmtlTwTeCYEsQ/oUyHjh8sbLDN15cC5wKKIMY/RmG8IjD2XA0+Yn8geSMTXJBx09STeO6RNa6VWEam1VpbPd7vpd1uB7un5mtQnJt9xCTTQaZwoTVqosjEhfPtUd1qhNCkIBm8xcP0sHWztzuJBZaMechBsDHIwKO73Jr0XdkWGuiAOWxQxn3iamZN359NEmaXApczXJB0rFCCgX2YwHflS3EuaQ01+Len7HucKsD1P5n6W1282wf7bC0mC867s75XQ3AWp2MF6o56P5WGS1mY9K8o9PemZke/E4Onj8UyMaHdOhnvps035MlP+jMdzhsov9srvz8fcWbeyt2KfFHAZ8FvSV7qS0Fxqb+GsIfx6VL6OwmZzDLAzBk9vmey9JtAMo8VyOjpRezehldCF96i9TmZDlWmkL6ik1G6ZQWM2GWdrYyE0KUj9vBUwNgFvleHb6aDsIFzwTzkoMvk4PKXiidu+yPwFSIk3blg/9p388tT+9jGPKuKmCk9Qt8Tg8aH807+Cf8Hx5aYCCwkHN3uTPixD2yle2wsahHJohIT+0MtO/ugYccugBoEcWiHh4LY6Xkpt3fNe3UUNwvhyhISDX4fgdAsaBPTVEhIOro6AT7YkvNTSIKSDKCQcnO/gMyOglcLEGgSQUEhR9+4KRScINqoRnPIFDRSPzP98OthCAviuIujqhpnPTUj/GwAGMKRX9/pnSQAAAABJRU5ErkJggg==";
        title_bar.appendChild(iconImg);
        var title_txt = document.createElement('p');
        title_txt.innerHTML = 'Save Credential';
        SetStyle(title_txt, {
            'display': 'inline-block',
            'margin':'0px',
            'margin-block-start':'0px',
            'margin-block-end':'0px',
            'padding':'8px 0px 0px 0px',
            'font-size':'18px',
            'vertical-align':'bottom',
            'color':'#ebebeb',
            'height':'44px',
            'width':'380px',
            'text-align':'center'
        });
        title_bar.appendChild(title_txt);
        dialog.appendChild(title_bar);

        var bodyDiv = document.createElement('div');
        SetStyle(bodyDiv, {
            'display':'contents',
            'height':'90px',
            'margin':'0px',
            'padding':'0px'
        });

        //////BODY/////

        //add message text
        var msgField = document.createElement('p');
        msgField.id = 'enpast_message_dialog_text';
        SetStyle(msgField, {
            'color':'#292929',
            'font-size':'medium',
            'padding-top':'40px',
            'padding-left':'20px',
            'margin':'0px',
            'display': 'block'
        });
        msgField.innerHTML = 'Do you want to save the credential to RevBits PAM? &nbsp;&nbsp;&nbsp;';
        bodyDiv.appendChild(msgField);

        var warningField = document.createElement('p');
        warningField.id = 'enpast_message_dialog_warning';
        SetStyle(warningField, {
            'color':'#ed2224',
            'font-size':'xx-small',
            'padding-top':'10px',
            'padding-left':'20px',
            'margin':'0px',
            'display': 'block'
        });
        setInterval(function(){ 
            if(!gDesktopApplicationIsLogined)
                warningField.innerHTML = 'Requires desktop app to be logged in';
            else
                warningField.innerHTML = '';
        }, 300);
        bodyDiv.appendChild(warningField);

        dialog.appendChild(bodyDiv);

        //create buttons
        var divBottom = document.createElement('div');
        SetStyle(divBottom, {
            'text-align':'right',
            'height':'40px',
            'padding':'0px',
            'margin-top':'10px',
            'margin-bottom':'20px'
        });

        var buttonCancel = document.createElement("button");
        buttonCancel.textContent = "No";
        SetStyle(buttonCancel, {
            'height':'40px',
            'width':'120px',
            'font-family':'sans-serif',
            'font-size':'medium',
            'border-style':'groove',
            'color':'#292929',
            'border-color':'#292929',
            'background':'#ebebeb',
            'outline':'none'
        });
        buttonCancel.addEventListener("click", function()
        {            
            dialog.close();
            document.body.removeChild(dialog);
            ClearLoginStateInBackground();
            setTimeout(function(){
                SetDlgOpen(false);
            }, 500);
        });
        divBottom.appendChild(buttonCancel);
        
        var buttonOk = document.createElement("button");
        buttonOk.textContent = "Yes";
        buttonOk.id = "enpast_button_save_entry_ok";
        SetStyle(buttonOk, {
            'height':'40px',
            'width':'120px',
            'margin-left':'15px',
            'margin-right':'10px',
            'font-family':'sans-serif',
            'font-size':'medium',
            'border-style':'hidden',
            'color':'#fafafa',
            'background':'#292929',
            'outline':'none'
        });
        buttonOk.addEventListener("click", function()
        {
            if(gDesktopApplicationIsLogined) {
                dialog.close();
                document.body.removeChild(dialog);
                SaveLoginConfirmToBackground();
                setTimeout(function(){
                    SetDlgOpen(false);
                }, 500);               
            }
        });
        divBottom.appendChild(buttonOk);


        dialog.appendChild(divBottom);

        document.body.appendChild(dialog);
        dialogPolyfill.registerDialog(dialog);
        dialog.showModal();

    }

    function Open(containerFolders)
    {
        if(GetDlgOpen())
            return;
        SetDlgOpen(true);

        var new_url = gEnpastSaveUrl;
        var new_uname = gEnpastSaveUsername;
        var new_pword = gEnpastSavePassword;

        if(!new_url || new_url.toString() == "null")
            new_url = gHostName;


        //add polyfill css into current page
        var polyfill_sheet = document.createElement('style');
        polyfill_sheet.innerHTML = "dialog {position: absolute;" +
            "left: 0; right: 0;" +
            "width: -moz-fit-content;" +
            "width: -webkit-fit-content;" +
            "width: fit-content;" +
            "height: -moz-fit-content;" +
            "height: -webkit-fit-content;" +
            "height: fit-content;" +
            "margin: auto;" +
            "border: solid;" +
            "padding: 1em;" +
            "background: white;" +
            "color: black;" +
            "display: block;} " +
            "dialog:not([open]) {display: none;} " +
            "dialog + .backdrop {position: fixed;" +
            "top: 0; right: 0; bottom: 0; left: 0;" +
            "background: rgba(0,0,0,0.1);} " +
            "._dialog_overlay {position: fixed;" +
            "top: 0; right: 0; bottom: 0; left: 0;} " +
            "dialog.fixed {position: fixed;top: 50%;transform: translate(0, -50%);}";
        document.body.appendChild(polyfill_sheet);

        var dialog = document.createElement("dialog");
        dialog.id = "enpast_entry_dlg";
        SetStyle(dialog, {
            'font-family':'sans-serif',
            'font-size':'medium',
            'padding':'0px',
            'background':'#fafafa',
            'border':'2px solid rgb(150, 150, 150)',
            'height':'auto',
            'text-align': 'left'
        });

        //add title bar main icon
        var title_bar = document.createElement('div');
        SetStyle(title_bar, {
            'background':'#292929',
            'display':'flex',
            'height':'45px',
            'padding':'2px',
            'margin':'0px'
        });
        var iconImg = document.createElement('img');
        SetStyle(iconImg, {
            'margin-left':'14px',
            'padding-top':'4px',
            'width':'74px',
            'height':'36px',
            'display':'-webkit-box'
        });
        iconImg.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAAAuCAYAAAAr3zfuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAACrlJREFUeNrsnHmQVcUVxn9vBhgcRAYFRYdVXMAFVDSiCBKBSGJMRLFUYjIuSSrBxKCJCZSyCCYFMRWxlCwarYQCJUOByGgIoohLUAY3UJYCUcCRTQQUUINg54/3XebQc+979773QGsyp6rr9e3u031vnz6nz/m6Z1LOORroq02NAEilcuVvAhwLHAmUAeVAW6AVcARQqjEcsAfYBXwEbALWA1uB7frdXNAve/FF6NWrHgkpHqWAC4GTgROAs4FuElC+9AWwDnhNaR2wFHizQY+yC+kMYBDQAzhLWnMwqAjopHSFKV8JvA68BFQBa/8fhZRyzllz1wwYDPQF+gHtsvAvBVYAHwAfAtuAjTJfHwOfS0tSQDFQArQEjlFqKdN4nLSybZbxVgBzgOeA2RlbPvUUDBhQr4R0NTAE6JXBfK0FngJeVn41UFPg9zkVOB44CRggk3pURNt3gJnAbaG1NTVQXl4/VMk5h4ObHDgvvedgloMbHLR32v0PcSpx0M3BKAfzHOz23nFFKN/w4envqicpEFJbB9PMxw92kPqSBJMptXQw3rznb+q0adasXgnIOUeRFOoDpYD+o28uBB0mV70QtB1YZZ7ren+TJtU7xyEQ0n/lSQX0vTz7bay9YgHwPrABeByoKMA79zb59w+oOftsqKiod0Ky3l1n4G2VzwO+kWOfnYBngQ4R9U8D35LnlwvVKGjeCbTWAkvTkiXQrZttex7Q0XiYyEKkgM/0LrvymL9LgTO1KFMm5lsP/E0e7EDgH4VwHIK0QbZ+bR77xofe5v6qNnhbNjPHvruYPqbXqd+xw7fn811mWuWca5rHfvGpc67KOfeAc+5BpYedc2ucc393zh3pnBuqtn2cc21yGccPZlcpYO0AtNeKSEK3Gxd+HfBt4C09DwBmAM0VIPfXSk5Cp5n8GwfUlJVBkzpbXwA1zdXYxZJnW+AO4EQ9NzUuPwqgq6SppwHLFP8huOssYB+wUNrkU0vFjD8F/gT0BB4BXtB7NFaAvlb8ZdLET4DH1Hck4jBT0A/A+TkI6Sf63Q2c4zkj87QnzdRzRQ5C6m/yCw+o6doVDjusjqHQ72zgQa/ujmAnA/4pEzpH5moUsBz4HTBF8xCY7/lCYG4EtgAPaDEUa3KLtQiHS1jTZfq2yYE6QUH9cvHukAPkFB9WA39VXaiQ5gD3mgmZlhBsLVP+VU9AAc0CPpXH1yUH69xHvxu179VS9+6Z+P4AjPPeFWCY3qNcaMaTEtKZwClCVB4GbhAqslkCWqfyoZrkFhIOZr87Beguwc0CLtZimWPeYxAwUpqa0u+7vtfqC+ltTcCxQiB+lMAVd6Zt0wxeX7DB7k0ooNOBrgHGXddd6ZQtDCjR2CnPuy1V/hM5PY1kcprLKx0uId0lzUHPgUD6R4y5VVtGtZ6P1PejxdwLuAb4ukBrpwXSUgv5rSghOUE/FfqwPsLJ4tDnWmnNtdq6A0u8NjcaAS5NKCQLvD5Rp7ZdKMwYFD4E/NCDn94C/ghcp7KOmlAH/Eradbi05jngegNHzZeAuwCjgTXeaUE7Cf8laWWwUCq0D90q+Gu5zOkSaVy59sOTpH2RKPg0E88MTSAkgHuASVL9BcCV2neKgWuB+03bhxIKaYjJz61T27FjGM9UTbIPxi6TW5zSbyN98581Wev0fjVmHkbqO+4xC/o+nRR0NwIKaLD2zUC4IxU73iyNuhb4GvBzhQFO5XcDlZlc8CBtl5v7ifCzJG7yYuMmf6CyDp4Lfl/CPnsY3qrQNpMnR7uxe/fiKitxl1yCGzECV1NTW7dtWzKXePVq3Pjx6T4ztXvtNdzKlel8VRWuujpe/zt34hYtCsXu/HS3mZSfJZzQpg4+Fu9ilR1l+luaQ3xUafgvC21TWorr3Dk8tWlzYNvi4nT5ySensb7LL8ctXVp3wior6/YV9NG3b7igJk7EnXpqbTvLM2pUbbtJk3D9+tXtv0WLdFvTp3+eZG154H4vlw1PAjXtkg1+FrhI5VsUdyyWmselw4UuBHFPmwS858nl3eMjLZq3TfLq0g7BddfBnXdC+/Ywdy4MHBi0b654Zp9M0gZgPh07wpgxaSjqlVfSv8uXo7joRDNuEx3xrKZnz/QRyowZ1iw29lCRFTi3JJu5w8HrZvWeWQBU4E2VbXfQJEF/w0x/ExJq4PyQIxg/7XHwgINm+/mGDMEVFdl+xobwle6vHzy4VgPSaV5I+wVZ5sqmB+OYOxxcapieTzAx/Q3fvab8X6Y8yfnUDsPXNqGQHo0hpCC9k6GfVSHtr8nQfmrEGEd77cZGtJsQdlQRRlUGZe5tPJhsdJzJbzD5TR5sEoduVqCIUIGkJ8Eu5Ph9gTzWZSHA8LiQPgLT5dP3E4wbUA/veWAc/qIsH/kLk/9LzImxl1UsrPShyTeLubf93jyPKADqf72Cx77C5K7SXhDQj0N4fhDR1zeBo3NAzQNqQfpeR+zzpCiaYc6ZenpnOVHUOkKT7JFA8xj9jBJKEMRU7xZASP64lQYRCBZPiXkuMcEugszWx9QmTPC7VfmrTPlVZqz3hO3lJCR/dU2O0b40Qnt2JNCklorkMRhbISgMTzzaMzMWge4nLzWg0cDz5vmmGGMulGcXQEMnmUVvge3P8hHSC0oBdDIyS/sjTH61yVtNOCpLH9NN/q48D+YsDQAuEG52iRCJ4039Gg9TvNXkq0nfvn3T28eyhSe7zWEqGtsi+h/JWkWazrg3WIdIJQHGAo96A0eZlFlmhZRHOBdhY/UzcdFICkd3Z6m318PKzHtgoKUngAmm/MoQJ8TSPkFjgTXo7OGKLwvHbBT3ZDZTGm1cxOoM7d6I4e5OieBt7GCvaXdhnreLHknggo/zeK81dbu8OhsH1YSMO8XUT3XQwjw/7WCIN24r713GZzqZzUR3CsVupwO9kREuaxNF2i6DiY0ys4+bc5kZCcHdOLRO5qWRxtmtlTwTeCYEsQ/oUyHjh8sbLDN15cC5wKKIMY/RmG8IjD2XA0+Yn8geSMTXJBx09STeO6RNa6VWEam1VpbPd7vpd1uB7un5mtQnJt9xCTTQaZwoTVqosjEhfPtUd1qhNCkIBm8xcP0sHWztzuJBZaMechBsDHIwKO73Jr0XdkWGuiAOWxQxn3iamZN359NEmaXApczXJB0rFCCgX2YwHflS3EuaQ01+Len7HucKsD1P5n6W1282wf7bC0mC867s75XQ3AWp2MF6o56P5WGS1mY9K8o9PemZke/E4Onj8UyMaHdOhnvps035MlP+jMdzhsov9srvz8fcWbeyt2KfFHAZ8FvSV7qS0Fxqb+GsIfx6VL6OwmZzDLAzBk9vmey9JtAMo8VyOjpRezehldCF96i9TmZDlWmkL6ik1G6ZQWM2GWdrYyE0KUj9vBUwNgFvleHb6aDsIFzwTzkoMvk4PKXiidu+yPwFSIk3blg/9p388tT+9jGPKuKmCk9Qt8Tg8aH807+Cf8Hx5aYCCwkHN3uTPixD2yle2wsahHJohIT+0MtO/ugYccugBoEcWiHh4LY6Xkpt3fNe3UUNwvhyhISDX4fgdAsaBPTVEhIOro6AT7YkvNTSIKSDKCQcnO/gMyOglcLEGgSQUEhR9+4KRScINqoRnPIFDRSPzP98OthCAviuIujqhpnPTUj/GwAGMKRX9/pnSQAAAABJRU5ErkJggg==";
        title_bar.appendChild(iconImg);
        var title_txt = document.createElement('p');
        title_txt.innerHTML = 'Save Credential';
        SetStyle(title_txt, {
            'display': 'inline-block',
            'margin':'0px',
            'margin-block-start':'0px',
            'margin-block-end':'0px',
            'padding-top':'8px',
            'font-size':'18px',
            'vertical-align':'bottom',
            'color':'rgba(220, 220, 220, 1)',
            'height':'44px',
            'width':'610px',
            'text-align':'center'
        });
        title_bar.appendChild(title_txt);
        dialog.appendChild(title_bar);

        var bodyDiv = document.createElement('div');
        SetStyle(bodyDiv, {
            'display':'flex',
            'margin':'0px',
            'padding':'0px'
        });

        var treeDiv = document.createElement('div');
        SetStyle(treeDiv, {
            'overflow':'auto',
            'width':'40%',
            'height':'271px',
            'background':'#ebebeb'
        });

        InsertTreeCss();
        InsertContainerInTreeview(treeDiv, containerFolders);
        bodyDiv.appendChild(treeDiv);

        //add url, username, password fields
        var topDiv = document.createElement('div');
        SetStyle(topDiv, {
            'margin-top':'5px',
            'margin-bottom':'0px',
            'width':'60%'
        });
        //url field
        var urlField = document.createElement('p');
        urlField.innerHTML = new_url;
        SetStyle(urlField, {
            'padding':'5px',
            'background':'#ebebeb',
            'color':'#292929',
            'font-weight':'600',
            'font-size':'small',
            'border':'solid 2px #b4b4b4',
            'text-align':'center',
            'margin-left':'6px',
            'margin-right':'6px',
            'margin-top':'5px',
            'margin-bottom':'5px',
            'display':'block'
        });
        topDiv.appendChild(urlField);

        //table for input fields
        var namepassword = document.createElement('form');
        SetStyle(namepassword, {
            'margin-top':'5px',
            'margin-bottom':'0px',
            'margin-right':'5px'
        });
        var table = document.createElement('table');
        table.classList.add('enpast_forms_table');
        SetStyle(table, {
            'margin-top':'10px',
            'width': '100%',
            'height':'150px',
            'padding-right':'4px',
            'margin':'0px'
        });

        //entryname field
        var tr_entryname = document.createElement('tr');
        var td_label_entryname = document.createElement('td');
        td_label_entryname.innerHTML = 'Entry Name';
        var td_input_entryname = document.createElement('td');
        SetStyle(td_label_entryname, {
            'width':'30%',
            'font-wight':500,
            'text-align':'center',
            'font-family':'sans-serif',
            'font-size':'medium',
            'color':'#292929'
        });
        SetStyle(td_input_entryname, {'width':'70%'});
        tr_entryname.appendChild(td_label_entryname);
        tr_entryname.appendChild(td_input_entryname);
        table.appendChild(tr_entryname);

        var entryNameField = document.createElement('input');
        entryNameField.id = 'enpast_save_entry_entryname';

        var new_entry_name = GetBaseDomain(new_url);

        entryNameField.value = new_entry_name;
        SetStyle(entryNameField, {
            'padding':'5px',
            'border-radius':'5px',
            'border':'2px solid #ccc',
            'width': '100%',
            'font-family':'sans-serif',
            'font-size':'medium',
            'box-sizing':'border-box',
            'color':'#292929'
        });
        entryNameField.setAttribute("autocomplete", "off");
        td_input_entryname.appendChild(entryNameField);

        //username field
        var tr_username = document.createElement('tr');
        var td_label_username = document.createElement('td');
        td_label_username.innerHTML = "User Name";
        var td_input_username = document.createElement('td');
        SetStyle(td_label_username, {
            'width':'30%',
            'font-wight':500,
            'text-align':'center',
            'font-family':'sans-serif',
            'font-size':'medium',
            'color':'#292929'
        });
        SetStyle(td_input_username, {'width':'70%'});
        tr_username.appendChild(td_label_username);
        tr_username.appendChild(td_input_username);
        table.appendChild(tr_username);

        var nameField = document.createElement('input');
        nameField.id = 'enpast_save_entry_username';
        nameField.value = new_uname;
        SetStyle(nameField, {
            'padding':'5px',
            'border-radius':'5px',
            'border':'2px solid #ccc',
            'width': '100%',
            'font-family':'sans-serif',
            'font-size':'medium',
            'box-sizing':'border-box',
            'color':'#292929'
        });
        td_input_username.appendChild(nameField);

        //password field
        var tr_password = document.createElement('tr');
        var td_label_password = document.createElement('td');
        td_label_password.innerHTML = 'Password';
        var td_input_password = document.createElement('td');

        SetStyle(td_label_password, {
            'width':'30%',
            'font-wight':500,
            'text-align':'center',
            'font-family':'sans-serif',
            'font-size':'medium',
            'color':'#292929'
        });
        SetStyle(td_input_password, {'width':'70%'});

        tr_password.appendChild(td_label_password);
        tr_password.appendChild(td_input_password);
        table.appendChild(tr_password);

        var passwordField = document.createElement('input');
        passwordField.id = 'enpast_save_entry_password';
        passwordField.value = new_pword;
        SetStyle(passwordField, {
            'padding':'5px',
            'border-radius':'5px',
            'border':'2px solid #ccc',
            'width': '100%',
            'font-family':'sans-serif',
            'font-size':'medium',
            'box-sizing':'border-box',
            'color':'#292929'
        });
        passwordField.type = 'password';
        td_input_password.appendChild(passwordField);

        namepassword.appendChild(table);
        topDiv.appendChild(namepassword);
        bodyDiv.appendChild(topDiv);
        dialog.appendChild(bodyDiv);

        //create buttons
        var divBottom = document.createElement('div');
        SetStyle(divBottom, {
            'text-align':'right',
            'height':'40px',
            'padding':'0px',
            'margin-top':'10px',
            'margin-bottom':'10px'
        });
        
        var buttonClose = document.createElement("button");
        buttonClose.textContent = "Close";
        SetStyle(buttonClose, {
            'margin-top':'0px',
            'height':'40px',
            'width':'120px',
            'font-family':'sans-serif',
            'font-size':'medium',
            'border-style':'groove',
            'color':'#292929',
            'border-color':'#292929',
            'background':'#ebebeb',
            'outline':'none'
        });
        buttonClose.addEventListener("click", function()
        {           
            dialog.close();
            document.body.removeChild(dialog);
            ClearLoginStateInBackground();
            setTimeout(function(){
                SetDlgOpen(false);
            }, 500);
   
        });
        divBottom.appendChild(buttonClose);

        var buttonSave = document.createElement("button");
        buttonSave.textContent = "Save";
        buttonSave.id = "enpast_button_save_entry";
        SetStyle(buttonSave, {
            'margin':'0px',
            'height':'40px',
            'width':'120px',
            'margin-left':'15px',
            'margin-right':'10px',
            'font-family':'sans-serif',
            'font-size':'medium',
            'border-style':'hidden',
            'color':'#fafafa',
            'background':'#292929',
            'outline':'none'
        });

        buttonSave.addEventListener("click", function()
        {
            if(document.getElementById('enpast_save_entry_entryname').value.length < 3) {
                var msgwarning = document.getElementById('enpast_save_dialog_warning');
                if(msgwarning) {
                    msgwarning.innerText = 'Please enter entry name over 3 lengh';
                }

                return;
            }

            if(document.getElementById('enpast_save_entry_username').value == '') {
                var msgwarning = document.getElementById('enpast_save_dialog_warning');
                if(msgwarning) {
                    msgwarning.innerText = 'Please confirm user name';
                }
                return;
            }

            if(document.getElementById('enpast_save_entry_password').value == '') {
                var msgwarning = document.getElementById('enpast_save_dialog_warning');
                if(msgwarning) {
                    msgwarning.innerText = 'Please confirm password';
                }
                return;
            }

            if(!selectedContainerId || !selectedFolderId) {
                var msgwarning = document.getElementById('enpast_save_dialog_warning');
                if(msgwarning) {
                    msgwarning.innerText = 'Please select parent folder';
                }
                return;
            }

            if(selectedContainerIsUnLocked == 'false') {
                var msgwarning = document.getElementById('enpast_save_dialog_warning');
                if(msgwarning) {
                    msgwarning.innerText = 'Please unlock the container from Desktop App.';
                }
            }

            SaveNewEntry();
            this_dialog = dialog;

        });
        divBottom.appendChild(buttonSave);

        topDiv.appendChild(divBottom);

        //add warning message
        var msgField = document.createElement('p');
        msgField.id = 'enpast_save_dialog_warning';
        SetStyle(msgField, {
            'color':'#ed2224',
            'font-size':'small',
            'margin':'0px'
        });
        topDiv.appendChild(msgField);

        document.body.appendChild(dialog);
        dialogPolyfill.registerDialog(dialog);
        dialog.showModal();
    }

    function ShowWarning(message)
    {
        this_dialog = null;

        var msgwarning = document.getElementById('enpast_save_dialog_warning');
        if(msgwarning) {
            msgwarning.innerText = message;
        }
    }

    var TreeItemEvent = function(e)
    {
        var nodes = document.getElementsByTagName('a');
        for (var i=0; i<nodes.length; i++) {
            if(nodes[i].getAttribute('data-container_id'))
                nodes[i].style.background = 'rgba(0,0,0,0)';
        }

        if(e.target && e.target.classList.contains('enpast_tree_parent')) {
            var parent = e.target.parentElement;

            var classList = parent.classList;

            if(classList.contains("open")) {
                classList.remove('open');
                var opensubs = parent.querySelectorAll(':scope .open');
                for(var i = 0; i < opensubs.length; i++) {
                    opensubs[i].classList.remove('open');
                }
            }else{
                classList.add('open');
            }
        }

        if(e.target && e.target.classList.contains('enpast_tree_container')) {
            selectedContainerId = e.target.getAttribute('data-container_id');
            selectedFolderId = e.target.getAttribute('data-container_id');
            selectedContainerIsUnLocked = e.target.getAttribute('data-isunlocked');

            if(selectedContainerId && selectedFolderId) {
                if(e.target.tagName.toLowerCase() == 'a')
                    e.target.style.background = 'rgb(200,190,190)';
                else
                    e.target.nextElementSibling.style.background = 'rgb(200,190,190)';
                document.getElementById('enpast_button_save_entry').disabled = false;
            }
        }

        if(e.target && e.target.classList.contains('enpast_tree_folder')) {
            selectedContainerId = e.target.getAttribute('data-container_id');
            selectedFolderId = e.target.getAttribute('data-folder_id');
            selectedContainerIsUnLocked = e.target.getAttribute('data-isunlocked');

            if(selectedContainerId && selectedFolderId) {
                if(e.target.tagName.toLowerCase() == 'a')
                    e.target.style.background = 'rgb(200,190,190)';
                else
                    e.target.nextElementSibling.style.background = 'rgb(200,190,190)';
                document.getElementById('enpast_button_save_entry').disabled = false;
            }
        }
    };

    function UpdateContainerFolderList(containerArray)
    {
        InsertContainerInTreeview(null, containerArray);
    }

    function InsertContainerInTreeview(parent, containerArray)
    {
        var ul_containers = document.getElementById('enpast_containers_folders_wrapper');

        if(ul_containers == null) {
            if(parent == null)
                return;

            ul_containers = document.createElement('ul');
            ul_containers.addEventListener( 'click', TreeItemEvent);
            ul_containers.classList.add('enpast_tree_root');
            ul_containers.id = 'enpast_containers_folders_wrapper';
            SetStyle(ul_containers, {
                'padding-left':'15px'
            });
            parent.appendChild(ul_containers);
        }

        var items = document.getElementsByClassName('enpast_container_element');
        for(var j = items.length - 1 ; j >= 0 ; j--) {
            var exists = false;
            if(containerArray != null) {
                for(var i = 0; i < containerArray.length ; i++) {
                    var containerObj = containerArray[i];
                    if(items[j].getAttribute('data-container_id') == containerObj.id) {
                        exists = true;
                        break;
                    }
                }
            }
            if(!exists) {
                items[j].remove();
            }
        }

        if(containerArray == null) {
            if(gDesktopApplicationIsLogined) {
                var msgwarning = document.getElementById('enpast_save_dialog_warning');
                if(msgwarning) {
                    msgwarning.innerText = "Cann't find any container or folder.";
                }
            }else{
                var msgwarning = document.getElementById('enpast_save_dialog_warning');
                if(msgwarning) {
                    msgwarning.innerText = "Desktop app was logged out!";
                }
            }

            return;
        }

        var msgwarning = document.getElementById('enpast_save_dialog_warning');
        if(msgwarning) {
            msgwarning.innerText = "";
        }

        for(var i = 0; i < containerArray.length ; i++) {
            var containerObj = containerArray[i];

            var containerItem;
            var exists = false;
            items = document.getElementsByClassName('enpast_container_element');
            for(var j = 0 ; j < items.length; j++) {
                if(items[j].getAttribute('data-container_id') == containerObj.id) {
                    exists = true;
                    containerItem = items[j];
                    break;
                }
            }

            if(!exists) {
                containerItem = document.createElement('li');
                containerItem.classList.add('enpast_container_element');
                containerItem.dataset.container_id = containerObj.id;

                ul_containers.appendChild(containerItem);
    
                var containerIcon = document.createElement('img');
                if(containerObj.isunlocked) {
                    containerIcon.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAADS5JREFUeNrsnXuUV1UVxz8zCgwIkg8WiCAiOGKIoOIjLSmMwBcZrgI18gHiGzVRSUXFB0IgL23URWoYGoKZKD5K8pFEpPlIzYpAMlBBw4VoiCBOf+zzc+7su+/93YGfzL33d75r7cVav3Pumcs5+57HPnt/N0SjKdALGAaMBaZ7yZTcAJwDHAq0ZAtwhGtkHvAC8E9gifvXS3pliZOXgMeBicCAhgx8NTAHWA/UesmN/M7NBrHoA7zlOyu38j9gaNTgHwqs851UFnKiHvyd3bqhK34E3A2cCQx2MsRLqmUw8APgDOAWYJUxruvcUv8FrjQq/RHojkfW0QH4tTG+Py9U+Iqx7r8M7OT7LjeoBB5VY7we6ALQz9COb/o+yx32Bj5U43wawEj14ytAE99fucQ8NdZTAcapH+/z/ZRbjFdj/SucFgR/vNv3U24xVo31wwBT1I+/8P2UW1ynxvqhL0sB2gBdgT2A7X2/l4cCdHBTzGPAG8DbwHJnT7gdOMr3f34VYDTwDvHmx0+RS6bOfhzyowDNgHtpmB16OXCgH4t8KMCdbNllxHtuj+CRYQU4LWJwfwsMB/oCA4EawhaoWuDJDHTYBcDTwBVAhVHezdlNHgZ6GuUVwMXAIuByxCRrtfEA8CCwf8R7XAw8B1wW0cY2V4AdgKXGGj8son5P4HVDCQamePBPVu96oSpv4Ta4hfIlhO9PfqjaGGH04/OB8r8CrVWdH6k2zkqDApxiDOYFCU4JK9Uz96dYAW5R7/qAKt8LcbAI1umm6kwm4gbOYW+jH3upOjWq/K40KMAd6pkXE77Aheq51UC7lCpAX+Bj956bCTtRNHEKHHS5qlJ1+gEbA23oGa8pMDfQxiNGG/2BTa58E/DdNCjAY+qZaxK+QI9AhxRk/xTPAt8CbgaOjSjfEbgUuBpxqrHQD/HSjWtjtNtnxLUxBTg6DZvAJmrtq0W8T5KgE/CuevZwvznP1imgElignrkk4QtUG+tmlmwCTd1XGOdd2xM43n3ZFpq72eCgmDYOAI5zm0QLLV0bBzaGAuDqaJfjJBhC2DetU0YGvzkw3733RsRPUmMQde70CxFvKz1wT7jyDcDpERvswkfyFNDKWDKeCpy8hjSGApytnvkcOKbIM1XumBN87nGyc1nUX737G4glNIjnVZ2zVflgVb7U+DsvqzpDixwtX25AH5ZMAdoBa9RzHwDfiJmyZhtHnmEZmv57q3dfQNhz6oEido4+qvxp4+88our0MzaEwfJ5DTAOldQSeK0xoOuRcLLeiMNhd+AkJEyp1viCWmRsEzUK+BvwZ+Bgo3wf4Bn3fxsXYT38iStfGLGG9wi0cU2EdfEaV76Yhnlul1QBdnDmySh7/5rA+VXLJnfEyiKaJqhTVaS8WQnaqNqCdy/5ZdDO7mtoyEXQRmLCkzzSfwy0lOCXCQf/Hwk2ix4ZU4ACjgdmEQ4y+dAdE0fFnGs9cqAAQWvf4UhM+lHAfr7fy0sBPDKuAHf5fsotrjVsCNysfrzH91NucYMa6wcBxqgfn/P9lFvcY83231M/fkK67+g9tgxtkFiN4FhfBOKq9QFGzJhHrqBd3GqRa2cAbjMKbyP6TtsjO6hC7g5ivbK7YhNEvYJ4svYFDnFyqJfUy8EIycdQ4A/GuH7uxrIehriCOBv+RuQix0u65VPiTfKjoqaLUxDvVU+lll+5LG69OImw166XfMmlUYM/xHdO2UhoCegCrDUqvopE/ByCRKz09JIZ6Y04nS6KUILDggow3agwg+y5bHmEUUH4EqgW4Q3crmAIWusNQbnHrWqMNxcMQYNUwWf4O/w8YtcoU7DmCV6I7c3qkX3MwohW9tfB5QPzOngqniiyXKCJIueBdwkrJ2wTn8A2iFPoMYhTaDff7+WhAP2QxARLqIuQ/QzJWPEsEkLu3cJzqACt3MYxKgwsKK/jGUNzpQDtCIdEF5OGxrR7pFQBWhAfHLoxZlbYjIRKZwHFYu8rcSbVrWhjO4qHeG+fNgUYg52XbgrikdIB4QU+izAxRGE5SDM5RBVCcr0CIYNsZdTpj4RpvwWcYJQ3R+5UViDxkztEtLEUeBObN7EKYWRdAczcyn1UyRSgDfBfwvSvR0TUb+mMDloJhqdYAS5W7zpelbemPlnmR0B7Veci1cZVqnxX6nMnrjbaGKXauDoNCnCuMaUXi/ptgvgYBp97IsH02Vj4qXrXWap8T8IUuJr/+CZV/jNVvhdhNzx9D6PHpyYNCjCTLeP91fSr65CkEmlEd+qSaa42ZrdKYILb52x2A6OVuaeb2gsz5GHG2h9sY7qxLB5I3SXOfzCcObe1AlQg4d6J3IwUuiGBJ1mhieuA+EnGMZv3R0Ljo9AJOLVIG0cjtHBxbQzF5flrbAVogtwYeqLIMj0GVlDHdRe1uYmbVrXTac8MdWBHhOTp9Ji9y/eRK/Z9I8o7u/JTiiyVYxAyaQvVro2TG2sPcLt65i8JX+AC9dwqYLeMDP4uCENY4d1vMuoEd/0rCKfHaUf9JN3XG21cFSj/t1O6INoDywJ1Lm8MBbA8iEcm+Hr09D87Q1//sYRJHjXb16sYHjcBaO7/lcbfeaPI8noGYbq9bU4U2QLJ/aOPgsMiLFrd3Syhleb4DCnAvmoDe5/R8cEAzM8IE2f2oj5X8r3G37lTtaH5CA9BaGYLde6gkYgih2Obeee59e077qsZTzj6uMCDmzUMRPiC7wZ2N8pbI0G184mmwhvkymcAbSOMbIU2BsfMwPOdsuzSGEtAlD0gqazCJ43K7ClAG0NmNXDwlwNf82ORDwUo4ArC+YAs+Y3/8vOpACB27SuRdDJvIsEmq4EXKE26E4+UK0BwWWjvvvQ98SwjZacAHhlTgKl4oshywbUYMaAT1Y/3+n7KLcZjJMO8lHAOmia+r3IJ7ZVVA+FkSLVkN5uHRzSqCXswDQMxJa4gnAp2J99nuUGlW+81I+wX180WkeACpzUe2UYn5OJKj2+9KPCdCaeDr0WSJ9cA5yFXmV6yIUOBc4BJiC+iHte1hH0VONhYCrzkT9YRk4H868SzhXrJvpwUt16M9R2Ue5lBRO7DMTEPfYD4oS1DLnq8pFuWAe8XUYJ6OCyi4ly3LLR3x0Uv2ZF2SMzFnRFjOzB4RpxjVLjIn6BygyHU9yOsRa7pq0ASHmt68Wm+z3KHHxsf+ZEQzke/FgmJ8sgXmiOpe4NjfaW183/C91VuMUON9UyAyXiHkHKBJ4osc+jZ/iHwLmHlhOsJe2mXXAH6IJnGRiM0KyciVCgeOVaAFohn0euECSAKUa4zgR5+DPKnAPuRnCtwPcWjiD0ypAC9CLOFJZHr/VhkXwHau6ndGuB3EefSpYRNkAU5NQMdVoVYSlvF1OlMPHdPc4QbqWWRNvYq0sY+bD3XckkV4A5jUJch9Ck7Ip7FVUgqU+uu4W0kFDqtaIuQXG9wymwN8rluz/MJQh2jM620Q/iUNiB+lpoRrQI4P9DGJUYbuwGLXRuLCTOGNIoCVBtf9mvuP5zUCFHrOi2tGEd8wExbY/nrXKTDp6jyDmrTvJEwL5D25Z+WBgUYbWzukuzwNbnUIjdLpBHaP6LGWAJXqTqdVJ0rVPkEQwE+DpRvMBRgbJE2GkUBZqtn5iR8gWMIM4d3SakCtEUindcAf8IOax+BkDeudDYPjOn7SdfGooh1/kzEF3NlxAmpg1uK1gDPsHXEmiVRgO0QepfgM+cnfIGuhIMTeqd8I9iDeDrbjkgUdBQqErSxR5E2Cu+xteTaJVGA7QnnpE9K+twJ4QyITGHqkY1j4CNbuC4dRNjruHuGOrCPW+4mYkdONUcicOcSzYDWF7gf4Rm0uBNaATci6XcGRLQxwL3HjQ08GpZMASYbx78km7kb1XNvIkEpWUAXhBI+SBOnMZV4ird9qcunZDGQQ/07+02EmVT3UyeHGpIn+iyZAlgBpcWOJ0eq/3yB4y4rOM5Qek0U+Zqqc6Eq/zKIIv/egL1BSQ1BLxpKMNGwBTRFuPEsk3GW2MI6Uj98biJhgsbLA+XvEOb+35M6+ngrCYU+9q00joXVSIaSQp0xjTEDAHwb28S7zC0RI52hZ0FEvSwykezjZrqRMV/dCNenUaebr7r+OS9i4CqQNDvTYmwrB7jl5rzG2gRGGYSSymI8eVSmTwFBXNXAwV9AvMnYI2MKAJIx69kiA7/SHZGa+nHInwIU1q6B7nz7MGL6fArJUX8m8dedHjlQgCAqnYGime/z8lQAjwwpwFQ8UWS5wIwL0Fox2/dTbjEJgyjqbMOQ09L3VS6hr/EngOTt00e2k31f5Q59CGdzHwQS1KEvMd4mbMf2yC7aE85o9j6BlH0jsFO7nIDccXtkE5UI7e9LxviOC1ZsBjyNbcFbhGSxmuQlU3Ir8PuIMf0XRraxjsjdsqdSy7e8R0zC7mr3xfuOyqcsQVjfYlGFcMcs9x2WG3kfcWBpSJJJdnfHhAmI/9ujTuZ7Sb085gx6UxBq2MiLuP8PAG9GBFgM27N/AAAAAElFTkSuQmCC";
                }else{
                    containerIcon.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAFrhJREFUeNrsnXmUVcW1h7/upqEZFMXHEhUlAqJ5MggqGBwY1OWMUeMTNUQEwUwi+JCgRsVZxAEDwYGH4oAgiiOiiQyihiCKAirweAIqCBGBIDNNN/X+qH3h3H3rnDv2Pee23WvtxaLGXXv/7qmqXbt2gf9fbeA4oC9wB/CXQqQSGHUOTBwJs2fBkmWwZjNsL4fdBowBUw67N8P2ZbBmFiwZCbPPgYklMKpQxw3cDfwO6AQ0IIO/k6WR14GPgf8Flsm/kacu8M04+Pd6qIgpOl1aDxXj4N9d4JtCGbfoaBnwKfA2MAI4Ox3FtwImA9sBU0hUBOZiMHMzVHgQzZW2iwpMJh76u3wNAv+6YNFecAM8EcyHVaB4TR9KXwUKgm1ALz/ldwI2F9qgSsHcBaYyBeVtAjMbzDipM1ToLkmbLWWStVMpdUoLFwiXaOU3knlDF9wCPA30Ay4T6hkV6gT918LSIGVthFXTYXJfGFIbLk/WZm24vC8MmQ6TN8KqoLbXwtJO0D9KMhEd/RfQB7uI/ZdDr5tlqt/7d4uj0D+AY9NdORpjMqP0YdzSwMoABU01cFoOfi6nSVt+/awUXrLrJ0U5ZfDXFJji6PJ/YgUOcMz7nwEHZtJbngDQ0sBqH4UsMdCtCr6b3aRtV5+rswZB1QEAoBh4S3W5HWgBcKaDn66Z9pQHABxk4GsfRTxqoKwKJ88y6cPV99fCWxQBAHAU8KPqtjfAAJW4ACiNKABKDMxwCL/cQO88rqJ6S5+ajxnCYxQBgNh0vN2OBLhXJb6QTQ9VDIChPsrvEcJSuocPCIZGGAD3q24nIijwJj4dUQC0MrDTIfB+Ie6n+jn42Sm8RhEAd6hu3wB4RCWOjygAXnUI+4kIbKqfcPD1akQBcKfq9rUqAQDQGGgJHAHUygEA2vtsvxpEAAANfLaj7X9qAGgqn5hpwGLgO2Cl2BMeB07PAgBPOwR8aYRMa5c6+Hv6pwSAocCaJGPcJYdMR6YJgP0NbFPCXWigKEIAKBKevDxuE96rNQDqABPSlNdKoEMaALjE8evqH0EDe38Hn5dUdwCMy1Be64CWKQJgrBLqbgMNIwiAhsbjZCI0tjoDoLfPWP4GXAN0B3oAYxwWKAO8myIAFimhvp8vpQLXAbOAm3FMOcAxYjd5A2gnvHl5XQQMAuYAfwKKfdp4GXgFaOuj9EHAB8AQMeuGDoD6wFeOOb6vzwDaAV84ZNwjCQBqOYwtI/Kk/CtU0vUqv54scGNJy36EUerYuKJWfBv9VRv1gXmepIVAQyW73yg+ro0CAK50yOy6IDuA7BJWqzovJgHAEY55tXeeADBKJb2s8puLg8Xe5Hlwk+b3CHUCp9o4ytH1cUpuY1T+U1EAwBOqzvxUDEHA9are90CTAAC0dQDgvDwBoDuwVf5biVrQyXnJi16Xq/Vwkea3Hez2tNFDtVEbeMmT9CZQpmR2Fvva2A1cGAUATFN1bk8RAG2AclW3bQAATnYAoGse1wDdgIfwAR2wP3AjcBvQSHiL4/deGCheukFtDJV1RiMfuZ0pejonCovAUjX3GfE+SQUAzYC1qm7nAAB0DRMAGVDm/BbQLqAYmK7q/HeKAGil5829NoECAIB8ss8BOmXKL1AXOA843g8AQHvgfKC+DwAaSBsdwpoCxjtcjlMBQE+Hb1qzQgCAKG6q/LccxynkXXBrEL+iuHfkvzuBqzUAZIEd+5HMBPZTMtxf0mM7r55hAOC3qs4e4Nwku4Ay2eZ4672997Ao+gA4SyUtBup4E853u4x5AXCZauMrBwA+U2V6KTn+2uG+VyvfAGgCbFD1NgKn+ii/ATDJIde+SbaBUQLACSppOlDqTbgUZicBQBfVxiwHAN5UZc50LAi9+a+nYRzKqSVwmENO27HXyU4Qh8Njsa7YnzrKLgbqFQoARIGDgS+Bj4ATdf6r0CuFNcBNMvYPgQ4OALQB3pMytzt+TEWy61oMzE3TczunAKgv5kk/eW3w7F817Qa6pWAKjtwuAKid7S5ATx2uXYC2Bzh2AWVROAxqJL+GdGRYrue1mm1gYfsDNAKeS1FGS4Fz0/AHqAFAAXkEXQA8T+Ilkx9lmzjYta+tAUA18wkUa19n7J3004HWWfgE1gCgEJ1Cc+gVXAOAEADwVA0Aqi0AhjlsCDykEp+tAUC1BcDdqttXAG5ViR/UAKDaAuBZ19f+IpW4A2hbA4BqB4DG2Lsa3m4Hxly1NuK4M1YNAdDQwFEGTpJ2LhTqKmlHZelxHGUAjHJ02z6W+Zgj8zE5eixEANSRyB6D5YbOHAMb0wgGtVHqPC1tnGpc5tvCAECZnB0keGV7C7XEHSBqATYGTnego1CnfNFY+J0W6Nh9wQ/j6Hq45GMYvQHmVbpvEWdFlbBzA8z7GEZfBxdny28V04nYIB+9gPcdet0juoz76ykZQTb8cjnIyQt1cwR57AYVsfxGsHsQVH4Ge6o6PJymz2DPIKhslAa/eaRdST44g4PcvSujsqbq6hB8VzBtwDwJZnuele6i7cJL6wB+I7ZWHRI0X1zu8NqNFAAWpamgjRL/70kwN4K5HMwF0nZ7oa6SdrmUeVLqbEyzr0WFAYAb/ZTfM2q7qq4Z/CLXgXkeTG8wLXLAQwswV0ub6zLgp2s0d6wJU0ALYJOj4CLsjZ+O2Mjh7fJJE6Bvigu0bathyiTof4Dd2lQJPwdA+0nQfzVMqUy8su6kCTbaersQ6ATgauy9RBcITvIC4C+OAmOx99/C2ga2NPBREgGvNHBDSLeFG0rfK5Pw+FFKMQSrbhtY5DgEMti4gSUxQ9CmiBmCrjKwNUCoKwxcYRy3bUOgYuFlRQC/W2VMYRqCRqsuK2OGoItVRgXQOiQAlBp1w1bRBgMDTbBfXlhUW3jbEMD/KKM8ifMIgP/wMwXrOMEfymcj3wBoaGBmgPAmGGhcAKG4GwuvfuOY6Zyy8nMY9DyOeMHhHwdDEwMLAsyyFxZgTPYLA8zPC2TMkTgOHkmYgSKhqbE3ZFyCmmPg8EINyi/xDeb4jO0rGXuYgSJfD9clzH4uv/AR0LMRneszWRs86zPGL/ZOa9XIKbSxOIWeK06hx/gov76B+T6Cua0aKF7TbT5jnW+CvKULCABnYh8mWMa+B6cqsC9WzMZeIa8vyi8x8KaPQAZXQ+XHaLDPmN80UFKoANhPFo67U5DBF8DpBu71EcQN1Vj5MbrBZ+z3FiIAmhAf5SopnZ8YS2+fAKq/8mPk9wM4r5AAUI/gy6Hl+qvQBMwG98BfjFjoV+9FzlpJ8otJ8kiEo40iGbPL0NXER/G1ogaAW3G/S/eIeKQ0BY7ExrVbCJjX/PfE9SKo+DJskOtV2GCQ+/kEjViMvQ73S5+oImOljeewC99Yfj0f28drjsAa46SNZ7C3skMHQGNgPYnhX0/2CxBxPczTg90de1whs1fDqhoAg1TS/Sq/IfHBMrcAh6oyA1Ubf1bS77TN7c3U0yO7waqN26IAgN87Dhb8Q8RAgz2wRg90qF0UlkQUAA+opOdV/s9IDIHbUpW5T+X/VQebvMYNgO8MNBAAaP2MiQIAnvHzMPUBwD16kH/fFyTqiIgC4Fj2Pab5PTZmoZ77h8s6p1IUU6LKtANWeL6QJ6n8EmD4u24Q3CMA6OA5xPnW5cyZbwAUYa97O92MHMo/RMf73xHvrdMhigAQBTUVP8mWSYJHXRCQ3wy4KqiNK6FPJexyvDdwiCe+Yi9x3Al9EVgqJ4apBYqEkRrdd6ceKPKnRHc7vgIjo7gNLGJfrLu9ixsnAOxDitu9g1oPpmF83XaFAgDgcGyQp6v9tn7ApXLE/nOf/CMl/0qHh9F6r6z2wA4DBzkA0ErauCKsNcDjqs4nPgBIeOdvSHy9fyGfuTwqsqmB6wy8ZOCfQi9JWtMA5R+EjRAWS7rPUca76l8FHKnymxD/SPddcaeBMETLaxXcpwBwKLDc08afwgCAy4N4QBwArKtU3Ovbm2GP+vVPyuLx6HRpPwOPGcflDQ9VGBhj3Hv+81TSV6jrYuJEG+dxo/J17P/VCgANt0Cll6ct1qeg2AOAPiSG28t7oMh62Ld/9FawLzFm4Uwt4AcT9XJBngDQ1CR5Zl7RUv01AH6OvTkdS3pBW/iIv4BZgb1T6M0/jvhYyRO0P8CL8LmDnzM9AOiIDTMbq/oEIQWKvMZH3q8DV34F7+qBHB1fbmaWz8en88tPR/leEOynFNgDGy/4aeAwx1eiIfZS7VRs0EjXVHKx5I8FDtYAeAV+4eDlGbUG6CltjJOpKbTDoGdcMi+1n/u4Qfwjce5vmScAjAlwNZsm5Oe6NSZva5N4WWgvos0GSqN4GljscDQ03R3CHBD/bNwvsng+Ph06zDHn7zFwu7ruXUfS9jjWBIeFAIABDjB2j7JDyM143gN62AGAZnvD6apfftUCYECa3kYur50BIQCgmYOPh6PuEdRc9qbTFqj7+avgB+CcHDwfny5NUUL8IYmfYW0p460zJe8AsPLQL5HOKwifwC/tY8r6szs6B6+HZ0JzE45ak9d5TdWZGxIARjumo3qRB4CBUxyfr8tCAoA+bx+fQp3xDn+FMABwmUOOp1QFAEaSy0CRcK2D8eY1AEgbAM0dcrw2SwAMw3EHdIRKnJAlAPThz3avJasGACkDoFifoxj7Y83m737V7cvIUa5+g6Y0CwBMVUx/mkWUsJ8uAKxMPlW8TM0SAK+4nEvOcvDTLQsAfKyYfqMGABkD4A3Fy8dZKL+Vw4Opb+yUa5XKmA8cmCEAtOvX4zUAyBgAjyte1mSo/GKZ73VE2KNiBVyBBKcLatIFwGbF9J01AMgYAHdqk3AGym8mB1e6y7hb4I1IfA7eYB9PHgP8QY4yk5Jeub5jFxq/CYPWwzdeXhbaewyBdRbCB8qB5Zuw+H/HvlgeJ88U6/bCBqh8UHwRtV43iWNK3N+JjqkgfSArGhiiE88Cxcv4FOqMV3UWhMj/QIc8c9DuZgJeID+F4GihNQAofABcHjRf3JHrL8AtNQDImG6pGgCMxT6CnfB3a0CljeKHtlz83H1J33R51M43K8KgL5Wr9SR7eyewziTY4q3zpY27Gwr/j8ImLy/b7Nc5lbrLsQdwQSCI+zvJp+BLMi0cKtvFpFSpFl5b7WrzoDCoXEUf2QoTk9XZChO9dcrt7aVQ+N+qIotU2gVpqvWbYC+VjPPRbQ/vHnGyo8DADO0AOrjjtBC3gToCyaQU6kxyRPAIaxs4TQedzNAO0FP5ERqsUakM4GgSw4s/moUlcHKCb114AHhb8bI4hTqLVZ23QwSA9mWcnIUl8AZHt6dB4nv0m7BXojIFwHDF9O6YP1sIAHAFYjg7oPzZoQWuSJRHqUkMpjE8CwDUxT7d6+32FtfK/50sTwNdT6i3DQkAJzh4WWfgeEfZ4yVPlz8hJAC0dfDSK8vDoLGq22cAHs6xQ0g7B+P9QgIARln2PN41Ewz0F5rgc2Hk/VC8gq08+jn4aZclAPIQKNJeltiaYIMPDwD/6ThXT4W2S92wADDeEXC6VpYAuKPqXcIs8zMU86tDBADGXt8uT0P55SbgyneeALBa8TQjB06hd6luX805AIAur8Grrs9XiADA2AAPy1NQ/nKjgkGE4BbumkZvijIA6oln0RfAjg4OwY63gaLahAgADNQVn8UZ6otQLmnXShlCBsBdDgB0iCoAWqNiBRaB+VYNYJlN3w4MCBEAOlTbwULhh6jbJ4ciA8uU8r81UBRFABxHYrQwA5iHHF+BU7334sMHQLRonxxOdfz6H8pRhJCcAuBQ4Guf8azt6LiROzG+zFVRB4CYSo/GES9ARfxoEZBfFzgGe2EmqI3mIoeJWm7Lra/G0WQXIzDnAHjCMZbl2PAp+wOllfCJdyAVYI7YV/Y7oHFUAQAcjA1yvVM8pVs4yvxefOt2YEPHFDkignwobczHvh/gzS8C/hhro7Od++PsEbts33OljbnYMDWhA6CV43Dhc3SYU4eL2Oj4OjdFGAD3qqSnHADR058OCaMF/ogjCtneoBN/VdFBDJh7rCt4Ts5pcgmAoarOdqANiavZ2hL00Hu86v0KzAHKIgoA7R8xRuUfio1z4E1upsrcrPKHOwCwFZFJuSNgZINE693wKABgkqozOc4QFA+CgQFrgV1AiwhPAdOADcA/ccT5w76s/i32avwgR/4h2CCaGwTszR1l+gGrpritlQMFJLOljfeAI8IGQAkwU9X5YwAA6uqvgNoRnBDlXYB82UqShI77WUB+UbI2/ga/8gkXW9ez+m9D9qbgnACgFolv0l/jCwCr3N56gEvA1LF1T/qJbwPrGFjiAEDvKngvIGdTwJt+85IPAIodV8bMA7busQUUKLKLTHcjgAN9tnzDxJXuAp82ugMvYgNJ72/gAS2Xb2BNiT2pO9sHAGcLH/ekuTXMGQAedmz/ynwBYBXcoVI5jO4BsxguKgQAYOP0bvEkveAo4z1ZrQBOdISai72nZH4N03VcokrY02Ffld2oMxSxvHrD1Y0h9Yc+cwYA14XSR4MAAJw2wv1czDpTAG8DAuc7QK8DRX6uylzvFyjycHvrqNKxTdZbyz5KjjpQ5JI01gY5NQTNd8hphLYFYH3QLwbW1wHzWdDTadEGwOHEX58bgXq8Ghu2NfbfNUBrxxsDK+qDme+Ww2f7x2/7VgNHKXm2wnoHx8rcGsYXAOAMH1ktlyligFjHpnvzj7HhT12Df8skeZ8nAiA4Wr50A/DhVbaGj+DjSnYwtFngfml8i7Em4yJsJJBHXaen8tdepps/hH0YNDQTWfZJPO3yPhBdUo1X/CXG/2HpX+Xh2bgqOQ7+c5pymI59OHnYTwwEQcq/PU8vh1aZQ8gvxVoVJIPVskWq7Tn3Hu8jkKkmgi+JZUH1ZIpzjXV87Ky/kAEQs3j1kP3tG2L6nIl9o74frkhh9lfxio9gPgmK319A1NSoU1EVhLLEBG2fCwgAew1B2Otm9YE6KTiD1g4AwfcGuhew8rvLGFxjeyUuaml1AkDaZH8Fz/gIao+xb/bVKTDz7v3G/RqYkbGWJL0alicAjCSXgSIzAcC+NcGdAd66XxroXADK7yy8+o3jTqcPYn4A4LwXoFExKSQAxOgyx8USLz0b0bVBU6OuczsudlyW1uXQ3APgQRyBon7rMOQ0CBEAGDjWwKIAYe6QiKRNI6L4kcKTH7+LZEyEDICZrkO8zg5+rggZABgoM/CwcdjLlT//cyFNDZ2l76AbR5UyhrKMrofnFgBdUK+5i4meeo5DjO/k1ClMAMSoo3G/sq1piYFbjbK/55haSx9LUuBngfCeeXyA3AHgUBJfNPtBPJb22q81TyvFwFM3ZADE/AmuNbA2xbt93xrrxNnHQBu5a5+uskulbh9p69sU+14rvBZnHSAiewAUY8P+furo8l5vwTrALB/e5mBfwnowbDoARj4F729RbxEnowqoXAsbFsKKGbBoCsybAHMeh1mPw6wJMGcKzJsBixbCirWwoSJ46kmgLbDtKXj/ALurejACNBqY4aPT/8Px2tjhcrYc+Z1WGZh+jjBwYdAC4aWscOxT67DBo3z9/ecUkrGtI5hRYNbkUelrpM+OhWecXEYKr46UYWPHrCykwRWD6QRmGJj3wezMocJ3SpvDpI/iwlP8D+LAks4jkxwm24Th2GjTbwlNLQQqg2lnwAdDYOFzsPw9WLsUNq2DHbsc4WB2QcU62LEUNr0Ha5+D5UNg4RnwQZm9HzC1gGiaGPQewYaGbe6n5P8fAHlhpzdVicuYAAAAAElFTkSuQmCC";
                }
                containerIcon.dataset.container_id = containerObj.id;
                containerIcon.dataset.isunlocked = containerObj.isunlocked;
    
                containerIcon.classList.add('enpast_tree_container');
                SetStyle(containerIcon, {'width':'20px',
                    'height':'20px',
                    'margin-right':'10px',
                    'vertical-align':'middle',
                    'display':'inline'});
                containerItem.appendChild(containerIcon);
    
                var containerTitle = document.createElement('a');
                containerTitle.innerHTML = containerObj.name;
                containerTitle.dataset.container_id = containerObj.id;
                containerTitle.dataset.isunlocked = containerObj.isunlocked;
    
                SetStyle(containerTitle, {'color':'#292929',
                    'cursor':'default',
                    'vertical-align':'middle'});
                containerTitle.classList.add('enpast_tree_container');
                containerItem.appendChild(containerTitle);
    
                var folders = containerObj.contents;
                if(folders != null) {
                    containerIcon.classList.add('enpast_tree_parent');
                    containerTitle.classList.add('enpast_tree_parent');
    
                    InsertFolderInTreeview(containerItem, containerObj.id, folders, containerObj.isunlocked);
                }
            }else{
                var containerIcon = containerItem.getElementsByTagName('img')[0];
                if(containerObj.isunlocked) {
                    containerIcon.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAADS5JREFUeNrsnXuUV1UVxz8zCgwIkg8WiCAiOGKIoOIjLSmMwBcZrgI18gHiGzVRSUXFB0IgL23URWoYGoKZKD5K8pFEpPlIzYpAMlBBw4VoiCBOf+zzc+7su+/93YGfzL33d75r7cVav3Pumcs5+57HPnt/N0SjKdALGAaMBaZ7yZTcAJwDHAq0ZAtwhGtkHvAC8E9gifvXS3pliZOXgMeBicCAhgx8NTAHWA/UesmN/M7NBrHoA7zlOyu38j9gaNTgHwqs851UFnKiHvyd3bqhK34E3A2cCQx2MsRLqmUw8APgDOAWYJUxruvcUv8FrjQq/RHojkfW0QH4tTG+Py9U+Iqx7r8M7OT7LjeoBB5VY7we6ALQz9COb/o+yx32Bj5U43wawEj14ytAE99fucQ8NdZTAcapH+/z/ZRbjFdj/SucFgR/vNv3U24xVo31wwBT1I+/8P2UW1ynxvqhL0sB2gBdgT2A7X2/l4cCdHBTzGPAG8DbwHJnT7gdOMr3f34VYDTwDvHmx0+RS6bOfhzyowDNgHtpmB16OXCgH4t8KMCdbNllxHtuj+CRYQU4LWJwfwsMB/oCA4EawhaoWuDJDHTYBcDTwBVAhVHezdlNHgZ6GuUVwMXAIuByxCRrtfEA8CCwf8R7XAw8B1wW0cY2V4AdgKXGGj8son5P4HVDCQamePBPVu96oSpv4Ta4hfIlhO9PfqjaGGH04/OB8r8CrVWdH6k2zkqDApxiDOYFCU4JK9Uz96dYAW5R7/qAKt8LcbAI1umm6kwm4gbOYW+jH3upOjWq/K40KMAd6pkXE77Aheq51UC7lCpAX+Bj956bCTtRNHEKHHS5qlJ1+gEbA23oGa8pMDfQxiNGG/2BTa58E/DdNCjAY+qZaxK+QI9AhxRk/xTPAt8CbgaOjSjfEbgUuBpxqrHQD/HSjWtjtNtnxLUxBTg6DZvAJmrtq0W8T5KgE/CuevZwvznP1imgElignrkk4QtUG+tmlmwCTd1XGOdd2xM43n3ZFpq72eCgmDYOAI5zm0QLLV0bBzaGAuDqaJfjJBhC2DetU0YGvzkw3733RsRPUmMQde70CxFvKz1wT7jyDcDpERvswkfyFNDKWDKeCpy8hjSGApytnvkcOKbIM1XumBN87nGyc1nUX737G4glNIjnVZ2zVflgVb7U+DsvqzpDixwtX25AH5ZMAdoBa9RzHwDfiJmyZhtHnmEZmv57q3dfQNhz6oEido4+qvxp4+88our0MzaEwfJ5DTAOldQSeK0xoOuRcLLeiMNhd+AkJEyp1viCWmRsEzUK+BvwZ+Bgo3wf4Bn3fxsXYT38iStfGLGG9wi0cU2EdfEaV76Yhnlul1QBdnDmySh7/5rA+VXLJnfEyiKaJqhTVaS8WQnaqNqCdy/5ZdDO7mtoyEXQRmLCkzzSfwy0lOCXCQf/Hwk2ix4ZU4ACjgdmEQ4y+dAdE0fFnGs9cqAAQWvf4UhM+lHAfr7fy0sBPDKuAHf5fsotrjVsCNysfrzH91NucYMa6wcBxqgfn/P9lFvcY83231M/fkK67+g9tgxtkFiN4FhfBOKq9QFGzJhHrqBd3GqRa2cAbjMKbyP6TtsjO6hC7g5ivbK7YhNEvYJ4svYFDnFyqJfUy8EIycdQ4A/GuH7uxrIehriCOBv+RuQix0u65VPiTfKjoqaLUxDvVU+lll+5LG69OImw166XfMmlUYM/xHdO2UhoCegCrDUqvopE/ByCRKz09JIZ6Y04nS6KUILDggow3agwg+y5bHmEUUH4EqgW4Q3crmAIWusNQbnHrWqMNxcMQYNUwWf4O/w8YtcoU7DmCV6I7c3qkX3MwohW9tfB5QPzOngqniiyXKCJIueBdwkrJ2wTn8A2iFPoMYhTaDff7+WhAP2QxARLqIuQ/QzJWPEsEkLu3cJzqACt3MYxKgwsKK/jGUNzpQDtCIdEF5OGxrR7pFQBWhAfHLoxZlbYjIRKZwHFYu8rcSbVrWhjO4qHeG+fNgUYg52XbgrikdIB4QU+izAxRGE5SDM5RBVCcr0CIYNsZdTpj4RpvwWcYJQ3R+5UViDxkztEtLEUeBObN7EKYWRdAczcyn1UyRSgDfBfwvSvR0TUb+mMDloJhqdYAS5W7zpelbemPlnmR0B7Veci1cZVqnxX6nMnrjbaGKXauDoNCnCuMaUXi/ptgvgYBp97IsH02Vj4qXrXWap8T8IUuJr/+CZV/jNVvhdhNzx9D6PHpyYNCjCTLeP91fSr65CkEmlEd+qSaa42ZrdKYILb52x2A6OVuaeb2gsz5GHG2h9sY7qxLB5I3SXOfzCcObe1AlQg4d6J3IwUuiGBJ1mhieuA+EnGMZv3R0Ljo9AJOLVIG0cjtHBxbQzF5flrbAVogtwYeqLIMj0GVlDHdRe1uYmbVrXTac8MdWBHhOTp9Ji9y/eRK/Z9I8o7u/JTiiyVYxAyaQvVro2TG2sPcLt65i8JX+AC9dwqYLeMDP4uCENY4d1vMuoEd/0rCKfHaUf9JN3XG21cFSj/t1O6INoDywJ1Lm8MBbA8iEcm+Hr09D87Q1//sYRJHjXb16sYHjcBaO7/lcbfeaPI8noGYbq9bU4U2QLJ/aOPgsMiLFrd3Syhleb4DCnAvmoDe5/R8cEAzM8IE2f2oj5X8r3G37lTtaH5CA9BaGYLde6gkYgih2Obeee59e077qsZTzj6uMCDmzUMRPiC7wZ2N8pbI0G184mmwhvkymcAbSOMbIU2BsfMwPOdsuzSGEtAlD0gqazCJ43K7ClAG0NmNXDwlwNf82ORDwUo4ArC+YAs+Y3/8vOpACB27SuRdDJvIsEmq4EXKE26E4+UK0BwWWjvvvQ98SwjZacAHhlTgKl4oshywbUYMaAT1Y/3+n7KLcZjJMO8lHAOmia+r3IJ7ZVVA+FkSLVkN5uHRzSqCXswDQMxJa4gnAp2J99nuUGlW+81I+wX180WkeACpzUe2UYn5OJKj2+9KPCdCaeDr0WSJ9cA5yFXmV6yIUOBc4BJiC+iHte1hH0VONhYCrzkT9YRk4H868SzhXrJvpwUt16M9R2Ue5lBRO7DMTEPfYD4oS1DLnq8pFuWAe8XUYJ6OCyi4ly3LLR3x0Uv2ZF2SMzFnRFjOzB4RpxjVLjIn6BygyHU9yOsRa7pq0ASHmt68Wm+z3KHHxsf+ZEQzke/FgmJ8sgXmiOpe4NjfaW183/C91VuMUON9UyAyXiHkHKBJ4osc+jZ/iHwLmHlhOsJe2mXXAH6IJnGRiM0KyciVCgeOVaAFohn0euECSAKUa4zgR5+DPKnAPuRnCtwPcWjiD0ypAC9CLOFJZHr/VhkXwHau6ndGuB3EefSpYRNkAU5NQMdVoVYSlvF1OlMPHdPc4QbqWWRNvYq0sY+bD3XckkV4A5jUJch9Ck7Ip7FVUgqU+uu4W0kFDqtaIuQXG9wymwN8rluz/MJQh2jM620Q/iUNiB+lpoRrQI4P9DGJUYbuwGLXRuLCTOGNIoCVBtf9mvuP5zUCFHrOi2tGEd8wExbY/nrXKTDp6jyDmrTvJEwL5D25Z+WBgUYbWzukuzwNbnUIjdLpBHaP6LGWAJXqTqdVJ0rVPkEQwE+DpRvMBRgbJE2GkUBZqtn5iR8gWMIM4d3SakCtEUindcAf8IOax+BkDeudDYPjOn7SdfGooh1/kzEF3NlxAmpg1uK1gDPsHXEmiVRgO0QepfgM+cnfIGuhIMTeqd8I9iDeDrbjkgUdBQqErSxR5E2Cu+xteTaJVGA7QnnpE9K+twJ4QyITGHqkY1j4CNbuC4dRNjruHuGOrCPW+4mYkdONUcicOcSzYDWF7gf4Rm0uBNaATci6XcGRLQxwL3HjQ08GpZMASYbx78km7kb1XNvIkEpWUAXhBI+SBOnMZV4ird9qcunZDGQQ/07+02EmVT3UyeHGpIn+iyZAlgBpcWOJ0eq/3yB4y4rOM5Qek0U+Zqqc6Eq/zKIIv/egL1BSQ1BLxpKMNGwBTRFuPEsk3GW2MI6Uj98biJhgsbLA+XvEOb+35M6+ngrCYU+9q00joXVSIaSQp0xjTEDAHwb28S7zC0RI52hZ0FEvSwykezjZrqRMV/dCNenUaebr7r+OS9i4CqQNDvTYmwrB7jl5rzG2gRGGYSSymI8eVSmTwFBXNXAwV9AvMnYI2MKAJIx69kiA7/SHZGa+nHInwIU1q6B7nz7MGL6fArJUX8m8dedHjlQgCAqnYGime/z8lQAjwwpwFQ8UWS5wIwL0Fox2/dTbjEJgyjqbMOQ09L3VS6hr/EngOTt00e2k31f5Q59CGdzHwQS1KEvMd4mbMf2yC7aE85o9j6BlH0jsFO7nIDccXtkE5UI7e9LxviOC1ZsBjyNbcFbhGSxmuQlU3Ir8PuIMf0XRraxjsjdsqdSy7e8R0zC7mr3xfuOyqcsQVjfYlGFcMcs9x2WG3kfcWBpSJJJdnfHhAmI/9ujTuZ7Sb085gx6UxBq2MiLuP8PAG9GBFgM27N/AAAAAElFTkSuQmCC";
                }else{
                    containerIcon.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAFrhJREFUeNrsnXmUVcW1h7/upqEZFMXHEhUlAqJ5MggqGBwY1OWMUeMTNUQEwUwi+JCgRsVZxAEDwYGH4oAgiiOiiQyihiCKAirweAIqCBGBIDNNN/X+qH3h3H3rnDv2Pee23WvtxaLGXXv/7qmqXbt2gf9fbeA4oC9wB/CXQqQSGHUOTBwJs2fBkmWwZjNsL4fdBowBUw67N8P2ZbBmFiwZCbPPgYklMKpQxw3cDfwO6AQ0IIO/k6WR14GPgf8Flsm/kacu8M04+Pd6qIgpOl1aDxXj4N9d4JtCGbfoaBnwKfA2MAI4Ox3FtwImA9sBU0hUBOZiMHMzVHgQzZW2iwpMJh76u3wNAv+6YNFecAM8EcyHVaB4TR9KXwUKgm1ALz/ldwI2F9qgSsHcBaYyBeVtAjMbzDipM1ToLkmbLWWStVMpdUoLFwiXaOU3knlDF9wCPA30Ay4T6hkV6gT918LSIGVthFXTYXJfGFIbLk/WZm24vC8MmQ6TN8KqoLbXwtJO0D9KMhEd/RfQB7uI/ZdDr5tlqt/7d4uj0D+AY9NdORpjMqP0YdzSwMoABU01cFoOfi6nSVt+/awUXrLrJ0U5ZfDXFJji6PJ/YgUOcMz7nwEHZtJbngDQ0sBqH4UsMdCtCr6b3aRtV5+rswZB1QEAoBh4S3W5HWgBcKaDn66Z9pQHABxk4GsfRTxqoKwKJ88y6cPV99fCWxQBAHAU8KPqtjfAAJW4ACiNKABKDMxwCL/cQO88rqJ6S5+ajxnCYxQBgNh0vN2OBLhXJb6QTQ9VDIChPsrvEcJSuocPCIZGGAD3q24nIijwJj4dUQC0MrDTIfB+Ie6n+jn42Sm8RhEAd6hu3wB4RCWOjygAXnUI+4kIbKqfcPD1akQBcKfq9rUqAQDQGGgJHAHUygEA2vtsvxpEAAANfLaj7X9qAGgqn5hpwGLgO2Cl2BMeB07PAgBPOwR8aYRMa5c6+Hv6pwSAocCaJGPcJYdMR6YJgP0NbFPCXWigKEIAKBKevDxuE96rNQDqABPSlNdKoEMaALjE8evqH0EDe38Hn5dUdwCMy1Be64CWKQJgrBLqbgMNIwiAhsbjZCI0tjoDoLfPWP4GXAN0B3oAYxwWKAO8myIAFimhvp8vpQLXAbOAm3FMOcAxYjd5A2gnvHl5XQQMAuYAfwKKfdp4GXgFaOuj9EHAB8AQMeuGDoD6wFeOOb6vzwDaAV84ZNwjCQBqOYwtI/Kk/CtU0vUqv54scGNJy36EUerYuKJWfBv9VRv1gXmepIVAQyW73yg+ro0CAK50yOy6IDuA7BJWqzovJgHAEY55tXeeADBKJb2s8puLg8Xe5Hlwk+b3CHUCp9o4ytH1cUpuY1T+U1EAwBOqzvxUDEHA9are90CTAAC0dQDgvDwBoDuwVf5biVrQyXnJi16Xq/Vwkea3Hez2tNFDtVEbeMmT9CZQpmR2Fvva2A1cGAUATFN1bk8RAG2AclW3bQAATnYAoGse1wDdgIfwAR2wP3AjcBvQSHiL4/deGCheukFtDJV1RiMfuZ0pejonCovAUjX3GfE+SQUAzYC1qm7nAAB0DRMAGVDm/BbQLqAYmK7q/HeKAGil5829NoECAIB8ss8BOmXKL1AXOA843g8AQHvgfKC+DwAaSBsdwpoCxjtcjlMBQE+Hb1qzQgCAKG6q/LccxynkXXBrEL+iuHfkvzuBqzUAZIEd+5HMBPZTMtxf0mM7r55hAOC3qs4e4Nwku4Ay2eZ4672997Ao+gA4SyUtBup4E853u4x5AXCZauMrBwA+U2V6KTn+2uG+VyvfAGgCbFD1NgKn+ii/ATDJIde+SbaBUQLACSppOlDqTbgUZicBQBfVxiwHAN5UZc50LAi9+a+nYRzKqSVwmENO27HXyU4Qh8Njsa7YnzrKLgbqFQoARIGDgS+Bj4ATdf6r0CuFNcBNMvYPgQ4OALQB3pMytzt+TEWy61oMzE3TczunAKgv5kk/eW3w7F817Qa6pWAKjtwuAKid7S5ATx2uXYC2Bzh2AWVROAxqJL+GdGRYrue1mm1gYfsDNAKeS1FGS4Fz0/AHqAFAAXkEXQA8T+Ilkx9lmzjYta+tAUA18wkUa19n7J3004HWWfgE1gCgEJ1Cc+gVXAOAEADwVA0Aqi0AhjlsCDykEp+tAUC1BcDdqttXAG5ViR/UAKDaAuBZ19f+IpW4A2hbA4BqB4DG2Lsa3m4Hxly1NuK4M1YNAdDQwFEGTpJ2LhTqKmlHZelxHGUAjHJ02z6W+Zgj8zE5eixEANSRyB6D5YbOHAMb0wgGtVHqPC1tnGpc5tvCAECZnB0keGV7C7XEHSBqATYGTnego1CnfNFY+J0W6Nh9wQ/j6Hq45GMYvQHmVbpvEWdFlbBzA8z7GEZfBxdny28V04nYIB+9gPcdet0juoz76ykZQTb8cjnIyQt1cwR57AYVsfxGsHsQVH4Ge6o6PJymz2DPIKhslAa/eaRdST44g4PcvSujsqbq6hB8VzBtwDwJZnuele6i7cJL6wB+I7ZWHRI0X1zu8NqNFAAWpamgjRL/70kwN4K5HMwF0nZ7oa6SdrmUeVLqbEyzr0WFAYAb/ZTfM2q7qq4Z/CLXgXkeTG8wLXLAQwswV0ub6zLgp2s0d6wJU0ALYJOj4CLsjZ+O2Mjh7fJJE6Bvigu0bathyiTof4Dd2lQJPwdA+0nQfzVMqUy8su6kCTbaersQ6ATgauy9RBcITvIC4C+OAmOx99/C2ga2NPBREgGvNHBDSLeFG0rfK5Pw+FFKMQSrbhtY5DgEMti4gSUxQ9CmiBmCrjKwNUCoKwxcYRy3bUOgYuFlRQC/W2VMYRqCRqsuK2OGoItVRgXQOiQAlBp1w1bRBgMDTbBfXlhUW3jbEMD/KKM8ifMIgP/wMwXrOMEfymcj3wBoaGBmgPAmGGhcAKG4GwuvfuOY6Zyy8nMY9DyOeMHhHwdDEwMLAsyyFxZgTPYLA8zPC2TMkTgOHkmYgSKhqbE3ZFyCmmPg8EINyi/xDeb4jO0rGXuYgSJfD9clzH4uv/AR0LMRneszWRs86zPGL/ZOa9XIKbSxOIWeK06hx/gov76B+T6Cua0aKF7TbT5jnW+CvKULCABnYh8mWMa+B6cqsC9WzMZeIa8vyi8x8KaPQAZXQ+XHaLDPmN80UFKoANhPFo67U5DBF8DpBu71EcQN1Vj5MbrBZ+z3FiIAmhAf5SopnZ8YS2+fAKq/8mPk9wM4r5AAUI/gy6Hl+qvQBMwG98BfjFjoV+9FzlpJ8otJ8kiEo40iGbPL0NXER/G1ogaAW3G/S/eIeKQ0BY7ExrVbCJjX/PfE9SKo+DJskOtV2GCQ+/kEjViMvQ73S5+oImOljeewC99Yfj0f28drjsAa46SNZ7C3skMHQGNgPYnhX0/2CxBxPczTg90de1whs1fDqhoAg1TS/Sq/IfHBMrcAh6oyA1Ubf1bS77TN7c3U0yO7waqN26IAgN87Dhb8Q8RAgz2wRg90qF0UlkQUAA+opOdV/s9IDIHbUpW5T+X/VQebvMYNgO8MNBAAaP2MiQIAnvHzMPUBwD16kH/fFyTqiIgC4Fj2Pab5PTZmoZ77h8s6p1IUU6LKtANWeL6QJ6n8EmD4u24Q3CMA6OA5xPnW5cyZbwAUYa97O92MHMo/RMf73xHvrdMhigAQBTUVP8mWSYJHXRCQ3wy4KqiNK6FPJexyvDdwiCe+Yi9x3Al9EVgqJ4apBYqEkRrdd6ceKPKnRHc7vgIjo7gNLGJfrLu9ixsnAOxDitu9g1oPpmF83XaFAgDgcGyQp6v9tn7ApXLE/nOf/CMl/0qHh9F6r6z2wA4DBzkA0ErauCKsNcDjqs4nPgBIeOdvSHy9fyGfuTwqsqmB6wy8ZOCfQi9JWtMA5R+EjRAWS7rPUca76l8FHKnymxD/SPddcaeBMETLaxXcpwBwKLDc08afwgCAy4N4QBwArKtU3Ovbm2GP+vVPyuLx6HRpPwOPGcflDQ9VGBhj3Hv+81TSV6jrYuJEG+dxo/J17P/VCgANt0Cll6ct1qeg2AOAPiSG28t7oMh62Ld/9FawLzFm4Uwt4AcT9XJBngDQ1CR5Zl7RUv01AH6OvTkdS3pBW/iIv4BZgb1T6M0/jvhYyRO0P8CL8LmDnzM9AOiIDTMbq/oEIQWKvMZH3q8DV34F7+qBHB1fbmaWz8en88tPR/leEOynFNgDGy/4aeAwx1eiIfZS7VRs0EjXVHKx5I8FDtYAeAV+4eDlGbUG6CltjJOpKbTDoGdcMi+1n/u4Qfwjce5vmScAjAlwNZsm5Oe6NSZva5N4WWgvos0GSqN4GljscDQ03R3CHBD/bNwvsng+Ph06zDHn7zFwu7ruXUfS9jjWBIeFAIABDjB2j7JDyM143gN62AGAZnvD6apfftUCYECa3kYur50BIQCgmYOPh6PuEdRc9qbTFqj7+avgB+CcHDwfny5NUUL8IYmfYW0p460zJe8AsPLQL5HOKwifwC/tY8r6szs6B6+HZ0JzE45ak9d5TdWZGxIARjumo3qRB4CBUxyfr8tCAoA+bx+fQp3xDn+FMABwmUOOp1QFAEaSy0CRcK2D8eY1AEgbAM0dcrw2SwAMw3EHdIRKnJAlAPThz3avJasGACkDoFifoxj7Y83m737V7cvIUa5+g6Y0CwBMVUx/mkWUsJ8uAKxMPlW8TM0SAK+4nEvOcvDTLQsAfKyYfqMGABkD4A3Fy8dZKL+Vw4Opb+yUa5XKmA8cmCEAtOvX4zUAyBgAjyte1mSo/GKZ73VE2KNiBVyBBKcLatIFwGbF9J01AMgYAHdqk3AGym8mB1e6y7hb4I1IfA7eYB9PHgP8QY4yk5Jeub5jFxq/CYPWwzdeXhbaewyBdRbCB8qB5Zuw+H/HvlgeJ88U6/bCBqh8UHwRtV43iWNK3N+JjqkgfSArGhiiE88Cxcv4FOqMV3UWhMj/QIc8c9DuZgJeID+F4GihNQAofABcHjRf3JHrL8AtNQDImG6pGgCMxT6CnfB3a0CljeKHtlz83H1J33R51M43K8KgL5Wr9SR7eyewziTY4q3zpY27Gwr/j8ImLy/b7Nc5lbrLsQdwQSCI+zvJp+BLMi0cKtvFpFSpFl5b7WrzoDCoXEUf2QoTk9XZChO9dcrt7aVQ+N+qIotU2gVpqvWbYC+VjPPRbQ/vHnGyo8DADO0AOrjjtBC3gToCyaQU6kxyRPAIaxs4TQedzNAO0FP5ERqsUakM4GgSw4s/moUlcHKCb114AHhb8bI4hTqLVZ23QwSA9mWcnIUl8AZHt6dB4nv0m7BXojIFwHDF9O6YP1sIAHAFYjg7oPzZoQWuSJRHqUkMpjE8CwDUxT7d6+32FtfK/50sTwNdT6i3DQkAJzh4WWfgeEfZ4yVPlz8hJAC0dfDSK8vDoLGq22cAHs6xQ0g7B+P9QgIARln2PN41Ewz0F5rgc2Hk/VC8gq08+jn4aZclAPIQKNJeltiaYIMPDwD/6ThXT4W2S92wADDeEXC6VpYAuKPqXcIs8zMU86tDBADGXt8uT0P55SbgyneeALBa8TQjB06hd6luX805AIAur8Grrs9XiADA2AAPy1NQ/nKjgkGE4BbumkZvijIA6oln0RfAjg4OwY63gaLahAgADNQVn8UZ6otQLmnXShlCBsBdDgB0iCoAWqNiBRaB+VYNYJlN3w4MCBEAOlTbwULhh6jbJ4ciA8uU8r81UBRFABxHYrQwA5iHHF+BU7334sMHQLRonxxOdfz6H8pRhJCcAuBQ4Guf8azt6LiROzG+zFVRB4CYSo/GES9ARfxoEZBfFzgGe2EmqI3mIoeJWm7Lra/G0WQXIzDnAHjCMZbl2PAp+wOllfCJdyAVYI7YV/Y7oHFUAQAcjA1yvVM8pVs4yvxefOt2YEPHFDkignwobczHvh/gzS8C/hhro7Od++PsEbts33OljbnYMDWhA6CV43Dhc3SYU4eL2Oj4OjdFGAD3qqSnHADR058OCaMF/ogjCtneoBN/VdFBDJh7rCt4Ts5pcgmAoarOdqANiavZ2hL00Hu86v0KzAHKIgoA7R8xRuUfio1z4E1upsrcrPKHOwCwFZFJuSNgZINE693wKABgkqozOc4QFA+CgQFrgV1AiwhPAdOADcA/ccT5w76s/i32avwgR/4h2CCaGwTszR1l+gGrpritlQMFJLOljfeAI8IGQAkwU9X5YwAA6uqvgNoRnBDlXYB82UqShI77WUB+UbI2/ga/8gkXW9ez+m9D9qbgnACgFolv0l/jCwCr3N56gEvA1LF1T/qJbwPrGFjiAEDvKngvIGdTwJt+85IPAIodV8bMA7busQUUKLKLTHcjgAN9tnzDxJXuAp82ugMvYgNJ72/gAS2Xb2BNiT2pO9sHAGcLH/ekuTXMGQAedmz/ynwBYBXcoVI5jO4BsxguKgQAYOP0bvEkveAo4z1ZrQBOdISai72nZH4N03VcokrY02Ffld2oMxSxvHrD1Y0h9Yc+cwYA14XSR4MAAJw2wv1czDpTAG8DAuc7QK8DRX6uylzvFyjycHvrqNKxTdZbyz5KjjpQ5JI01gY5NQTNd8hphLYFYH3QLwbW1wHzWdDTadEGwOHEX58bgXq8Ghu2NfbfNUBrxxsDK+qDme+Ww2f7x2/7VgNHKXm2wnoHx8rcGsYXAOAMH1ktlyligFjHpnvzj7HhT12Df8skeZ8nAiA4Wr50A/DhVbaGj+DjSnYwtFngfml8i7Em4yJsJJBHXaen8tdepps/hH0YNDQTWfZJPO3yPhBdUo1X/CXG/2HpX+Xh2bgqOQ7+c5pymI59OHnYTwwEQcq/PU8vh1aZQ8gvxVoVJIPVskWq7Tn3Hu8jkKkmgi+JZUH1ZIpzjXV87Ky/kAEQs3j1kP3tG2L6nIl9o74frkhh9lfxio9gPgmK319A1NSoU1EVhLLEBG2fCwgAew1B2Otm9YE6KTiD1g4AwfcGuhew8rvLGFxjeyUuaml1AkDaZH8Fz/gIao+xb/bVKTDz7v3G/RqYkbGWJL0alicAjCSXgSIzAcC+NcGdAd66XxroXADK7yy8+o3jTqcPYn4A4LwXoFExKSQAxOgyx8USLz0b0bVBU6OuczsudlyW1uXQ3APgQRyBon7rMOQ0CBEAGDjWwKIAYe6QiKRNI6L4kcKTH7+LZEyEDICZrkO8zg5+rggZABgoM/CwcdjLlT//cyFNDZ2l76AbR5UyhrKMrofnFgBdUK+5i4meeo5DjO/k1ClMAMSoo3G/sq1piYFbjbK/55haSx9LUuBngfCeeXyA3AHgUBJfNPtBPJb22q81TyvFwFM3ZADE/AmuNbA2xbt93xrrxNnHQBu5a5+uskulbh9p69sU+14rvBZnHSAiewAUY8P+furo8l5vwTrALB/e5mBfwnowbDoARj4F729RbxEnowqoXAsbFsKKGbBoCsybAHMeh1mPw6wJMGcKzJsBixbCirWwoSJ46kmgLbDtKXj/ALurejACNBqY4aPT/8Px2tjhcrYc+Z1WGZh+jjBwYdAC4aWscOxT67DBo3z9/ecUkrGtI5hRYNbkUelrpM+OhWecXEYKr46UYWPHrCykwRWD6QRmGJj3wezMocJ3SpvDpI/iwlP8D+LAks4jkxwm24Th2GjTbwlNLQQqg2lnwAdDYOFzsPw9WLsUNq2DHbsc4WB2QcU62LEUNr0Ha5+D5UNg4RnwQZm9HzC1gGiaGPQewYaGbe6n5P8fAHlhpzdVicuYAAAAAElFTkSuQmCC";
                }
                containerIcon.dataset.isunlocked = containerObj.isunlocked;
    
                var containerTitle = containerItem.getElementsByTagName('a')[0];
                containerTitle.innerHTML = containerObj.name;
                containerTitle.dataset.isunlocked = containerObj.isunlocked;

                var folders = containerObj.contents;
                if(folders != null) {
                    containerIcon.classList.add('enpast_tree_parent');
                    containerTitle.classList.add('enpast_tree_parent');
    
                    InsertFolderInTreeview(containerItem, containerObj.id, folders, containerObj.isunlocked);
                }
            }
        }
    }

    function InsertFolderInTreeview(parent, containerId, folderArray, isunlocked)
    {
        if(folderArray == null) {
            return;
        }

        var childs = parent.getElementsByTagName('ul');
        if(childs == null) {
            return;
        }
        var ul_folders;
        if(childs.length == 0) {
            ul_folders = document.createElement('ul');
        
            SetStyle(ul_folders, {
            });
            parent.appendChild(ul_folders);    
        }else{
            ul_folders = childs[0];
        }

        var items = parent.getElementsByClassName('enpast_folder_element');
        for(var j = items.length - 1 ; j >= 0 ; j--) {
            var exists = false;
            for(var i = 0; i < folderArray.length ; i++) {
                var folderObj = folderArray[i];
                if(items[j].getAttribute('data-folder_id') == folderObj.id) {
                    exists = true;
                    break;
                }
            }
            if(!exists) {
                items[j].remove();
            }
        }

        for(var i=0; i<folderArray.length; i++) {
            var folderObj = folderArray[i];

            var li_folder;
            var exists = false;
            items = parent.getElementsByClassName('enpast_folder_element');
            for(var j = 0 ; j < items.length; j++) {
                if(items[j].getAttribute('data-folder_id') == folderObj.id) {
                    exists = true;
                    li_folder = items[j];
                    break;
                }
            }

            if(!exists) {
                li_folder = document.createElement('li');
                li_folder.classList.add('enpast_folder_element');
                ul_folders.appendChild(li_folder);
    
                var folderIcon = document.createElement('img');
                folderIcon.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABPtJREFUeNrsnF2IVVUcR5dajaVhRUSZGNlDBBrljGRlCn0RwfRQ9lA0lT0UvUgfMJrVSNPXQ0xhFAOGNcEYGUHTQxlGPiR9IFmRWk9GUYEVWUakps70cE403fu/Z2Z0Yu45ey34McNlHzj7/Ne99+yz974wdiYB5wLzgQtLkvnAXGRcOBZYDvSULI8Dx1u+o2ca8B0wVMKssXxHzwnAxyUVYAhot4RpC7AbONMyjq8AHwDrgJebLOuATYEEA5ZxfAW4tYnPtwXYHEiw3FKOnwC3N/k5zwJ+rDnnA8ACy3lkbKm5mDeU4JxvCT4FvgCmWs6Y6cBCoDV/kPLPg59LgO01F/IR4IJh7SYqlwInF/TpxUCCZy11zKL8Ah0E/spzIP87WHMRDwH7h7WbqAwBW3N5G0m9M5BgqeWuZ0mJh3q9Bf1aGLT/CZhtyf/LZSUWYKR39QNB+3eByZa9sQCDeQ4P+79Zcjgo6B7g7IL+bQyOWWHZGwuwJ/9amAOc02SZA3QFBd1Y0L/ZwdBwKL/JlUCAn0e4w24G3gkK2lnQ/vqg/U7gFMsPFwUCzGzycz4d+D4YoSwqOOb5QIIvgbfy+4Kq5j2gu+hiXhwIMKsE4i4NCvpV/gQz4jjg85Lf8B5ptgB0AK8B64dlLfWTKPuBN/OHKesnMK8C/UBbgQS9QWdfKGjfBuxLUIAB8gtTxpPfVfBd3QJsC47pKJBgeaoCPFPiDvQVFLQ1aP9LPmpoxB3AKuD+CubO/Lu/UgKMNBN5T9D+fbJ1jSny4GgE+AxYCTwErG6iPAw8BvxZc75/AOcVdHogkGB1ogJ0j0aAtU3eiXuDgm4uaD8T+CE4ZkmCAtw3GgFeKkFH3ggK+mhB+2upn8HcBdxGtk6gI4HcHFy3UIC+EghwKvBNIMHVBcf0JDrWH/MooK8kH2ftQYe+Bk5q0P4YsrUCFr4iAjR6V28oaD83v2m0+BURYArwYdCxuwuOWZZ/UuwgWxOYSrZRP/tZegEAzuff5WDDh4bzCo6ZTrZPcGpCaQGeqKIAAHcFnwKf4mbQWrqqKgD5JFGtBD3WfOxPAssqwGnAt4EENwIzyBazpJxpwFNVFgDgCurXB+4jm+/fnni2kq1+rrQABDc6psLDwIjJZLuVLXCiAkD2G0a/WuB0BSCf/IgWhNyUzxlcl1DaydZ4bkhJAKjfDHqIbE1BqqxMTYAZZCuCo6FhinSnJgBk+xtqh4a/Ubw2UAEqRifxZtBJCpCGAFOIt411KUAaAkD203C7AwkWK0AaAkC8bWwHcKICpCEAwNOBBP0KkI4AAJ8EEixLoN8rFCCjjewHr2p3P19DtsKotYKZR/0+0GQFgGzdYPR8/HeyKeSqZS/ZL74pwDBex8mgpAU4g/pFEgqQ2MORBcBHCpCuAJCtHj4rgaxRgLRZpQBp44MgBVAABVAABVAABVAABVAABVAABVAABVAABVAABVAABVAABVAABRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAWQ/1eAXq9TZekcjQCbgMuBK4GrTGWyGOgfjQBDwGDwmil3DgavNRTApJEBgOe8EMnmbYAngb0mybzy9wC3Nfyyd/s32QAAAABJRU5ErkJggg==";
                folderIcon.dataset.container_id = containerId;
                folderIcon.dataset.folder_id = folderObj.id;
                folderIcon.dataset.isunlocked = isunlocked;
                folderIcon.classList.add('enpast_tree_folder');
                SetStyle(folderIcon, {'width':'20px',
                    'height':'20px',
                    'margin-right':'10px',
                    'vertical-align':'middle',
                    'display':'inline'});
                li_folder.appendChild(folderIcon);
    
                var folderTitle = document.createElement('a');
                folderTitle.innerHTML = folderObj.name;
                folderTitle.dataset.container_id = containerId;
                folderTitle.dataset.folder_id = folderObj.id;
                folderTitle.dataset.isunlocked = isunlocked;
    
                SetStyle(folderTitle, {'color':'#292929',
                    'cursor':'default',
                    'vertical-align':'middle'});
                folderTitle.classList.add('enpast_tree_folder');
                li_folder.appendChild(folderTitle);
    
                var subFoldersArray = folderObj.contents;
                if(subFoldersArray != null) {
                    folderIcon.classList.add('enpast_tree_parent');
                    folderTitle.classList.add('enpast_tree_parent');
    
                    InsertFolderInTreeview(li_folder, containerId, subFoldersArray, isunlocked);
                }
            }else{
    
                var folderIcon = li_folder.getElementsByTagName('img')[0];
                folderIcon.dataset.isunlocked = isunlocked;
    
                var folderTitle = li_folder.getElementsByTagName('a')[0];
                folderTitle.innerHTML = folderObj.name;
                folderTitle.dataset.isunlocked = isunlocked;

                var subFoldersArray = folderObj.contents;
                if(subFoldersArray != null) {   
                    InsertFolderInTreeview(li_folder, containerId, subFoldersArray, isunlocked);
                }
            }

        }
    }

    function InsertTreeCss()
    {
        var cssForTree = "ul.enpast_tree_root li {list-style-type: none; position: relative; margin-top: 5px; margin-bottom: 0px} ul.enpast_tree_root li ul {display: none;} ul.enpast_tree_root li.open > ul {display: block;} ul.enpast_tree_root li a {color: black;text-decoration: none;} table.enpast_forms_table tr td { padding-top:5px } ul.enpast_tree_root ul {padding-left:40px}";

        var treeCss = document.createElement('style');
        treeCss.innerHTML = cssForTree;
        document.body.appendChild(treeCss);
    }

    function SaveNewEntry()
    {
        var url = gEnpastSaveUrl;

        if(!url || url.toString() == "null")
            url = gHostName;

        SaveEntry(
            url, 
            document.getElementById('enpast_save_entry_entryname').value,
            document.getElementById('enpast_save_entry_username').value,
            document.getElementById('enpast_save_entry_password').value,
            selectedContainerId,
            selectedFolderId
        );
    }

    function Close()
    {
        // Close dialog
        this_dialog.close();
        document.body.removeChild(this_dialog);

        // Mark a flag
        setTimeout(function(){
            SetDlgOpen(false);
        }, 500);
    }

    return {
        Open: Open,
        Close: Close,
        OpenMessageBox: OpenMessageBox,
        ShowWarning: ShowWarning,
        UpdateContainerFolderList: UpdateContainerFolderList
    };
})();