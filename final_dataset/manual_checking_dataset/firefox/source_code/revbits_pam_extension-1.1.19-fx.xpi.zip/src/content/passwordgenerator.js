var enpast_pwd_gen_input_id = [];
var enpast_pwd_gen_input_class = [];
var enpast_pwd_gen_input_position_new = [];
var enpast_pwd_gen_set_new_width;

var enpast_pwd_gen = {
    ib: 0,
    input_position: new Array(),
    input_length: document.getElementsByClassName('enpast_ext_element_pa_ssword').length,
    init: function() {
        enpast_pwd_gen.add_event('load', enpast_pwd_gen.onresize_new_style);
        enpast_pwd_gen.add_event('load', function() {
            setTimeout(function() {
                enpast_pwd_gen.onresize_new_style();
            }, 150);
            setTimeout(function() {
                enpast_pwd_gen.onresize_new_style();
            }, 750);
            setTimeout(function() {
                enpast_pwd_gen.onresize_new_style();
            }, 1250);
        });
        enpast_pwd_gen.add_event('resize', enpast_pwd_gen.checkall);
        enpast_pwd_gen.add_event('click', enpast_pwd_gen.checkall, 1);
        enpast_pwd_gen.add_event('scroll', enpast_pwd_gen.checkall, 1);
        enpast_pwd_gen.add_event('keypress', enpast_pwd_gen.checkall, 1);
        enpast_pwd_gen.add_event('mousedown', enpast_pwd_gen.checkall, 1);
        setInterval(enpast_pwd_gen.checkall, 2000);
    },
    checkall: function() {
        enpast_pwd_gen.check_if_new();
        enpast_pwd_gen.onresize_new_style();
        setTimeout(function() {
            enpast_pwd_gen.check_if_new();
            enpast_pwd_gen.onresize_new_style();
        }, 140);
        setTimeout(function() {
            enpast_pwd_gen.check_if_new();
            enpast_pwd_gen.onresize_new_style();
        }, 640);
    },
    position: function(object) {
        var rect = object.getBoundingClientRect();
        return {
            position_left: rect.left + window.pageXOffset,
            position_top: rect.top + window.pageYOffset
        }
    },
    get_style: function(object, style) {
        return window.getComputedStyle(object, null).getPropertyValue(style);
    },
    padding_right: function(object) {
        var current_padding_right_px = window.getComputedStyle(object, null).getPropertyValue('padding-right');
        var current_padding_right = Number(current_padding_right_px.split('px')[0]);
        var current_padding_left_px = window.getComputedStyle(object, null).getPropertyValue('padding-left');
        var current_padding_left = Number(current_padding_left_px.split('px')[0]);
        var border_left_px = window.getComputedStyle(object, null).getPropertyValue('border-left');
        var border_left = Number(border_left_px.split('px')[0]);
        var border_right_px = window.getComputedStyle(object, null).getPropertyValue('border-right');
        var border_right = Number(border_right_px.split('px')[0]); /*used if input does not appera correctly*/
        var inline_padding_right = object.style.paddingRight;
        var inline_width = object.style.width;
        var get_current_width = object.offsetWidth;

        var get_new_width = object.offsetWidth;
        enpast_pwd_gen_set_new_width = object.offsetWidth;
        if (get_new_width != get_current_width) {
            enpast_pwd_gen_set_new_width = get_current_width - ((get_new_width - get_current_width) + current_padding_left + border_right + border_left + current_padding_right) + 'px';
        }
        return {
            current: get_current_width,
            thenew: enpast_pwd_gen_set_new_width,
            paddingRight: inline_padding_right,
            inline_width: inline_width
        }
    },
    enpast_pwd_gen_onclick: function(enpast_pwd_gen_class, enpast_pwd_gen_id) {
        var get_class = document.getElementsByClassName(enpast_pwd_gen_class);
        document.getElementById(enpast_pwd_gen_id).onclick = function() {
            PrintLog('clicked enpast_pwd_gen icon');
            for (var i = 0; i <= get_class.length - 1; i++) {
                setTimeout(function(){
                    PasswordGenerator.CreateDialog(get_class[i]);                         
                }, 200);  
                return false;
            }
        };
    },
    generate: function(add_letter) {
        var charachters = 'abcdefghijklmnopqrstuvwxyz_',
            m = '';
        var rand_split = charachters.split('');
        var rand_number = Math.round(Math.random() * 20);
        while (rand_number < 12) {
            rand_number = rand_number + Math.round(Math.random() * 6);
        }
        for (var i = 0; i <= rand_number; i++) {
            var rand_number2 = Math.round(Math.random() * (charachters.length - 1));
            m = m + rand_split[rand_number2];
        }
        return m;
    },
    evenodd: function(number) {
        if ((number % 2 == 0) == false) {
            return number + 1;
        } else {
            return number;
        }
    },
    create_new_style: function(object, left, top, width, height, margin_top, background_size, z_index) {
        document.getElementById(object + 's').innerText = '#' + object + '{top:' + top + 'px !important; left:' + left + 'px !important; height:' + height + 'px !important; margin-left:' + (width - (width > 300 ? 30 : 24)) + 'px !important;margin-top:' + margin_top + 'px !important;' + background_size + 'z-index:' + z_index + ' !important }';
    },
    onresize_new_style: function() {
        for (var i = 0; i < enpast_pwd_gen_input_class.length; i++) {
            var onresize_getclass = document.getElementsByClassName(enpast_pwd_gen_input_class[i]);
            for (var ia = 0; ia < onresize_getclass.length; ia++) {
                var onresize_position = enpast_pwd_gen.position(onresize_getclass[ia]),
                    width, height;
                width = onresize_getclass[ia].offsetWidth;
                height = onresize_getclass[ia].offsetHeight;
                var new_height_onresize = height;
                var background_size_onresize = onresize_getclass[ia].offsetHeight < 14 ? 'background-size: 14px !important' : '';
                var onresize_margin_top = (enpast_pwd_gen.evenodd(onresize_getclass[ia].offsetHeight - onresize_getclass[ia].offsetHeight)) / 2;
                var get_z_index_a = enpast_pwd_gen.get_style(onresize_getclass[ia], 'z-index');
                var get_position = enpast_pwd_gen.get_style(onresize_getclass[ia], 'position');
                var z_index_onresize;
                if (get_position != 'static') {
                    if (get_z_index_a == 'auto') {
                        z_index_onresize = 'auto';
                    } else {
                        z_index_onresize = parseInt(get_z_index_a) + 1;
                    }
                } else {
                    z_index_onresize = '9999';
                }
                enpast_pwd_gen.create_new_style(enpast_pwd_gen_input_id[i], onresize_position.position_left, onresize_position.position_top, width, new_height_onresize, onresize_margin_top, background_size_onresize, z_index_onresize);
            }
        }
    },
    check_if_new: function() {
        var i = 0;
        var rem_by_id;
        enpast_pwd_gen.ib = 0;
        enpast_pwd_gen_input_position_new = [];
        enpast_pwd_gen.input_length = document.querySelectorAll('.enpast_ext_element_pa_ssword_re_gister:not(.enpast_ext_element_pa_ssword_co_nfirm_re_gister)');
        
        for (i = 0; i <= enpast_pwd_gen_input_class.length - 1; i++) {
            if (!document.getElementsByClassName(enpast_pwd_gen_input_class[i])[0]) {
                rem_by_id = document.getElementById(enpast_pwd_gen_input_id[i]);
                if (rem_by_id) {
                    rem_by_id.parentElement.removeChild(rem_by_id);
                }
                enpast_pwd_gen_input_id.splice([i], 1);
                enpast_pwd_gen_input_class.splice([i], 1);
            }
        }
        for (i = 0; i <= enpast_pwd_gen.input_length.length - 1; i++) {
            enpast_pwd_gen_input_position_new.push(i);
        }
        for (i = 0; i <= enpast_pwd_gen_input_position_new.length - 1; i++) {
            enpast_pwd_gen.ib = 0;
            for (var ia = 0; ia <= enpast_pwd_gen_input_class.length - 1; ia++) {
                if (document.querySelectorAll('.enpast_ext_element_pa_ssword_re_gister:not(.enpast_ext_element_pa_ssword_co_nfirm_re_gister)')[enpast_pwd_gen_input_position_new[i]].className.indexOf(enpast_pwd_gen_input_class[ia]) >= 0) {
                    enpast_pwd_gen.ib = 1;
                }
            }
            if (enpast_pwd_gen.ib != 1) {
                var generate_id = enpast_pwd_gen.generate('i');
                var generate_class = enpast_pwd_gen.generate('c');
                var parent_input = document.querySelectorAll('.enpast_ext_element_pa_ssword_re_gister:not(.enpast_ext_element_pa_ssword_co_nfirm_re_gister)')[enpast_pwd_gen_input_position_new[i]];
                if (parent_input.offsetHeight < 15 || parent_input.offsetWidth < 66 || parseFloat(enpast_pwd_gen.get_style(parent_input, 'opacity')) < .05 || enpast_pwd_gen.get_style(parent_input, 'visibility') == 'hidden' || (window.location.host.match('dropbox.com') && parent_input.id == 'password')) {
                    continue;
                }
                var create_enpast_generate_icon = document.createElement('button');
                create_enpast_generate_icon.className = 'enpast_generate_icon';
                create_enpast_generate_icon.id = generate_id;
                document.body.appendChild(create_enpast_generate_icon);
                var get_input_position = enpast_pwd_gen.position(parent_input);
                var parent_enpast_pwd_gen_input_class = generate_class;
                var parent_input_width = parent_input.offsetWidth;
                parent_input.className = parent_input.className + (parent_input.className.length > 0 ? ' ' : '') + parent_enpast_pwd_gen_input_class;
                enpast_pwd_gen_input_class.push(parent_enpast_pwd_gen_input_class);
                parent_input.offsetHeight < 14 && (create_enpast_generate_icon.style.backgroundSize = '14px !important');
                var enpast_generate_icon_style = document.createElement('style');
                var new_margin_top = (enpast_pwd_gen.evenodd(parent_input.offsetHeight - parent_input.offsetHeight)) / 2;
                enpast_generate_icon_style.id = generate_id + 's';
                var background_size = parent_input.offsetHeight < 14 ? 'background-size: 14px !important' : '';
                enpast_generate_icon_style.innerText = '#' + generate_id + '{top:' + get_input_position.position_top + 'px !important; left:' + get_input_position.position_left + 'px !important; height:' + parent_input.offsetHeight + 'px !important; margin-left:' + (parent_input_width - (parent_input_width > 300 ? 30 : 24)) + 'px !important; margin-top:' + new_margin_top + 'px !important;' + background_size + '}';
                document.documentElement.appendChild(enpast_generate_icon_style);
                enpast_pwd_gen_input_id.push(generate_id);
                enpast_pwd_gen.enpast_pwd_gen_onclick(parent_enpast_pwd_gen_input_class, generate_id);
            }
        }
    },
    add_event: function(event_, func, w) {
        w = w || 'w';
        if (w == 'w') {
            if (window.addEventListener) {
                window.addEventListener(event_, func, false);
            } else if (window.attachEvent) {
                window.attachEvent('on' + event_, func);
            }
        } else {
            if (document.addEventListener) {
                document.addEventListener(event_, func, false);
            } else if (document.attachEvent) {
                document.attachEvent('on' + event_, func);
            }
        }
    }
};


var PasswordGenerator = (function()
{
    var password_generator_dlg;

    var charTypes = {
        'upper': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        'lower': 'abcdefghijklmnopqrstuvwxyz',
        'number': '0123456789',
        'special': '!$%^&*()-=+[]{};#:@~,./<>?'
    };

    $(document).on('click', function(e){
        if(GetDlgOpen()){
            if ($("#enpast_password_generator_dlg").length) {
                if (!$(e.target).parents().filter('#enpast_password_generator_dlg').length) {
                    CloseDialog();
                }
            }
        }
    });

    function CreateDialog(pwd_element){   
        if(GetDlgOpen())
            return;
            
        SetDlgOpen(true);

        //add polyfill css into current page
        var polyfill_sheet = document.createElement('style');
        polyfill_sheet.innerHTML = "dialog {position: absolute;" +
            "left: 0; right: 0;" +
            "width: -moz-fit-content;" +
            "width: -webkit-fit-content;" +
            "width: fit-content;" +
            "height: -moz-fit-content;" +
            "height: -webkit-fit-content;" +
            "height: fit-content;" +
            "margin: auto;" +
            "border: solid;" +
            "padding: 1em;" +
            "background: white;" +
            "color: black;" +
            "display: block;} " +
            "dialog:not([open]) {display: none;} " +
            "dialog + .backdrop {position: fixed;" +
            "top: 0; right: 0; bottom: 0; left: 0;" +
            "background: rgba(0,0,0,0.1);} " +
            "._dialog_overlay {position: fixed;" +
            "top: 0; right: 0; bottom: 0; left: 0;} " +
            "dialog.fixed {position: fixed;top: 50%;transform: translate(0, -50%);}";

        document.body.appendChild(polyfill_sheet);

        var dialog = document.createElement("dialog");
        dialog.id = "enpast_password_generator_dlg";
        SetStyle(dialog, {
            'font-family':'sans-serif',
            'font-size':'medium',
            'padding':'0px',
            'background':'#fafafa',
            'border':'2px solid rgb(150, 150, 150)',
            'height':'auto',
            'z-index':'1',
            'width':'500px',
            'text-align': 'left'
        });

        //add title bar main icon
        var title_bar = document.createElement('div');
        SetStyle(title_bar, {
            'background':'#292929',
            'height':'45px',
            'padding':'2px',
            'margin':'0px',
            'display':'flex'
        });
        var iconImg = document.createElement('img');
        SetStyle(iconImg, {
            'margin':'0px 0px 0px 14px',
            'padding':'4px 0px 0px 0px',
            'width':'74px',
            'height':'36px',
            'display':'-webkit-box'
        });
        iconImg.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAAAuCAYAAAAr3zfuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAACrlJREFUeNrsnHmQVcUVxn9vBhgcRAYFRYdVXMAFVDSiCBKBSGJMRLFUYjIuSSrBxKCJCZSyCCYFMRWxlCwarYQCJUOByGgIoohLUAY3UJYCUcCRTQQUUINg54/3XebQc+979773QGsyp6rr9e3u031vnz6nz/m6Z1LOORroq02NAEilcuVvAhwLHAmUAeVAW6AVcARQqjEcsAfYBXwEbALWA1uB7frdXNAve/FF6NWrHgkpHqWAC4GTgROAs4FuElC+9AWwDnhNaR2wFHizQY+yC+kMYBDQAzhLWnMwqAjopHSFKV8JvA68BFQBa/8fhZRyzllz1wwYDPQF+gHtsvAvBVYAHwAfAtuAjTJfHwOfS0tSQDFQArQEjlFqKdN4nLSybZbxVgBzgOeA2RlbPvUUDBhQr4R0NTAE6JXBfK0FngJeVn41UFPg9zkVOB44CRggk3pURNt3gJnAbaG1NTVQXl4/VMk5h4ObHDgvvedgloMbHLR32v0PcSpx0M3BKAfzHOz23nFFKN/w4envqicpEFJbB9PMxw92kPqSBJMptXQw3rznb+q0adasXgnIOUeRFOoDpYD+o28uBB0mV70QtB1YZZ7ren+TJtU7xyEQ0n/lSQX0vTz7bay9YgHwPrABeByoKMA79zb59w+oOftsqKiod0Ky3l1n4G2VzwO+kWOfnYBngQ4R9U8D35LnlwvVKGjeCbTWAkvTkiXQrZttex7Q0XiYyEKkgM/0LrvymL9LgTO1KFMm5lsP/E0e7EDgH4VwHIK0QbZ+bR77xofe5v6qNnhbNjPHvruYPqbXqd+xw7fn811mWuWca5rHfvGpc67KOfeAc+5BpYedc2ucc393zh3pnBuqtn2cc21yGccPZlcpYO0AtNeKSEK3Gxd+HfBt4C09DwBmAM0VIPfXSk5Cp5n8GwfUlJVBkzpbXwA1zdXYxZJnW+AO4EQ9NzUuPwqgq6SppwHLFP8huOssYB+wUNrkU0vFjD8F/gT0BB4BXtB7NFaAvlb8ZdLET4DH1Hck4jBT0A/A+TkI6Sf63Q2c4zkj87QnzdRzRQ5C6m/yCw+o6doVDjusjqHQ72zgQa/ujmAnA/4pEzpH5moUsBz4HTBF8xCY7/lCYG4EtgAPaDEUa3KLtQiHS1jTZfq2yYE6QUH9cvHukAPkFB9WA39VXaiQ5gD3mgmZlhBsLVP+VU9AAc0CPpXH1yUH69xHvxu179VS9+6Z+P4AjPPeFWCY3qNcaMaTEtKZwClCVB4GbhAqslkCWqfyoZrkFhIOZr87Beguwc0CLtZimWPeYxAwUpqa0u+7vtfqC+ltTcCxQiB+lMAVd6Zt0wxeX7DB7k0ooNOBrgHGXddd6ZQtDCjR2CnPuy1V/hM5PY1kcprLKx0uId0lzUHPgUD6R4y5VVtGtZ6P1PejxdwLuAb4ukBrpwXSUgv5rSghOUE/FfqwPsLJ4tDnWmnNtdq6A0u8NjcaAS5NKCQLvD5Rp7ZdKMwYFD4E/NCDn94C/ghcp7KOmlAH/Eradbi05jngegNHzZeAuwCjgTXeaUE7Cf8laWWwUCq0D90q+Gu5zOkSaVy59sOTpH2RKPg0E88MTSAkgHuASVL9BcCV2neKgWuB+03bhxIKaYjJz61T27FjGM9UTbIPxi6TW5zSbyN98581Wev0fjVmHkbqO+4xC/o+nRR0NwIKaLD2zUC4IxU73iyNuhb4GvBzhQFO5XcDlZlc8CBtl5v7ifCzJG7yYuMmf6CyDp4Lfl/CPnsY3qrQNpMnR7uxe/fiKitxl1yCGzECV1NTW7dtWzKXePVq3Pjx6T4ztXvtNdzKlel8VRWuujpe/zt34hYtCsXu/HS3mZSfJZzQpg4+Fu9ilR1l+luaQ3xUafgvC21TWorr3Dk8tWlzYNvi4nT5ySensb7LL8ctXVp3wior6/YV9NG3b7igJk7EnXpqbTvLM2pUbbtJk3D9+tXtv0WLdFvTp3+eZG154H4vlw1PAjXtkg1+FrhI5VsUdyyWmselw4UuBHFPmwS858nl3eMjLZq3TfLq0g7BddfBnXdC+/Ywdy4MHBi0b654Zp9M0gZgPh07wpgxaSjqlVfSv8uXo7joRDNuEx3xrKZnz/QRyowZ1iw29lCRFTi3JJu5w8HrZvWeWQBU4E2VbXfQJEF/w0x/ExJq4PyQIxg/7XHwgINm+/mGDMEVFdl+xobwle6vHzy4VgPSaV5I+wVZ5sqmB+OYOxxcapieTzAx/Q3fvab8X6Y8yfnUDsPXNqGQHo0hpCC9k6GfVSHtr8nQfmrEGEd77cZGtJsQdlQRRlUGZe5tPJhsdJzJbzD5TR5sEoduVqCIUIGkJ8Eu5Ph9gTzWZSHA8LiQPgLT5dP3E4wbUA/veWAc/qIsH/kLk/9LzImxl1UsrPShyTeLubf93jyPKADqf72Cx77C5K7SXhDQj0N4fhDR1zeBo3NAzQNqQfpeR+zzpCiaYc6ZenpnOVHUOkKT7JFA8xj9jBJKEMRU7xZASP64lQYRCBZPiXkuMcEugszWx9QmTPC7VfmrTPlVZqz3hO3lJCR/dU2O0b40Qnt2JNCklorkMRhbISgMTzzaMzMWge4nLzWg0cDz5vmmGGMulGcXQEMnmUVvge3P8hHSC0oBdDIyS/sjTH61yVtNOCpLH9NN/q48D+YsDQAuEG52iRCJ4039Gg9TvNXkq0nfvn3T28eyhSe7zWEqGtsi+h/JWkWazrg3WIdIJQHGAo96A0eZlFlmhZRHOBdhY/UzcdFICkd3Z6m318PKzHtgoKUngAmm/MoQJ8TSPkFjgTXo7OGKLwvHbBT3ZDZTGm1cxOoM7d6I4e5OieBt7GCvaXdhnreLHknggo/zeK81dbu8OhsH1YSMO8XUT3XQwjw/7WCIN24r713GZzqZzUR3CsVupwO9kREuaxNF2i6DiY0ys4+bc5kZCcHdOLRO5qWRxtmtlTwTeCYEsQ/oUyHjh8sbLDN15cC5wKKIMY/RmG8IjD2XA0+Yn8geSMTXJBx09STeO6RNa6VWEam1VpbPd7vpd1uB7un5mtQnJt9xCTTQaZwoTVqosjEhfPtUd1qhNCkIBm8xcP0sHWztzuJBZaMechBsDHIwKO73Jr0XdkWGuiAOWxQxn3iamZN359NEmaXApczXJB0rFCCgX2YwHflS3EuaQ01+Len7HucKsD1P5n6W1282wf7bC0mC867s75XQ3AWp2MF6o56P5WGS1mY9K8o9PemZke/E4Onj8UyMaHdOhnvps035MlP+jMdzhsov9srvz8fcWbeyt2KfFHAZ8FvSV7qS0Fxqb+GsIfx6VL6OwmZzDLAzBk9vmey9JtAMo8VyOjpRezehldCF96i9TmZDlWmkL6ik1G6ZQWM2GWdrYyE0KUj9vBUwNgFvleHb6aDsIFzwTzkoMvk4PKXiidu+yPwFSIk3blg/9p388tT+9jGPKuKmCk9Qt8Tg8aH807+Cf8Hx5aYCCwkHN3uTPixD2yle2wsahHJohIT+0MtO/ugYccugBoEcWiHh4LY6Xkpt3fNe3UUNwvhyhISDX4fgdAsaBPTVEhIOro6AT7YkvNTSIKSDKCQcnO/gMyOglcLEGgSQUEhR9+4KRScINqoRnPIFDRSPzP98OthCAviuIujqhpnPTUj/GwAGMKRX9/pnSQAAAABJRU5ErkJggg==";
        title_bar.appendChild(iconImg);
        var title_txt = document.createElement('p');
        title_txt.innerHTML = 'Suggest Strong Password';
        SetStyle(title_txt, {
            'display': 'inline-block',
            'margin':'0px',
            'margin-block-start':'0px',
            'margin-block-end':'0px',
            'padding':'8px 0px 0px 0px',
            'font-size':'18px',
            'vertical-align':'bottom',
            'color':'#ebebeb',
            'height':'44px',
            'width':'380px',
            'text-align':'center'
        });
        title_bar.appendChild(title_txt);
        dialog.appendChild(title_bar);

        var bodyDiv = document.createElement('div');
        SetStyle(bodyDiv, {
            'margin':'0px',
            'padding':'0px'
        });

        //////BODY/////

        //add message text
        var msgField = document.createElement('p');
        msgField.id = 'enpast_password_generator_dialog_text';
        SetStyle(msgField, {
            'color':'#292929',
            'font-size':'medium',
            'padding-top':'20px',
            'padding-left':'20px',
            'margin':'0px'
        });
        msgField.innerHTML = '&nbsp;&nbsp;Do you want to use suggested strong password from RevBits PAM? &nbsp;&nbsp;&nbsp;';
        bodyDiv.appendChild(msgField);

        //add suggested password field
        var suggested_password = generatePassword(Math.floor(Math.random() * 10) + 20);

        var pwdField = document.createElement('div');
        pwdField.id = 'enpast_password_generator_password_text';
        SetStyle(pwdField, {
            'color':'#292929',
            'font-size':'medium',
            'padding-left':'20px',
            'margin':'0px',
            'text-align': 'center'
        });
        pwdField.innerText = suggested_password.toString();
        bodyDiv.appendChild(pwdField);

        // var copyBtnField = document.createElement('i');
        // copyBtnField.className += 'fa fa-copy';
        // bodyDiv.appendChild(copyBtnField);


        dialog.appendChild(bodyDiv);

        //create buttons
        var divBottom = document.createElement('div');
        SetStyle(divBottom, {
            'text-align':'right',
            'height':'40px',
            'padding':'0px',
            'margin-top':'10px',
            'margin-bottom':'20px'
        });

        var buttonCopy = document.createElement("button");
        buttonCopy.textContent = "Copy";
        SetStyle(buttonCopy, {
            'height':'40px',
            'width':'120px',
            'font-family':'sans-serif',
            'font-size':'medium',
            'border-style':'groove',
            'color':'#292929',
            'color-color':'#292929',
            'background':'#ebebeb',
            'border':'solid',
            'display':'initial',
            'outline':'none'
        });
        buttonCopy.addEventListener("click", function()
        {
            if(gBrowserName.toLowerCase() != "firefox")
                event.preventDefault();
            
            navigator.clipboard.writeText($('#enpast_password_generator_password_text').text()).then(function() {
                // console.log('Async: Copying to clipboard was successful!');
            }, function(err) {
                // console.error('Async: Could not copy text: ', err);
            });
        });
        divBottom.appendChild(buttonCopy);
        
        var buttonOk = document.createElement("button");
        buttonOk.textContent = "Yes";
        SetStyle(buttonOk, {
            'height':'40px',
            'width':'120px',
            'margin-left':'15px',
            'margin-right':'10px',
            'font-family':'sans-serif',
            'font-size':'medium',
            'border-style':'hidden',
            'color':'#fafafa',
            'background':'#292929',
            'display':'initial',
            'outline':'none'
        });
        buttonOk.addEventListener("click", function(event)
        {
            event.preventDefault();
            FillField(pwd_element, $('#enpast_password_generator_password_text').text());
            
            var el_confirm = document.getElementsByClassName('enpast_ext_element_pa_ssword_co_nfirm_re_gister');
            for (i = 0; i < el_confirm.length; i++) {
                FillField(el_confirm[i], $('#enpast_password_generator_password_text').text());                      
            }
            CloseDialog();   
        });
        divBottom.appendChild(buttonOk);

        dialog.appendChild(divBottom);

        document.body.appendChild(dialog);
        dialogPolyfill.registerDialog(dialog);
        dialog.showModal();
        
        password_generator_dlg = dialog;

    }
    
    function CloseDialog(){
        setTimeout(function(){
            if(GetDlgOpen()){
                password_generator_dlg.close();
                password_generator_dlg.remove();
                setTimeout(function(){
                    SetDlgOpen(false);
                }, 500);

            }   
        }, 200); 
    }

    function FillField(field, val) {
        if(val == '') 
            return false;

        SendKeyEvent(field);
        
        field.value = val;

        field.dispatchEvent((new Event('input', { 'bubbles': true })));
        field.dispatchEvent((new Event('change', { 'bubbles': true })));
        
        var filled = field.value === val;
        return filled;
    }

    function SendKeyEvent(field) {
        field.focus();

        var eventsToFire = {
            keydown: 'KeyboardEvent',
            keyup  : 'KeyboardEvent',
            change : 'HTMLEvents',
        };

        window.setTimeout(function() {
            for (var i in eventsToFire) {
                var evt = document.createEvent(eventsToFire[i]);
                evt.initEvent(i, true, true);
                field.dispatchEvent(evt);
            }
        });
    }

    function _generatePassword(passwordLength, charBlocks) {
        var allChars = "";
        for (var i = 0; i < charBlocks.length; i++) {
            allChars += charBlocks[i];
        }
        var numChars = allChars.length;
        var password = "";
        for (var i = 1; i <= passwordLength; i++) {
            password += allChars.charAt(Math.floor(Math.random() * numChars));
        }
        return password;
    }

    function generatePassword(passwordLength) {
        var charBlocks = [];
        for (id in charTypes) {
            charBlocks.push(charTypes[id]);
        }
        
        var password = _generatePassword(passwordLength, charBlocks);
        return password;
    }

    return {
        CreateDialog: CreateDialog
    };
})();
