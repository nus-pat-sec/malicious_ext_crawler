
function SetStyle(p_elem, p_styles)
{
    p_elem.style['margin-top'] = '0px';
    p_elem.style['margin-bottom'] = '0px';
    p_elem.style['margin-block-start'] = '0px';
    p_elem.style['margin-block-end'] = '0px';

    p_elem.style['padding-top'] = '0px';
    p_elem.style['padding-bottom'] = '0px';

    p_elem.style['box-sizing'] = 'border-box';
    p_elem.style['line-height'] = '1.6';
    p_elem.style['font-family'] = 'sans-serif';
    p_elem.style['font-size'] = 'medium';

    var s;
    for (s in p_styles) {
        p_elem.style[s] = p_styles[s];
    }

    if(p_elem.style['margin-top'] != '0px')
        p_elem.style['margin-block-start'] = p_elem.style['margin-top'];
    if(p_elem.style['margin-bottom'] != '0px')
        p_elem.style['margin-block-end'] = p_elem.style['margin-bottom'];
    if(p_elem.style['margin'] != '0px') {
        p_elem.style['margin-block-start'] = p_elem.style['margin'];
        p_elem.style['margin-block-end'] = p_elem.style['margin'];
    }
}

function SaveLoginStateToBackground(url, username, password)
{
    PrintLog("Updated storage >>>>>>>>>>");
    PrintLog(url);
    PrintLog(username);
    PrintLog(password);
    PrintLog("<<<<<<<<<<<<<<<<<<<<<<<<<<");

    chrome.runtime.sendMessage({
        m: MSG_SAVE_LOGIN_STATE,
        username: username,
        password: password,
        url: url
    });
}

function SaveLoginConfirmToBackground()
{
    chrome.runtime.sendMessage({
        m: MSG_SAVE_LOGIN_CONFIRM
    });
}

function ClearLoginStateInBackground()
{
    chrome.runtime.sendMessage({
        m: MSG_CLEAR_LOGIN_STATE
    });
}

function SetDlgOpen(flg)
{
    gIsOpenedDialog = flg;
}

function GetDlgOpen()
{
    return gIsOpenedDialog;
}

function GetBaseDomain(url){
    var new_url = url.replace('https://', '');
    new_url = new_url.replace('http://', '');

    if(new_url == "")
        return "";
    
    var parts = new_url.split("/");
    new_url = parts[0];

    parts = new_url.split(".");
    var parts_len = parts.length;
    if(parts_len < 3)
        return new_url;

    // check if this is ip address. ex: 192.168.5.17
    var f = true;
    for (i = 0; i < parts_len; i++) {
        if(isNaN(parseInt(parts[i])))
            f = false;
    }
    if(f == true) {
        return new_url;
    }

    // print out only last 2 parts
    new_url = parts[parts_len - 2] + "." + parts[parts_len - 1];

    return new_url;
}

function GetBaseUrl(url)
{
    var new_url = "";
    
    var parts = url.split("/");
    var parts_len = parts.length;
    for (i = 0; i < parts_len - 1; i++) {
        new_url = parts[i] + "/"
    }
    
    new_url = new_url.replace('https:/', 'https://');
    new_url = new_url.replace('http:/', 'http://');
    return new_url;
}