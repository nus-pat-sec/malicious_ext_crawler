
///////////////////////////////////////////////////////////////////////////////////////////////////////////
function GetEntries(url)
{
    // console.log("Sent message to background script");
    // Send message to background script
    try{
        chrome.runtime.sendMessage({
            m: MSG_WEBSOCKET_REQUEST,
            msg: ENPAST_WEBSOCKET_MESSAGE_GET_ENTRIES,
            url: url
        });
    }catch(err){}
}

function GetContainerFolderList()
{
    // console.log("Sent message to background script");
    // Send message to background script
    chrome.runtime.sendMessage({
        m: MSG_WEBSOCKET_REQUEST,
        msg: ENPAST_WEBSOCKET_MESSAGE_GET_CONTAINER_FOLDER_LIST
    });
}

function SaveEntry(url, entryname, username, password, pcid, pfid)
{
    // console.log("Sent message to background script");
    // Send message to background script
    chrome.runtime.sendMessage({
        m: MSG_WEBSOCKET_REQUEST,
        msg: ENPAST_WEBSOCKET_MESSAGE_SAVE_ENTRY,
        url: url,
        entryname: entryname,
        username: username,
        password: password,
        pcid: pcid,
        pfid: pfid
    });
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
// Setup Message Listner
chrome.runtime.onMessage.addListener(contentMessageHandler);

// Message Handler
function contentMessageHandler(message, sender, sendResponse)
{    
    if (!message || !message.m)
        //Unrecognized message format
        return;

    if(message.m != MSG_APPLICATION_STATE)
        PrintLog(message);

    // Process messages from background.js
    if(message.m == MSG_ALLOWED_CONNECTION) {
        ProcessAllowedConnection(message.e);
    }else if(message.m == MSG_ENTRY_LIST) {
        ProcessGetEntries(message.e);
    }else if (message.m == MSG_CONTAINER_FOLDER_LIST) {
        ProcessGetContainerFolderList(message.e);
    }else if (message.m == MSG_UPDATED_CONTAINER_FOLDER_LIST) {
        ProcessUpdateContainerFolderList(message.e);
    }else if (message.m == MSG_SAVE_ENTRY_RESULT) {
        ProcessSaveEntry(message.e);
    }else if (message.m == MSG_APPLICATION_STATE) {
        ProcessApplicationState(message.e);
    }else if (message.m == MSG_RUN_SAVE_MODULE){
        ProcessRunSaveModule(message.url, message.username, message.password, message.confirmed);
    }
}

// Process of "AllowedConnection" message
function ProcessAllowedConnection(response)
{
    var responseObj = JSON.parse(response);

    gExtensionToken = responseObj.extension_token;
}

// Process of "ApplicationState" message
function ProcessApplicationState(response)
{
    var responseObj = JSON.parse(response);

    if(response) {
        gDesktopApplicationVersion = responseObj.application_version;
        gDesktopApplicationIsLogined = responseObj.is_logined;
    }else{
        gDesktopApplicationVersion = "Unknown";
        gDesktopApplicationIsLogined = false;
    }

    if(!gDesktopApplicationIsLogined) {
        SaveEntryDlg.UpdateContainerFolderList(null);
    }
}

// Process of "GetEntries" message
function ProcessGetEntries(response)
{
    gIsOpenedWebSocket = true;
    
    var responseObj = JSON.parse(response);
    gOpenedEntries = responseObj.data;
        
    if(gOpenedEntries.length == 1) {
        PageCheck.add_mark_login_element();
        PageCheck.write_login_email(gOpenedEntries[0].username);
        PageCheck.write_login_password(gOpenedEntries[0].password);        
    }else if(gOpenedEntries.length > 1) {
        PageCheck.add_mark_login_element();
        SelectEntryDlg.Open(gOpenedEntries);
    }
}

// Process of "GetContainerFolderList" message
function ProcessGetContainerFolderList(response)
{
    var responseObj = JSON.parse(response);
    var containerFolders = responseObj.data;
    SaveEntryDlg.Open(containerFolders)
}

function ProcessUpdateContainerFolderList(response)
{
    console.log('updated');
    var responseObj = JSON.parse(response);
    var containerFolders = responseObj.data;
    SaveEntryDlg.UpdateContainerFolderList(containerFolders);
}

// Process of "SaveEntry" message
function ProcessSaveEntry(response)
{    
    responseObj = JSON.parse(response);
    if(responseObj.return_code == 1000) {
        // close dialog
        try{
            SaveEntryDlg.Close();

            ClearLoginStateInBackground();
        }catch(err){}        
    } else {
        // show message in dialog without closing it
        // SaveEntryDlg.ShowWarning(responseObj.text);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
function RegisterLoginStatus(username, password)
{
    PrintLog("Clicked Submit button");

    var is_exist = false;
    if(gOpenedEntries) {
        for (var i = 0; i < gOpenedEntries.length ; i++) {            
            if((gOpenedEntries[i].username == username &&
                gOpenedEntries[i].password == password)) {
                is_exist = true;
            }
        }
    }

    if(!is_exist){
        SaveLoginStateToBackground(
            gHostName,
            username,
            password
        );
    }else{
        ClearLoginStateInBackground();
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
function ProcessRunSaveModule(url, username, password, confirmed)
{
    if(url == "" || password == "")
        return;

    gEnpastSaveUrl = url;
    gEnpastSaveUsername = username;
    gEnpastSavePassword = password;
    if(!confirmed)
        SaveEntryDlg.OpenMessageBox();
    else{
        if(!GetDlgOpen())
            GetContainerFolderList();
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////

function StartProcess()
{   
    PrintLog("Start");

    enpast_pwd_gen.init();

    setInterval(function(){
        PageCheck.check();
        if(PageCheck.is_loginpage()) {
            if(gDesktopApplicationIsLogined) {
                GetEntries(GetBaseDomain(gHostName));
            }
        }else{
            if(!PageCheck.is_loginpage(false)) {
                PageCheck.remove_mark_login_element();
                if(gDesktopApplicationIsLogined) {
                    if(GetDlgOpen() === true) {
                        try{
                            SelectEntryDlg.Close();
                        }catch(err){}
                    }    
                }
            }
        }
    }, 500);    
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
StartProcess();