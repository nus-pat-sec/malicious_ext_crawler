var PageCheck = (function()
{
    function check()
    {
        $("iframe").each(function(){
            var frame = $(this);
            if(is_visible(frame)) {
                try{
                    if(frame.attr('src')) {
                        var iframe_url = GetBaseUrl(frame.attr('src'));

                        if(iframe_url.toLowerCase().includes("login") ||
                        iframe_url.toLowerCase().includes("log_in") ||
                        iframe_url.toLowerCase().includes("signin") ||
                        iframe_url.toLowerCase().includes("sign_in") ||
                        iframe_url.toLowerCase().includes("register") ||
                        iframe_url.toLowerCase().includes("create") ||
                        iframe_url.toLowerCase().includes("signup") ||
                        iframe_url.toLowerCase().includes("sign_up") ||
                        iframe_url.toLowerCase().includes("join")){
                            window.location.href = frame.attr('src');
                        }
                    }
                }catch(err){}
            }
        });

        $(USERNAME_PASSWORD_PATTERN).each(function(){
            var el = $(this);
            if(is_visible(el)){
                el.addClass('enpast_ext_element');
                if(is_email(el))
                    el.addClass('enpast_ext_element_em_ail');
                if(is_password(el))
                    el.addClass('enpast_ext_element_pa_ssword');                    
            }
        });

        $(SUBMIT_PATTERN).each(function(){
            var el = $(this);
            if(is_visible(el)){
                if(el.prop('innerText').toLowerCase().includes("login") ||
                el.prop('innerText').toLowerCase().includes("log in") ||
                el.prop('innerText').toLowerCase().includes("log_in") ||
                el.prop('innerText').toLowerCase().includes("sign in") ||
                el.prop('innerText').toLowerCase().includes("sign_in") ||
                el.prop('innerText').toLowerCase().includes("signin") ||
                el.prop('innerText').toLowerCase().includes("sign up") ||
                el.prop('innerText').toLowerCase().includes("sign_up") ||
                el.prop('innerText').toLowerCase().includes("singup") ||
                el.prop('innerText').toLowerCase().includes("register") ||
                el.prop('innerText').toLowerCase().includes("create") ||
                el.prop('innerText').toLowerCase().includes("next") ||
                el.prop('innerText').toLowerCase().includes("continue") ||
                el.prop('innerText').toLowerCase().includes("join") ||
                el.prop('innerText').toLowerCase().includes("submit")){

                    el.addClass('enpast_ext_element');
                    el.addClass('enpast_ext_element_su_bmit');
    
                    if(el.prop('innerText').toLowerCase().includes("login") ||
                    el.prop('innerText').toLowerCase().includes("log in") ||
                    el.prop('innerText').toLowerCase().includes("log_in") ||
                    el.prop('innerText').toLowerCase().includes("sign in") ||
                    el.prop('innerText').toLowerCase().includes("sign_in") ||
                    el.prop('innerText').toLowerCase().includes("signin")){
                        el.addClass('enpast_ext_element_su_bmit_lo_gin');
                    }
    
                    if(el.prop('innerText').toLowerCase().includes("sign up") ||
                    el.prop('innerText').toLowerCase().includes("singup") ||
                    el.prop('innerText').toLowerCase().includes("sing_up") ||
                    el.prop('innerText').toLowerCase().includes("register") ||
                    el.prop('innerText').toLowerCase().includes("create")){
                        el.addClass('enpast_ext_element_su_bmit_re_gister');
                    }
                }else{
                    if(el.prop('outerHTML').toLowerCase().includes("login") ||
                    el.prop('outerHTML').toLowerCase().includes("log in") ||
                    el.prop('outerHTML').toLowerCase().includes("log_in") ||
                    el.prop('outerHTML').toLowerCase().includes("sign in") ||
                    el.prop('outerHTML').toLowerCase().includes("sign_in") ||
                    el.prop('outerHTML').toLowerCase().includes("signin") ||
                    el.prop('outerHTML').toLowerCase().includes("sign up") ||
                    el.prop('outerHTML').toLowerCase().includes("sign_up") ||
                    el.prop('outerHTML').toLowerCase().includes("singup") ||
                    el.prop('outerHTML').toLowerCase().includes("register") ||
                    el.prop('outerHTML').toLowerCase().includes("create") ||
                    el.prop('outerHTML').toLowerCase().includes("next") ||
                    el.prop('outerHTML').toLowerCase().includes("continue") ||
                    el.prop('outerHTML').toLowerCase().includes("join") ||
                    el.prop('outerHTML').toLowerCase().includes("submit"))
                    {
    
                        el.addClass('enpast_ext_element');
                        el.addClass('enpast_ext_element_su_bmit');
        
                        if(el.prop('outerHTML').toLowerCase().includes("login") ||
                        el.prop('outerHTML').toLowerCase().includes("log in") ||
                        el.prop('outerHTML').toLowerCase().includes("log_in") ||
                        el.prop('outerHTML').toLowerCase().includes("sign in") ||
                        el.prop('outerHTML').toLowerCase().includes("sign_in") ||
                        el.prop('outerHTML').toLowerCase().includes("signin")){
                            el.addClass('enpast_ext_element_su_bmit_lo_gin');
                        }
        
                        if(el.prop('outerHTML').toLowerCase().includes("sign up") ||
                        el.prop('outerHTML').toLowerCase().includes("singup") ||
                        el.prop('outerHTML').toLowerCase().includes("sing_up") ||
                        el.prop('outerHTML').toLowerCase().includes("register") ||
                        el.prop('outerHTML').toLowerCase().includes("create")){
                            el.addClass('enpast_ext_element_su_bmit_re_gister');
                        }
                    }
                }
            }
        });

        // All header elements <h1>, <h2> ...
        $(":header").each(function(){
            var el = $(this);
            if(is_visible(el)){
                if(el.prop('innerText').toLowerCase().includes("signup") ||
                el.prop('innerText').toLowerCase().includes("sign up") ||
                el.prop('innerText').toLowerCase().includes("sign_up") ||
                el.prop('innerText').toLowerCase().includes("register") ||
                el.prop('innerText').toLowerCase().includes("create")||
                el.prop('innerText').toLowerCase().includes("new") ||
                el.prop('innerText').toLowerCase().includes("login") ||
                el.prop('innerText').toLowerCase().includes("log in") ||
                el.prop('innerText').toLowerCase().includes("log_in") ||
                el.prop('innerText').toLowerCase().includes("sign in") ||
                el.prop('innerText').toLowerCase().includes("sign_in") ||
                el.prop('innerText').toLowerCase().includes("signin")) {
                    if(el.prop('innerText').toLowerCase().includes("signup") ||
                    el.prop('innerText').toLowerCase().includes("sign up") ||
                    el.prop('innerText').toLowerCase().includes("sign_up") ||
                    el.prop('innerText').toLowerCase().includes("register") ||
                    el.prop('innerText').toLowerCase().includes("create")||
                    el.prop('innerText').toLowerCase().includes("new")) {
                        el.addClass('enpast_ext_element');
                        el.addClass('enpast_ext_element_header_re_gister');
                    }
    
                    if(el.prop('innerText').toLowerCase().includes("login") ||
                    el.prop('innerText').toLowerCase().includes("log in") ||
                    el.prop('innerText').toLowerCase().includes("log_in") ||
                    el.prop('innerText').toLowerCase().includes("sign in") ||
                    el.prop('innerText').toLowerCase().includes("sign_in") ||
                    el.prop('innerText').toLowerCase().includes("signin")) {
                        el.addClass('enpast_ext_element');
                        el.addClass('enpast_ext_element_header_lo_gin');
                    }
                }else{
                    if(el.prop('outerHTML').toLowerCase().includes("signup") ||
                    el.prop('outerHTML').toLowerCase().includes("sign up") ||
                    el.prop('outerHTML').toLowerCase().includes("sign_up") ||
                    el.prop('outerHTML').toLowerCase().includes("register") ||
                    el.prop('outerHTML').toLowerCase().includes("create")||
                    el.prop('outerHTML').toLowerCase().includes("new")) {
                        el.addClass('enpast_ext_element');
                        el.addClass('enpast_ext_element_header_re_gister');
                    }
    
                    if(el.prop('outerHTML').toLowerCase().includes("login") ||
                    el.prop('outerHTML').toLowerCase().includes("log in") ||
                    el.prop('outerHTML').toLowerCase().includes("log_in") ||
                    el.prop('outerHTML').toLowerCase().includes("sign in") ||
                    el.prop('outerHTML').toLowerCase().includes("sign_in") ||
                    el.prop('outerHTML').toLowerCase().includes("signin")) {
                        el.addClass('enpast_ext_element');
                        el.addClass('enpast_ext_element_header_lo_gin');
                    }
                }                
            }
        });

        var all = $('.enpast_ext_element');
        all.each(function(){
            var el = $(this);
            var el_index = all.index(el);

            if(el.hasClass('enpast_ext_element_su_bmit_re_gister')){
                for(i = 1 ; i <= el_index; i++){
                    if(all.eq(el_index - i).hasClass('enpast_ext_element_su_bmit') ||
                    all.eq(el_index - i).hasClass('enpast_ext_element_header_re_gister'))
                        if(is_visible(all.eq(el_index - i)))
                            break;

                    if(all.eq(el_index - i).hasClass('enpast_ext_element_em_ail')) {
                        all.eq(el_index - i).addClass("enpast_ext_element_em_ail_re_gister");
                    }

                    if(all.eq(el_index - i).hasClass('enpast_ext_element_pa_ssword')) {
                        all.eq(el_index - i).addClass("enpast_ext_element_pa_ssword_re_gister");
                    }
                }
            }

            if(el.hasClass('enpast_ext_element_su_bmit_lo_gin')){
                for(i = 1 ; i <= el_index; i++){
                    if(all.eq(el_index - i).hasClass('enpast_ext_element_su_bmit') ||
                    all.eq(el_index - i).hasClass('enpast_ext_element_header_lo_gin')) {
                        if(is_visible(all.eq(el_index - i)))
                            break;
                    }
                    if(all.eq(el_index - i).hasClass('enpast_ext_element_em_ail')) {
                        all.eq(el_index - i).addClass("enpast_ext_element_em_ail_lo_gin");
                    }

                    if(all.eq(el_index - i).hasClass('enpast_ext_element_pa_ssword')) {
                        all.eq(el_index - i).addClass("enpast_ext_element_pa_ssword_lo_gin");
                    }
                }
            }

            if(el.hasClass('enpast_ext_element_pa_ssword')){
                if(el.prop('outerHTML').toLowerCase().includes("create")){
                    el.addClass('enpast_ext_element_pa_ssword_re_gister');

                    for(i = el_index + 1 ; i < all.length; i++) {
                        if(all.eq(i).hasClass('enpast_ext_element_su_bmit')) {
                            all.eq(i).addClass('enpast_ext_element_su_bmit_re_gister');
                            if(is_visible(all.eq(i)))
                                break;                              
                        }
                    }
                }

                if(el.prop('outerHTML').toLowerCase().includes("confirm") ||
                el.prop('outerHTML').toLowerCase().includes("repeat") ||
                el.prop('outerHTML').toLowerCase().includes("again")){

                    el.addClass('enpast_ext_element_pa_ssword_co_nfirm_re_gister');

                    for(i = el_index + 1 ; i < all.length; i++) {
                        if(all.eq(i).hasClass('enpast_ext_element_su_bmit')) {
                            all.eq(i).addClass('enpast_ext_element_su_bmit_re_gister');
                            if(is_visible(all.eq(i)))
                                break;                              
                        }
                    }
                }
            }

            if(el_index > 1 && el.hasClass('enpast_ext_element_pa_ssword')){
                if(all.eq(el_index - 1).hasClass('enpast_ext_element_pa_ssword')){

                    el.addClass("enpast_ext_element_pa_ssword_co_nfirm_re_gister");
                    all.eq(el_index - 1).addClass("enpast_ext_element_pa_ssword_re_gister");

                    if(all.eq(el_index - 2).hasClass("enpast_ext_element_em_ail")) {
                        all.eq(el_index - 2).addClass("enpast_ext_element_em_ail_re_gister");
                    }

                    for(i = el_index + 1 ; i < all.length; i++) {
                        if(all.eq(i).hasClass('enpast_ext_element_su_bmit')) {                            
                            all.eq(i).addClass('enpast_ext_element_su_bmit_re_gister');
                            if(is_visible(all.eq(i)))
                                break; 
                        }
                    }
                }
            }
        });

        if($('.enpast_ext_element_su_bmit_lo_gin').length == 0 ||
        $('.enpast_ext_element_su_bmit_re_gister').length == 0) {
            all.each(function(){
                var el = $(this);
                var el_index = all.index(el);
    
                if(el.hasClass('enpast_ext_element_header_lo_gin')) {
                    for(i = el_index + 1 ; i < all.length; i++) {
                        if(all.eq(i).hasClass('enpast_ext_element_su_bmit')) {
                            all.eq(i).addClass('enpast_ext_element_su_bmit_lo_gin');
                            if(is_visible(all.eq(i)))
                                break;
                        }
                        if(all.eq(i).hasClass('enpast_ext_element_em_ail')) {
                            all.eq(i).addClass('enpast_ext_element_em_ail_lo_gin');
                        }
                        if(all.eq(i).hasClass('enpast_ext_element_pa_ssword')) {
                            all.eq(i).addClass('enpast_ext_element_pa_ssword_lo_gin');
                        }
                    }
                }
                    
                if(el.hasClass('enpast_ext_element_header_re_gister')) {
                    for(i = el_index + 1 ; i < all.length; i++) {
                        if(all.eq(i).hasClass('enpast_ext_element_su_bmit')) {
                            all.eq(i).addClass('enpast_ext_element_su_bmit_re_gister');
                            if(is_visible(all.eq(i)))
                                break;
                        }
                        if(all.eq(i).hasClass('enpast_ext_element_em_ail')) {
                            all.eq(i).addClass('enpast_ext_element_em_ail_re_gister');
                        }
                        if(all.eq(i).hasClass('enpast_ext_element_pa_ssword')) {
                            all.eq(i).addClass('enpast_ext_element_pa_ssword_re_gister');
                        }
                    }
                }

                if(el.hasClass('enpast_ext_element_em_ail')) {
                    if(el.prop('outerHTML').toLowerCase().includes("login") ||
                    el.prop('outerHTML').toLowerCase().includes("log in") ||
                    el.prop('outerHTML').toLowerCase().includes("log_in") ||
                    el.prop('outerHTML').toLowerCase().includes("sign in") ||
                    el.prop('outerHTML').toLowerCase().includes("sign_in") ||
                    el.prop('outerHTML').toLowerCase().includes("signin")) {
                        el.addClass('enpast_ext_element_em_ail_lo_gin');
                        for(i = el_index + 1 ; i < all.length; i++) {
                            if(all.eq(i).hasClass('enpast_ext_element_su_bmit')) {
                                all.eq(i).addClass('enpast_ext_element_su_bmit_lo_gin');
                                if(is_visible(all.eq(i)))
                                    break;
                            }
                            if(all.eq(i).hasClass('enpast_ext_element_em_ail')) {
                                all.eq(i).addClass('enpast_ext_element_em_ail_lo_gin');
                            }
                            if(all.eq(i).hasClass('enpast_ext_element_pa_ssword')) {
                                all.eq(i).addClass('enpast_ext_element_pa_ssword_lo_gin');
                            }
                        }
                    }
                    
                    if(el.prop('outerHTML').toLowerCase().includes("signup") ||
                    el.prop('outerHTML').toLowerCase().includes("sign up") ||
                    el.prop('outerHTML').toLowerCase().includes("sign_up") ||
                    el.prop('outerHTML').toLowerCase().includes("register") ||
                    el.prop('outerHTML').toLowerCase().includes("create") ||
                    el.prop('outerHTML').toLowerCase().includes("new")) {
                        el.addClass('enpast_ext_element_em_ail_re_gister');
                        for(i = el_index + 1 ; i < all.length; i++) {
                            if(all.eq(i).hasClass('enpast_ext_element_su_bmit')) {
                                all.eq(i).addClass('enpast_ext_element_su_bmit_re_gister');
                                if(is_visible(all.eq(i)))
                                    break;
                            }
                            if(all.eq(i).hasClass('enpast_ext_element_em_ail')) {
                                all.eq(i).addClass('enpast_ext_element_em_ail_re_gister');
                            }
                            if(all.eq(i).hasClass('enpast_ext_element_pa_ssword')) {
                                all.eq(i).addClass('enpast_ext_element_pa_ssword_re_gister');
                            }
                        }
                    }
                }
    
                if(el.hasClass('enpast_ext_element_pa_ssword')){
                    if(el.prop('outerHTML').toLowerCase().includes("login") ||
                    el.prop('outerHTML').toLowerCase().includes("log in") ||
                    el.prop('outerHTML').toLowerCase().includes("log_in") ||
                    el.prop('outerHTML').toLowerCase().includes("sign in") ||
                    el.prop('outerHTML').toLowerCase().includes("sign_in") ||
                    el.prop('outerHTML').toLowerCase().includes("signin")) {
                        el.addClass('enpast_ext_element_pa_ssword_lo_gin');
                        for(i = el_index + 1 ; i < all.length; i++) {
                            if(all.eq(i).hasClass('enpast_ext_element_su_bmit')) {
                                all.eq(i).addClass('enpast_ext_element_su_bmit_lo_gin');
                                if(is_visible(all.eq(i)))
                                    break;
                            }
                            if(all.eq(i).hasClass('enpast_ext_element_em_ail')){
                                all.eq(i).addClass('enpast_ext_element_em_ail_lo_gin');
                            }
                            if(all.eq(i).hasClass('enpast_ext_element_pa_ssword')){
                                all.eq(i).addClass('enpast_ext_element_pa_ssword_lo_gin');
                            }
                        }
                    }
                    
                    if(el.prop('outerHTML').toLowerCase().includes("signup") ||
                    el.prop('outerHTML').toLowerCase().includes("sign up") ||
                    el.prop('outerHTML').toLowerCase().includes("sign_up") ||
                    el.prop('outerHTML').toLowerCase().includes("register") ||
                    el.prop('outerHTML').toLowerCase().includes("create") ||
                    el.prop('outerHTML').toLowerCase().includes("new")){
                        el.addClass('enpast_ext_element_pa_ssword_re_gister');
                        for(i = el_index + 1 ; i < all.length; i++){
                            if(all.eq(i).hasClass('enpast_ext_element_su_bmit')){
                                all.eq(i).addClass('enpast_ext_element_su_bmit_re_gister');
                                if(is_visible(all.eq(i)))
                                    break;
                            }
                            if(all.eq(i).hasClass('enpast_ext_element_em_ail')){
                                all.eq(i).addClass('enpast_ext_element_em_ail_re_gister');
                            }
                            if(all.eq(i).hasClass('enpast_ext_element_pa_ssword')){
                                all.eq(i).addClass('enpast_ext_element_pa_ssword_re_gister');
                            }
                        }
                    }
                }
    
                if(el.hasClass('enpast_ext_element_pa_ssword_co_nfirm_re_gister')){
                    for(i = el_index + 1 ; i < all.length; i++){
                        if(all.eq(i).hasClass('enpast_ext_element_su_bmit')){
                            all.eq(i).addClass('enpast_ext_element_su_bmit_re_gister');
                            if(all.eq(i).hasClass('enpast_ext_element_su_bmit')){
                                all.eq(i).addClass('enpast_ext_element_su_bmit_re_gister');
                                if(is_visible(all.eq(i)))
                                    break;
                            }
                            if(all.eq(i).hasClass('enpast_ext_element_em_ail')){
                                all.eq(i).addClass('enpast_ext_element_em_ail_re_gister');
                            }
                            if(all.eq(i).hasClass('enpast_ext_element_pa_ssword')){
                                all.eq(i).addClass('enpast_ext_element_pa_ssword_re_gister');
                            }
                        }
                    }
                }
            });
        }

        if($('.enpast_ext_element_su_bmit_lo_gin').length == 0 &&
        $('.enpast_ext_element_su_bmit_re_gister').length == 0){
            $('.enpast_ext_element_su_bmit').each(function(){
                var el = $(this);
                for (index in SIGNUP_URL_PATTERN) {
                    if((window.location.origin + window.location.pathname).toLowerCase().includes(SIGNUP_URL_PATTERN[index])){
                        el.addClass('enpast_ext_element_su_bmit_re_gister');
                    }
                };
                for (index in LOGIN_URL_PATTERN) {
                    if((window.location.origin + window.location.pathname).toLowerCase().includes(LOGIN_URL_PATTERN[index])){
                        el.addClass('enpast_ext_element_su_bmit_lo_gin');
                    }
                };
            });
        }

        if(is_loginpage(false)){
            $('.enpast_ext_element_su_bmit_lo_gin').each(function() {
                var el_submit = $(this);
                
                el_submit.on('click', function(e){
                    // Mouse click event
                    RegisterLoginStatus(read_login_email(), read_login_password());
                });
    
                window.addEventListener('keypress', function (e) {
                    if (e.keyCode == 13) {
                        // ENTER keypress event
                        RegisterLoginStatus(read_login_email(), read_login_password());
                     }
                }, false);
            });
        }

        if(is_registerpage()){
            $('.enpast_ext_element_su_bmit_re_gister').each(function() {
                var el_submit = $(this);
                
                el_submit.on('click', function(e){
                    // Mouse click event
                    RegisterLoginStatus(read_register_email(), read_register_password());
                });
    
                window.addEventListener('keypress', function (e) {
                    if (e.keyCode == 13) {
                        // ENTER keypress event
                        RegisterLoginStatus(read_register_email(), read_register_password());
                     }
                }, false);
            });
        }
    }

    function is_loginpage(flt = true){
        var css_email;
        var css_password;

        if(flt){
            css_email = '.enpast_ext_element_em_ail_lo_gin:not(.enpast_ext_element_marked)';
            css_password = '.enpast_ext_element_pa_ssword_lo_gin:not(.enpast_ext_element_marked)';
        }else{
            css_email = '.enpast_ext_element_em_ail_lo_gin';
            css_password = '.enpast_ext_element_pa_ssword_lo_gin';
        }

        if($('.enpast_ext_element_su_bmit_lo_gin').length > 0){
            var ret = false;
            $('.enpast_ext_element_su_bmit_lo_gin').each(function(){
                var el_submit = $(this);
                if(is_visible(el_submit)){
                    if($(css_email).length > 0 || 
                    $(css_password).length > 0){
                        var flg = false;
                        $(css_email).each(function(){
                            var el = $(this);
                            if(is_visible(el)){
                                flg = true;
                                return;
                            }
                        });

                        if(flg){
                            ret = true;
                            return;
                        }

                        $(css_password).each(function(){
                            var el = $(this);
                            if(is_visible(el)){
                                flg = true;
                                return;
                            }
                        });

                        if(flg){
                            ret = true;
                            return;
                        }
                    }
                }
            }); 

            return ret;
        }
    }

    function add_mark_login_element(){
        $('.enpast_ext_element_em_ail_lo_gin,.enpast_ext_element_pa_ssword_lo_gin').each(function(){
            var el = $(this);
            if(is_visible(el)){
                el.addClass('enpast_ext_element_marked');
            }
        });
    }

    function remove_mark_login_element(){
        $('.enpast_ext_element_em_ail_lo_gin,.enpast_ext_element_pa_ssword_lo_gin').each(function(){
            var el = $(this);
            el.removeClass('enpast_ext_element_marked');
        });
    }

    function write_login_email(username){
        $('.enpast_ext_element_em_ail_lo_gin').each(function(){
            var el = $(this);
            if(is_visible(el)){
                write_value(el, username);
            }
        });
    }

    function write_login_password(password){
        $('.enpast_ext_element_pa_ssword_lo_gin').each(function(){
            var el = $(this);
            if(is_visible(el)){
                setTimeout(function(){
                    write_value(el, password);
                }, 300);                
            }
        });
    }

    function read_login_email(){
        var ret = "";
        $('.enpast_ext_element_em_ail_lo_gin').each(function(){
            var el = $(this);
            if(el.val() != ""){
                ret = el.val();
            }
        });

        return ret;
    }

    function read_login_password(){
        var ret = "";
        $('.enpast_ext_element_pa_ssword_lo_gin').each(function(){
            var el = $(this);
            if(el.val() != ""){
                ret = el.val();
            }
        });

        return ret;
    }

    function read_register_email(){
        var ret = "";
        $('.enpast_ext_element_em_ail_re_gister').each(function(){
            var el = $(this);
            if(el.val() != ""){
                ret = el.val();
            }
        });

        return ret;
    }

    function read_register_password(){
        var ret = "";
        $('.enpast_ext_element_pa_ssword_re_gister:not(.enpast_ext_element_pa_ssword_co_nfirm_re_gister)').each(function(){
            var el = $(this);
            if(el.val() != ""){
                ret = el.val();
            }
        });

        return ret;
    }

    function is_registerpage(){
        var css_email = '.enpast_ext_element_em_ail_re_gister';
        var css_password = '.enpast_ext_element_pa_ssword_re_gister';

        if($('.enpast_ext_element_su_bmit_re_gister').length > 0){
            var ret = false;
            $('.enpast_ext_element_su_bmit_re_gister').each(function(){
                var el_submit = $(this);
                if(is_visible(el_submit)){
                    if($(css_email).length > 0 || 
                    $(css_password).length > 0){
                        var flg = false;
                        $(css_email).each(function(){
                            var el = $(this);
                            if(is_visible(el)){
                                flg = true;
                                return;
                            }
                        });

                        if(flg){
                            ret = true;
                            return;
                        }

                        $(css_password).each(function(){
                            var el = $(this);
                            if(is_visible(el)){
                                flg = true;
                                return;
                            }
                        });

                        if(flg){
                            ret = true;
                            return;
                        }
                    }
                }
            }); 

            return ret;
        }
    }

    function is_visible(el) {
        if(!el.is(':visible'))
            return false;
        
        if (el instanceof jQuery) {
            el = el[0];
        }

        var rect = el.getBoundingClientRect();

        return (            
            rect.top >= 0 && rect.left >= 0 &&
            rect.height > 5 && rect.width > 5 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) + 100 &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)) + 100; // 100 : width of scroll-bar
    }

    function is_email(el){
        var ret = false;
        USERNAME_ATTR_PATTERN.some(function(attr_pattern){
            try{
                if (el.attr(Object.keys(attr_pattern).join()).toLowerCase() == Object.values(attr_pattern).join()){
                    ret = true;
                    return true;
                }
            }catch (exception) {

            }
        });

        return ret;
    }

    function is_password(el) {
        var ret = false;
        PASSWORD_ATTR_PATTERN.some(function(attr_pattern){
            try{
                if (el.attr(Object.keys(attr_pattern).join()).toLowerCase() == Object.values(attr_pattern).join()){
                    ret = true;
                    return true;
                }
            }catch (exception) {

            }
        });

        return ret;
    }

    function write_value(el, v) {
        if(v == '') 
            return false;

        make_key_event(el);
        
        el.val(v);
        el.trigger('input');
        el.trigger('change');

        el[0].dispatchEvent((new Event('input', { 'bubbles': true })));
        el[0].dispatchEvent((new Event('change', { 'bubbles': true })));
        
        var filled = (el.val() === v);
        return filled;
    }
    
    function make_key_event(el) {
        el.focus();

        var eventsToFire = {
            keydown: 'KeyboardEvent',
            keyup  : 'KeyboardEvent',
            change : 'HTMLEvents',
        };

        window.setTimeout(function() {
            for (var i in eventsToFire) {
                var evt = document.createEvent(eventsToFire[i]);
                evt.initEvent(i, false, true);
                el.get(0).dispatchEvent(evt);
            }
        });
    }

    return{
        check: check,
        is_loginpage: is_loginpage,
        is_registerpage: is_registerpage,
        write_login_email: write_login_email,
        write_login_password: write_login_password,
        read_login_email: read_login_email,
        read_login_password: read_login_password,
        read_register_email: read_register_email,
        read_register_password: read_register_password,
        add_mark_login_element: add_mark_login_element,
        remove_mark_login_element: remove_mark_login_element
    }
})();
