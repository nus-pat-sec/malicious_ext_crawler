var SelectEntryDlg = (function()
{
    var this_dialog;

    function Open(entries)
    {
        if(GetDlgOpen() === true)
            return;
        SetDlgOpen(true);
        //add polyfill css into current page
        var polyfill_sheet = document.createElement('style');
        polyfill_sheet.innerHTML = "dialog {position: absolute;" +
            "left: 0; right: 0;" +
            "width: -moz-fit-content;" +
            "width: -webkit-fit-content;" +
            "width: fit-content;" +
            "height: -moz-fit-content;" +
            "height: -webkit-fit-content;" +
            "height: fit-content;" +
            "margin: auto;" +
            "border: solid;" +
            "padding: 1em;" +
            "background: white;" +
            "color: black;" +
            "display: block;} " +
            "dialog:not([open]) {display: none;} " +
            "dialog + .backdrop {position: fixed;" +
            "top: 0; right: 0; bottom: 0; left: 0;" +
            "background: rgba(0,0,0,0.1);} " +
            "._dialog_overlay {position: fixed;" +
            "top: 0; right: 0; bottom: 0; left: 0;} " +
            "dialog.fixed {position: fixed;top: 50%;transform: translate(0, -50%);}";

        document.body.appendChild(polyfill_sheet);

        this_dialog = document.createElement("dialog");
        this_dialog.id = "enpast_entry_dlg";
        SetStyle(this_dialog, {'font-family':'sans-serif',
                'font-size':'medium',
                'padding':'0px',
                'background':'#fafafa',
                'border':'2px solid rgb(150, 150, 150)',
                'height':'auto',
                'line-height':'1.6'
        });

        //add title bar main icon
        var title_bar = document.createElement('div');
        SetStyle(title_bar, {
            'background':'#292929',
            'height':'45px',
            'padding':'2px',
            'margin':'0px',
            'display':'flex'
        });
        var iconImg = document.createElement('img');
        SetStyle(iconImg, {
            'margin':'0px 0px 0px 14px',
            'padding':'4px 0px 0px 0px',
            'width':'74px',
            'height':'36px',
            'display':'-webkit-box'
        });
        iconImg.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAAAuCAYAAAAr3zfuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAACrlJREFUeNrsnHmQVcUVxn9vBhgcRAYFRYdVXMAFVDSiCBKBSGJMRLFUYjIuSSrBxKCJCZSyCCYFMRWxlCwarYQCJUOByGgIoohLUAY3UJYCUcCRTQQUUINg54/3XebQc+979773QGsyp6rr9e3u031vnz6nz/m6Z1LOORroq02NAEilcuVvAhwLHAmUAeVAW6AVcARQqjEcsAfYBXwEbALWA1uB7frdXNAve/FF6NWrHgkpHqWAC4GTgROAs4FuElC+9AWwDnhNaR2wFHizQY+yC+kMYBDQAzhLWnMwqAjopHSFKV8JvA68BFQBa/8fhZRyzllz1wwYDPQF+gHtsvAvBVYAHwAfAtuAjTJfHwOfS0tSQDFQArQEjlFqKdN4nLSybZbxVgBzgOeA2RlbPvUUDBhQr4R0NTAE6JXBfK0FngJeVn41UFPg9zkVOB44CRggk3pURNt3gJnAbaG1NTVQXl4/VMk5h4ObHDgvvedgloMbHLR32v0PcSpx0M3BKAfzHOz23nFFKN/w4envqicpEFJbB9PMxw92kPqSBJMptXQw3rznb+q0adasXgnIOUeRFOoDpYD+o28uBB0mV70QtB1YZZ7ren+TJtU7xyEQ0n/lSQX0vTz7bay9YgHwPrABeByoKMA79zb59w+oOftsqKiod0Ky3l1n4G2VzwO+kWOfnYBngQ4R9U8D35LnlwvVKGjeCbTWAkvTkiXQrZttex7Q0XiYyEKkgM/0LrvymL9LgTO1KFMm5lsP/E0e7EDgH4VwHIK0QbZ+bR77xofe5v6qNnhbNjPHvruYPqbXqd+xw7fn811mWuWca5rHfvGpc67KOfeAc+5BpYedc2ucc393zh3pnBuqtn2cc21yGccPZlcpYO0AtNeKSEK3Gxd+HfBt4C09DwBmAM0VIPfXSk5Cp5n8GwfUlJVBkzpbXwA1zdXYxZJnW+AO4EQ9NzUuPwqgq6SppwHLFP8huOssYB+wUNrkU0vFjD8F/gT0BB4BXtB7NFaAvlb8ZdLET4DH1Hck4jBT0A/A+TkI6Sf63Q2c4zkj87QnzdRzRQ5C6m/yCw+o6doVDjusjqHQ72zgQa/ujmAnA/4pEzpH5moUsBz4HTBF8xCY7/lCYG4EtgAPaDEUa3KLtQiHS1jTZfq2yYE6QUH9cvHukAPkFB9WA39VXaiQ5gD3mgmZlhBsLVP+VU9AAc0CPpXH1yUH69xHvxu179VS9+6Z+P4AjPPeFWCY3qNcaMaTEtKZwClCVB4GbhAqslkCWqfyoZrkFhIOZr87Beguwc0CLtZimWPeYxAwUpqa0u+7vtfqC+ltTcCxQiB+lMAVd6Zt0wxeX7DB7k0ooNOBrgHGXddd6ZQtDCjR2CnPuy1V/hM5PY1kcprLKx0uId0lzUHPgUD6R4y5VVtGtZ6P1PejxdwLuAb4ukBrpwXSUgv5rSghOUE/FfqwPsLJ4tDnWmnNtdq6A0u8NjcaAS5NKCQLvD5Rp7ZdKMwYFD4E/NCDn94C/ghcp7KOmlAH/Eradbi05jngegNHzZeAuwCjgTXeaUE7Cf8laWWwUCq0D90q+Gu5zOkSaVy59sOTpH2RKPg0E88MTSAkgHuASVL9BcCV2neKgWuB+03bhxIKaYjJz61T27FjGM9UTbIPxi6TW5zSbyN98581Wev0fjVmHkbqO+4xC/o+nRR0NwIKaLD2zUC4IxU73iyNuhb4GvBzhQFO5XcDlZlc8CBtl5v7ifCzJG7yYuMmf6CyDp4Lfl/CPnsY3qrQNpMnR7uxe/fiKitxl1yCGzECV1NTW7dtWzKXePVq3Pjx6T4ztXvtNdzKlel8VRWuujpe/zt34hYtCsXu/HS3mZSfJZzQpg4+Fu9ilR1l+luaQ3xUafgvC21TWorr3Dk8tWlzYNvi4nT5ySensb7LL8ctXVp3wior6/YV9NG3b7igJk7EnXpqbTvLM2pUbbtJk3D9+tXtv0WLdFvTp3+eZG154H4vlw1PAjXtkg1+FrhI5VsUdyyWmselw4UuBHFPmwS858nl3eMjLZq3TfLq0g7BddfBnXdC+/Ywdy4MHBi0b654Zp9M0gZgPh07wpgxaSjqlVfSv8uXo7joRDNuEx3xrKZnz/QRyowZ1iw29lCRFTi3JJu5w8HrZvWeWQBU4E2VbXfQJEF/w0x/ExJq4PyQIxg/7XHwgINm+/mGDMEVFdl+xobwle6vHzy4VgPSaV5I+wVZ5sqmB+OYOxxcapieTzAx/Q3fvab8X6Y8yfnUDsPXNqGQHo0hpCC9k6GfVSHtr8nQfmrEGEd77cZGtJsQdlQRRlUGZe5tPJhsdJzJbzD5TR5sEoduVqCIUIGkJ8Eu5Ph9gTzWZSHA8LiQPgLT5dP3E4wbUA/veWAc/qIsH/kLk/9LzImxl1UsrPShyTeLubf93jyPKADqf72Cx77C5K7SXhDQj0N4fhDR1zeBo3NAzQNqQfpeR+zzpCiaYc6ZenpnOVHUOkKT7JFA8xj9jBJKEMRU7xZASP64lQYRCBZPiXkuMcEugszWx9QmTPC7VfmrTPlVZqz3hO3lJCR/dU2O0b40Qnt2JNCklorkMRhbISgMTzzaMzMWge4nLzWg0cDz5vmmGGMulGcXQEMnmUVvge3P8hHSC0oBdDIyS/sjTH61yVtNOCpLH9NN/q48D+YsDQAuEG52iRCJ4039Gg9TvNXkq0nfvn3T28eyhSe7zWEqGtsi+h/JWkWazrg3WIdIJQHGAo96A0eZlFlmhZRHOBdhY/UzcdFICkd3Z6m318PKzHtgoKUngAmm/MoQJ8TSPkFjgTXo7OGKLwvHbBT3ZDZTGm1cxOoM7d6I4e5OieBt7GCvaXdhnreLHknggo/zeK81dbu8OhsH1YSMO8XUT3XQwjw/7WCIN24r713GZzqZzUR3CsVupwO9kREuaxNF2i6DiY0ys4+bc5kZCcHdOLRO5qWRxtmtlTwTeCYEsQ/oUyHjh8sbLDN15cC5wKKIMY/RmG8IjD2XA0+Yn8geSMTXJBx09STeO6RNa6VWEam1VpbPd7vpd1uB7un5mtQnJt9xCTTQaZwoTVqosjEhfPtUd1qhNCkIBm8xcP0sHWztzuJBZaMechBsDHIwKO73Jr0XdkWGuiAOWxQxn3iamZN359NEmaXApczXJB0rFCCgX2YwHflS3EuaQ01+Len7HucKsD1P5n6W1282wf7bC0mC867s75XQ3AWp2MF6o56P5WGS1mY9K8o9PemZke/E4Onj8UyMaHdOhnvps035MlP+jMdzhsov9srvz8fcWbeyt2KfFHAZ8FvSV7qS0Fxqb+GsIfx6VL6OwmZzDLAzBk9vmey9JtAMo8VyOjpRezehldCF96i9TmZDlWmkL6ik1G6ZQWM2GWdrYyE0KUj9vBUwNgFvleHb6aDsIFzwTzkoMvk4PKXiidu+yPwFSIk3blg/9p388tT+9jGPKuKmCk9Qt8Tg8aH807+Cf8Hx5aYCCwkHN3uTPixD2yle2wsahHJohIT+0MtO/ugYccugBoEcWiHh4LY6Xkpt3fNe3UUNwvhyhISDX4fgdAsaBPTVEhIOro6AT7YkvNTSIKSDKCQcnO/gMyOglcLEGgSQUEhR9+4KRScINqoRnPIFDRSPzP98OthCAviuIujqhpnPTUj/GwAGMKRX9/pnSQAAAABJRU5ErkJggg==";
        title_bar.appendChild(iconImg);

        var title_txt = document.createElement('p');
        title_txt.innerHTML = 'Select Credential';
        SetStyle(title_txt, {
            'display': 'inline-block',
            'margin':'0px',
            'margin-block-start':'0px',
            'margin-block-end':'0px',
            'padding':'8px 0px 0px 0px',
            'font-size':'18px',
            'vertical-align':'bottom',
            'color':'#ebebeb',
            'height':'44px',
            'width':'650px',
            'text-align':'center'
        });
        title_bar.appendChild(title_txt);
        this_dialog.appendChild(title_bar);

        //////BODY/////

        //cretate table element
        var entry_table = document.createElement("table");      
        SetStyle(entry_table, {
            'width': '96%',
            'border-spacing':'0',
            'border':'1px solid rgb(180, 180, 180)',
            'margin':'10px',
            'vertical-align':'middle',
            'background':'white'
        });

        var thead = document.createElement('thead');
        var thead_row = document.createElement('tr');
        SetStyle(thead_row, {
            'background': '#fafafa'
        });

        var thead_col = document.createElement('th');
        thead_col.innerHTML = '<span>&nbsp;&nbsp;&nbsp;&nbsp;</span>';
        SetStyle(thead_col, {
            'width':'1px',
            'padding':'6px',
            'border-bottom':'1px solid rgb(180, 180, 180)'
        });
        thead_row.appendChild(thead_col);

        thead_col = document.createElement('th');
        thead_col.innerHTML ='Entry';
        SetStyle(thead_col, {
            'width':'120px',
            'padding':'6px',
            'border-bottom':'1px solid rgb(180, 180, 180)',
            'border-right':'1px solid rgb(180, 180, 180)',
            'font-size':'small',
            'vertical-align': 'middle',
            'text-align': 'center'
        });
        thead_row.appendChild(thead_col);

        thead_col = document.createElement('th');
        thead_col.innerHTML = 'Username';
        SetStyle(thead_col, {
            'width':'120px',
            'padding':'6px',
            'border-bottom':'1px solid rgb(180, 180, 180)',
            'border-right':'1px solid rgb(180, 180, 180)',
            'font-size':'small',
            'vertical-align': 'middle',
            'text-align': 'center'
        });
        thead_row.appendChild(thead_col);

        thead_col = document.createElement('th');
        thead_col.innerHTML = 'Container';
        SetStyle(thead_col, {
            'width':'120px',
            'padding':'6px',
            'border-bottom':'1px solid rgb(180, 180, 180)',
            'font-size':'small',
            'vertical-align': 'middle',
            'text-align': 'center'
        });
        thead_row.appendChild(thead_col);

        thead.appendChild(thead_row);
        entry_table.appendChild(thead);

        //create tbody
        var tbdy = document.createElement('tbody');        

        for (var i = 0; i < entries.length ; i++) {
            var tr = document.createElement('tr');

            var td = document.createElement('td');
            td.innerHTML = '<img class="enpast_table_entry_icon" src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAADG9JREFUeNrsXWu0VVUVPoc7vR/vewXkYUgYmKBcRHyEhAo3TAwxswITFONhAY1EaJhoCb5G0Ch5BkFPRA0SDFFeI8rEEUN8hEFSiCClgYqiSPLG04+mozOO56y51t5r77PWPnuPsX7ccfdea875fWfvteaac65MLpfLpK1yW3oZXgR0JOBqAu4k4AEC1hOwnYB3CMgVtGMEvEHASwSsIWAeATcT0I+AmtSafgDejoARBCwhYE8RkIO2DwnYQsAsAgYS0Ci1tjug1xIwjoCnGahcDO0/BCxmMlSlKJQH+B4ELCTgcEygl2qvE/A9AlqlqMQDfC/+RuccawcJmEFAuxSlaIDvTMCjDgJf2D7gSWfjFDU7wIOAuwg44gH4+e2fBAxMEQwHfk8C/h4SiL0EPEHAjwm4iYC+BHTnJWILnkS2IaATzysGETCRgAU8sQw7x3iQgNoUTTPgswzCsQAGP8FzhPEE1BGQDSlLYwL6E3AvAVtDvA16pcjqGbwJAcsCGHkzAbcQ0DZi+c4jYDoBbxvKd5SAMSnCauOeSsBfDA37FAEDykTU8QS8ZijvrNR3UHqWv8vAkM8ScIkDclezI2qvgey/JaA6Rf3/RjyD/fA6xttHwMiw3/aIPJI/NSDBipQE/zNcJ/am6RhtteuOFgLqDT4LKyr6c0DAKQS8rDmzv9W1X71CrxYErNIkwYJKBb+a19mSgfYTcLmH+jUg4IeaJLi1EgkwV8MwbxDQ3XM9x2m+4T5fSeAP0dxl65wQfW/Q0PetithIIqADv9ZVxnibgK4J01vnTbDWl3lOGEOsFoxwiIDeCdX9Pg0SjEwy+F/TMMD1CdY/y0s/lf7vEtA6ico30Vjvzy+jfGcScDtvJL3OE7McAcd5Xb+SgAkEdAw5Tg0BOytuachhUyql/1GOIAreHn7KMEB0FQHnhRizdx7BSo1xVpLAryXgPUHhPmVw1jwcMlJ4NgENA44/Xej/0SQR4A5B2V/ELM+nCdhhKfLnhSDLNwKaEvBvgWBdkwA+CHhTCLFuHaM8JnsPuu2VIDoQ8HWh358ngQDXCUpOj1GWZjzXiCIGcAMBJxnKQ0weVaRxre8EeFJY87eLUZb5EQeCTgkg0yihz3E+g3+qkK0zN0ZZztXMHHqcgMEcNFpLwOkEXM95hTkNJ1YHQ7mqhTS2P/tMgFsEg10YoyxLNKKH64U+rtVwY98fQDZp1/A0XwmwTqHU1hjlaMlBmaot5y6afV0shIrvI4AM5TtLIMA3fAS/sZDM8V2HXNDDi3jrRhEwjYAfcYp51mBZe0kAGZ9X9Pc7HwlQLxipR4yyzFTIsTM/LIt/jbuL3LeJgP55bu0DNgM8OO9AtTua9Y0Adwjf22yMsqh2IGcb/BJzBCziyeEjNn35XIhCNW4X3wiwVKHMkphleVZnmcUpYrqZPn9Q/H9ZABkb8rq/VJ9DfCPANoUyE2OWZYNClm8GIIDUlgSUc6Oiz3t9Ar9KmHUPilmelapMnYJ7n7FAgNkB5VzoylszrMFPEwzUOWZ5Zihk2UVAg7x7uwZI9yps3woo5+2KPjf6RIALBANVxSyPFIR6Y8H9zXn5FzQ1vEdAOb+q6PNVnwgwQKHIe2WQp0b4JO0j4Iwiz3USnFlWgSLgMlXlEZ8IcLVCkdfKJNNvBOD2FIvNz6tVcFSTANNCyNhL1bdPBBjmggu4QKZzNDeD7i7x/KUcsKmTzNI6oIzdUgJEK5du9u7AEs/XaaaBLw8o39lJIYBznwCWq6lmQMhCRR91QnzjR+0a25PndBJoRzadkLDFQh/9NeoX7TItKcsRyiVD59JloD35OguhWCM0+rhN4y0w3lCuoaq4w9QRZFfGWi7h9rFwbB2Ccvr3nzRWFo0MZPp+IiKDXHMFC7L25hqCcwj4sskuJWcTSQUsb7LkCl6U8elyaTOojG7mHAEvGvS1WdHPZN8MszQRGxuynq04t0FFgnM0+mkupItd5ZthnAkIiUHXeQIBfqDRx+VCH5/wzSj9XAkJi0HXboKuf9PoY7ZqSemjUZwJCo1J3y0CCdorns0S8C/Fs7/21SjrXHQJR6TrZIEAQxTPXiQ8O9hXo4wXFLsgQQT4bNAcSAJ+pXjuCAHNfTWKM6lhMejaUPjkrSvxXAtOKbO6seSSYZxJDo1B1+dMN8EImGR7U8k1o1xnO5fOYV1/KejapOD+Wo5GUrmSq303ilMFIiLWdYJAgG4F998l3D85Kb8Mp0rERKin5MwZlHdvRz5hTPXDaJUUAjhXJCoiPU8XCPDtvHtXkyOVU+IyjpNl4izrKO2CzuD7hgm2eD9xxSJdLxRpUU9VyNljfDrKAcEOkzJJvCqhVKyQhraNgBcF/bcFrT3oi4ESXSza8NygYq2fj0oPIOD3XGxhLQGfU9zbQSOqdq93+fD6jh1Vm+OjwmNKnIDxJcUziT0wgiuKBQF/q2kUsQvKTgwaxWpwZEydZzapDwD+Ae/KwmqGRTdTPJ/IQ6M0Kn4V84Fck0Tw90thXxxPl6hj4/goPBMCfCeJ4OcIuE+zv0QdHMk6HYs6k7hcit2jqdhDJtk/nKmz2+Do2BEuvw00j8Gd51VgLAFTowC/gAQmh0dvJOBiR221Xfrlp+AXH8eb4+MFPVQ6bPDtta8L/gM2kj55z2BZgKXUXzkGsa0DNlPlDG7yBfisEKse2feMx55gUJalcMWwhoCbOV4/G1IWIqAPl3J9nk8Re5Nf49UlnnlMId8OX8CfVw7wC+Q4l4CXQvrW9xLwBCeAjuZSL3UckHEyxyqczH93J+BKPuXzJ1wzUBWw+UgJuRep5EnBN5MHBEzRyMItVzvT0Mt5JCngz4654HMnzt13jQCDisg6TXjmJBfBrxJeXfltahnl7MXfeFcI0KWIjFOEZ2pdBP8h18EvkLkHF1Q4XEbwS80B/CGAj+AXyF/Lk7anNesA2mhv8aoAJWSSzkpq4yP498QgTyOehd9AwNkBnm/HbuIlBq5lnXac1/aT+MygKkEOKSeyowvgVxOwXNMAt4Ucqxn/UlWtd5Eq3QtCehY7cs3CO9lRtZ53H98pkYS5m2P2HudjZsayXE0Mx3WbAAz+iijBZ4/eXI1j1nK6sfQeeU/dJUAc4PM4qyy9fp9JCVAe8CeGGOd8i9/fLR4SQEqCOaUcQjUWDjrKb2NCjjXUIgFmRmSPhvxLXcpzoZGmBz4q+nZrGcjg/zEO8Hm8Gy2Bv52AlhHYo2mJA5rW2SABAfc7Q4C4wbdIgFdUhZVCyne3YtyxFvqf44Qr2AD8EwSMsjhuGAIc5Bq+LSO0i+p4ts0W+n9QlfgZF/g1gqL54A+1PLZEgCtL+AJqYrKNZJdLQ/a/uqxVv8sJviYB+pZ5li4d174qQoJtTDT4nhCga1RHv3H/O6Mil87GiA74R20VH+QYgvPZbfozDps64jIBWO4nBRnXhLDH0dirfnJGyhZN8K+yNGZPzTN4XCTAFRpyXhGg37ZBTiXzEfwaofqX6wTIErBJ49wf042gPianlHoJPo87MsRSr6cjLtsvaMg617DP0UJ/F9lUoI0m+AeDvM5COjtUUbrOFD/UPBr2Kwb9zQyaMW0qeHvh5Kt88OsjMFyQ3b4TrqVCc+6AlMz5vu6qgCfBJV3biQCfZXjZAPhXOfLIyergmkmve6RtXN5jOB7kQErfwG8gLHWe48yefs5FwBbXp6FmAsoOVdkaAq4Vnh8VVtB2muDvjzJzlgs9qcYfnfHs4nN7P9Cw7e5Sk1iNcPX2YYVcpgn+ZyI2Vl9BhvqMh5fBJtZBnu1n8569UHjmBRsCHo4KfD64YDAbQWrzBTk+mfH00tjLz2/rCRjIySo7bR4jW0q4qMAfolG+VLcdJaCBxwSoIuBhy3kEhwhoETUB+gXss2vANOySpU4znl8cO7nYok1m2BLMeqSpQQEI3bYyk4CL3wQLLNjjXWuVvyMiwDLLBJiVScjF+wWThCNdpTbUpkBREGC5ZQIMyyTsIuCygBtfs2wL4joBNnl/yFFpO9Vy7QSdBNQP2buYrRQCHIo6kNMhInTmjbC9JYBfa3XHr8wEmKqR1Fnr87Iv5PygjoAvEjCcS+a3inrQuAkwJZNeTrEuJUBKgJQAKQFSAqQEsEEA9nZtTAmQDAJ015yxf9RaaiwBUwJ4RIAo2rjU6pVLgOMEfCq1euUSYGxq8colwJjU2m4SYGcKfmUTYEQKfkqC4Zqh4SZts828wfSK6Mrlcmmr4PbfAQAgKsZ27Iix3wAAAABJRU5ErkJggg==" style="width:24px; margin-top: 3px" align="right"/>';

            if(i < entries.length - 1)
                td.style.borderBottom = '1px solid rgb(180, 180, 180)';
            tr.appendChild(td);

            td = document.createElement('td');
            td.innerHTML = entries[i].entryname;
            SetStyle(td, {
                'width':'120px',
                'padding':'6px',
                'font-size':'small',
                'vertical-align': 'middle',
                'text-align': 'center'
            });
            if(i < entries.length-1)
                td.style.borderBottom = '1px solid rgb(180, 180, 180)';

            td.style.fontSize = 'medium';
            tr.appendChild(td);

            td = document.createElement('td');
            td.innerHTML = '<a class="enpast_table_tr_bg_autofill" style="font-size:medium; text-decoration: underline; cursor: pointer;" data-enpast-pwd="' + entries[i].password + '" ' +
                'data-enpast-user="' + entries[i].username + '">' + entries[i].username + '</a>' ;
            SetStyle(thead_col, {
                'width':'120px',
                'padding':'6px',
                'font-size':'small',
                'vertical-align': 'middle',
                'text-align': 'center'
            });
            if(i < entries.length - 1)
                td.style.borderBottom = '1px solid rgb(180, 180, 180)';
            tr.appendChild(td);

            td = document.createElement('td');
            td.innerHTML = entries[i].containername;
            SetStyle(thead_col, {
                'width':'120px',
                'padding':'6px',
                'font-size':'small',
                'vertical-align': 'middle',
                'text-align': 'center'
            });
            if(i < entries.length-1)
                td.style.borderBottom = '1px solid rgb(180, 180, 180)';
            tr.appendChild(td);

            tbdy.appendChild(tr);
        }
        entry_table.appendChild(tbdy);
        this_dialog.appendChild(entry_table);

        //create buttons
        var divBottom = document.createElement('div');
        SetStyle(divBottom, {
            'text-align':'right',
            'margin':'10px'
        });

        var buttonClose = document.createElement("button");
        buttonClose.textContent = "Close";
        SetStyle(buttonClose, {
            'margin':'6px 10px 10px 15px',
            'height':'40px',
            'width':'120px',
            'font-family':'sans-serif',
            'font-size':'medium',
            'border-style':'groove',
            'color':'#292929',
            'border-color':'#292929',
            'background':'#ebebeb',
            'outline':'none'
        });
        buttonClose.addEventListener("click", function() {
            Close();
        });
        divBottom.appendChild(buttonClose);
        this_dialog.appendChild(divBottom);

        document.body.appendChild(this_dialog);
        dialogPolyfill.registerDialog(this_dialog);
        this_dialog.showModal();
    }

    function Close()
    {
        // Close dialog
        this_dialog.close();
        document.body.removeChild(this_dialog);

        // Mark a flag
        setTimeout(function() {
            SetDlgOpen(false);
        }, 500);
    }

    $(document).on('click', '.enpast_table_tr_bg_autofill', function() {        
        // Get username and password
        var username = $(this).attr('data-enpast-user');
        var password  = $(this).attr('data-enpast-pwd');

        PageCheck.write_login_email(username);
        PageCheck.write_login_password(password);

        Close();
    });

    return {
        Open: Open,
        Close: Close
    };
})();