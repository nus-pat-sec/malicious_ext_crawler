// background script

var enpast_login_details_tab_id = "";
var enpast_login_details_url = "";
var enpast_login_details_username = "";
var enpast_login_details_password = "";
var enpast_login_details_confirmed = false;

function ShowDisconnectionIcon()
{
    chrome.browserAction.setBadgeBackgroundColor({ color: [255, 0, 0, 255] });
    chrome.browserAction.setBadgeText ( { text: "X" } );
}

function RemoveDisconnectionIcon()
{
    chrome.browserAction.setBadgeBackgroundColor({ color: [0, 0, 255, 255] });
    chrome.browserAction.setBadgeText ( { text: "" } );
}

function SaveLoginDetails(tab_id, url, username, password)
{
    if(url.includes("https://accounts.google.com"))
    {
        if(username.length > 0)
        {
            if(!username.includes("@"))
            {
                username = username + "@gmail.com";
            }
        }
    }

    if(password == "") {
        enpast_login_details_tab_id = tab_id;
        enpast_login_details_url = url;
        enpast_login_details_username = username;
        enpast_login_details_password = password; 
    } else {
        if(tab_id == enpast_login_details_tab_id && 
            url == enpast_login_details_url &&
            username == "" &&
            enpast_login_details_username != "") {
            enpast_login_details_password = password;
        } else {
            enpast_login_details_tab_id = tab_id;
            enpast_login_details_url = url;
            enpast_login_details_username = username;
            enpast_login_details_password = password;    
        }
    }

    PrintLoginDetails();
}

function SetLoginDetailsConfirmed()
{
    enpast_login_details_confirmed = true;
}

function PrintLoginDetails()
{
    PrintLog("Login State>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    PrintLog("tab_id -> " + enpast_login_details_tab_id);
    PrintLog("url -> " + enpast_login_details_url);
    PrintLog("username -> " + enpast_login_details_username);
    PrintLog("password -> " + enpast_login_details_password);
    PrintLog("confirmed -> " + enpast_login_details_confirmed);
    PrintLog("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
}

function ClearLoginDetails()
{
    PrintLog("Cleared login details");
    enpast_login_details_tab_id = "";
    enpast_login_details_url = "";
    enpast_login_details_username = "";
    enpast_login_details_password = "";
    enpast_login_details_confirmed = false;
}

function GetLoginDetailsTabId(){
    return enpast_login_details_tab_id;
}

function GetLoginDetailsUrl(){
    return enpast_login_details_url;
}

function GetLoginDetailsUsername(){
    return enpast_login_details_username;
}

function GetLoginDetailsPassword(){
    return enpast_login_details_password;
}

function GetLoginDetailsConfirmed(){
    return enpast_login_details_confirmed;
}

