
var WebSocketTimer;

var tabids_injected = [];
////////////////////////////////////////////////////////////////////////////////////////////////////
chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab)
{
   if (changeInfo.status == 'complete')
    {
        if (tab.active) // Reloading state on the same page
        {
            var injected = false;
            tabids_injected.forEach(function(item) {
                if(item == tabId) {
                    injected = true;
                    return;
                }
            });
            if(!injected){
                tabids_injected.push(tabId);
                setInterval(function() {                
                    if(GetLoginDetailsTabId() == tabId) {
                        PrintLog("Send SAVE command to content script");
                        try{
                            chrome.tabs.sendMessage(tabId, {                // will be started in main.js
                                m: MSG_RUN_SAVE_MODULE,
                                url: GetLoginDetailsUrl(),
                                username: GetLoginDetailsUsername(),
                                password: GetLoginDetailsPassword(),
                                confirmed: GetLoginDetailsConfirmed()
                            });
                        } catch(exception) {
                            PrintLog(`${exception}`);
                        }
                    }
                }, 1000);            
            }
        }
    }
});

chrome.tabs.onActivated.addListener(function(){
    PrintLog("Activated tab - clear storage");
});

////////////////////////////////////////////////////////////////////////////////////////////////////
//Listen for  message:
chrome.runtime.onMessage.addListener(MessageHandler);

function MessageHandler(message, sender, sendResponse)
{
    var tab_id = sender.tab.id;

    //Message format unrecognized
    if (!message || !message.m) 
        return; 

    if(message.m == MSG_WEBSOCKET_REQUEST) {
        PrintLog("Received new message from content tab : " + sender.tab.id);
        PrintLog(message);

        var msg = message.msg;
        if(msg == ENPAST_WEBSOCKET_MESSAGE_GET_ENTRIES) {
            EnpastWebSocket.GetEntries(
                tab_id, 
                message.url
            );
        } else if(msg == ENPAST_WEBSOCKET_MESSAGE_GET_CONTAINER_FOLDER_LIST) {
            EnpastWebSocket.GetContainerFolderList(
                tab_id
            );            
        } else if(msg == ENPAST_WEBSOCKET_MESSAGE_SAVE_ENTRY) {
            EnpastWebSocket.SaveEntry(
                tab_id,
                message.url, 
                message.entryname, 
                message.username, 
                message.password, 
                message.pcid, 
                message.pfid
            );
        }
    } else if(message.m == MSG_SAVE_LOGIN_STATE) {
        SaveLoginDetails(tab_id, message.url, message.username, message.password);
    } else if(message.m == MSG_CLEAR_LOGIN_STATE) {
        PrintLog("Received new message from content tab : " + sender.tab.id);
        PrintLog(message);

        ClearLoginDetails();
    } else if(message.m == MSG_SAVE_LOGIN_CONFIRM) {
        SetLoginDetailsConfirmed();
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////

function StopReconnection()
{
    clearInterval(WebSocketTimer);
}

function CreateWebSocket()
{
    EnpastWebSocket.Create(ENPAST_WEBSOCKET_URL);

    StopReconnection();
}

function ConnectWebSocket()
{
    WebSocketTimer = setInterval(CreateWebSocket, 2000);
}

function ClosedWebSocket()
{
    ConnectWebSocket(); 
    
    if(typeof browser == 'undefined') {
        chrome.tabs.getAllInWindow(null, function(tabs) {
            $.each(tabs, function() {
                PrintLog("Sent null state to tab : " + this.id);
                // u can use 'this.id' to work with evey tab 
                if(this.id != -1) {
                    chrome.tabs.sendMessage(this.id, {
                        m: MSG_APPLICATION_STATE,
                        e: null
                    });
                }
            });
        });

    }else{
        var querying = gMyBrowser.tabs.query({});
        querying.then(function(tabs) {
            for (let tab of tabs) {
                if(tab.id != -1){
                    chrome.tabs.sendMessage(tab.id, {
                        m: MSG_APPLICATION_STATE,
                        e: null
                    });
                }
            }
        }, function(error) {
            PrintLog(`Error: ${error}`);
        });
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

// Entry point of background process
ConnectWebSocket();

/////////////////////////////////////////////////////////////////////////////////////////////////////
function ReceivedWebSocketResponse(message)
{
    var msgObj = JSON.parse(message);

    if(msgObj.msg == ENPAST_WEBSOCKET_MESSAGE_ALLOWED_CONNECTION)                       // "AllowedConnection"
        ProcessAllowedConnectionOnBackground(message);
    else if(msgObj.msg == ENPAST_WEBSOCKET_MESSAGE_APPLICATION_STATE)                   // "ApplicationState"
        ProcessApplicationStateOnBackground(message);
    else if(msgObj.msg == ENPAST_WEBSOCKET_MESSAGE_GET_ENTRIES)                         // "GetEntries"
        ProcessGetEntriesOnBackground(message);
    else if(msgObj.msg == ENPAST_WEBSOCKET_MESSAGE_GET_CONTAINER_FOLDER_LIST)           // "GetContainerFolderList"
        ProcessGetContainerFolderListOnBackground(message);
    else if(msgObj.msg == ENPAST_WEBSOCKET_MESSAGE_UPDATED_CONTAINER_FOLDER_LIST)       // "GetContainerFolderList"
        ProcessUpdateContainerFolderListOnBackground(message);
    else if(msgObj.msg == ENPAST_WEBSOCKET_MESSAGE_SAVE_ENTRY)                          // "SaveEntry"
        ProcessSaveEntryOnBackground(message);
}

// Process of "AllowedConnection" message
function ProcessAllowedConnectionOnBackground(response)
{
    if(typeof browser == 'undefined') {
        chrome.tabs.getAllInWindow(null, function(tabs) {
            $.each(tabs, function() {
                PrintLog("Sent allowed message to tab : " + this.id);
                // u can use 'this.id' to work with evey tab 
                if(this.id != -1) {
                    chrome.tabs.sendMessage(this.id, {
                        m: MSG_ALLOWED_CONNECTION,
                        e: response
                    });
                }
            });
        });

    }else{
        var querying = gMyBrowser.tabs.query({});
        querying.then(function(tabs) {
            for (let tab of tabs) {
                if(tab.id != -1) {
                    chrome.tabs.sendMessage(tab.id, {
                        m: MSG_ALLOWED_CONNECTION,
                        e: response
                    });
                }
            }
        }, function(error) {
            // console.log(`Error: ${error}`);
        });
    }
}

// Process of "ApplicationState" message
function ProcessApplicationStateOnBackground(response)
{
    var responseObj = JSON.parse(response);
    var is_logined = responseObj.is_logined;

    PrintLog("Logged in - " + is_logined);

    if(!is_logined) {
        ShowDisconnectionIcon();
    }else{
        RemoveDisconnectionIcon();
    }

    if(typeof browser == 'undefined') {
        chrome.tabs.getAllInWindow(null, function(tabs) {
            $.each(tabs, function() {
                // u can use 'this.id' to work with evey tab 
                if(this.id != -1) {
                    chrome.tabs.sendMessage(this.id, {
                        m: MSG_APPLICATION_STATE,
                        e: response
                    });
                }
            });
        });

    }else{
        var querying = gMyBrowser.tabs.query({});
        querying.then(function(tabs) {
            for (let tab of tabs) {
                if(tab.id != -1) {
                    chrome.tabs.sendMessage(tab.id, {
                        m: MSG_APPLICATION_STATE,
                        e: response
                    });
                }
            }
        }, function(error) {
            // console.log(`Error: ${error}`);
        });
    }
}

// Process of "GetEntries" message
function ProcessGetEntriesOnBackground(response)
{   
    var msgObj = JSON.parse(response);

    chrome.tabs.sendMessage(msgObj.tab_id, {
        m: MSG_ENTRY_LIST,
        e: response
    });
}

// Process of "GetContainerFolderList" message
function ProcessGetContainerFolderListOnBackground(response)
{
    var msgObj = JSON.parse(response);

    chrome.tabs.sendMessage(msgObj.tab_id, {
        m: MSG_CONTAINER_FOLDER_LIST,
        e: response
    });
}

function ProcessUpdateContainerFolderListOnBackground(response)
{
    if(typeof browser == 'undefined')
    {
        chrome.tabs.getAllInWindow(null, function(tabs) {
            $.each(tabs, function() {
                // u can use 'this.id' to work with evey tab 
                if(this.id != -1) {
                    chrome.tabs.sendMessage(this.id, {
                        m: MSG_UPDATED_CONTAINER_FOLDER_LIST,
                        e: response
                    });
                }
            });
        });

    }else{
        var querying = gMyBrowser.tabs.query({});
        querying.then(function(tabs) {
            for (let tab of tabs) {
                if(tab.id != -1){
                    chrome.tabs.sendMessage(tab.id, {
                        m: MSG_UPDATED_CONTAINER_FOLDER_LIST,
                        e: response
                    });
                }
            }
        }, function(error) {
            // console.log(`Error: ${error}`);
        });
    }

}

// Process of "SaveEntry" message
function ProcessSaveEntryOnBackground(response)
{
    var msgObj = JSON.parse(response);

    chrome.tabs.sendMessage(msgObj.tab_id, {
        m: MSG_SAVE_ENTRY_RESULT,
        e: response
    });
}
////////////////////////////////////////////////////////////////////////////////////////////////////