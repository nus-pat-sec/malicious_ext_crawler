
var EnpastWebSocket = (function()
{
    var websocket = null;
    
    ShowDisconnectionIcon();

    function Create(url)
    {
        try {
            if (typeof MozWebSocket == 'function')
                WebSocket = MozWebSocket;

            // Close websocket if it was opened.
            if ( websocket && websocket.readyState == 1 )
                websocket.close();

            // Create websocket
            websocket = new WebSocket(url);

            // Send - event
            websocket.onopen = function (evt) {
                PrintLog("Created new WebSocket");
                
                // "Connect" : send messgae to desktop application
                SendMessage(
                    JSON.stringify({
                        msg: ENPAST_WEBSOCKET_MESSAGE_CONNECT,
                        data: JSON.stringify({
                            extension_id : gExtensionId,
                            browser_agent : gBrowserAgent
                        })
                    })
                );
            };

            // Close - event
            websocket.onclose = function (evt) {
                PrintLog("Closed websocket");
                websocket = null;

                ClosedWebSocket();

                ShowDisconnectionIcon();               
            };

            // Receive - event
            websocket.onmessage = function (evt)
            {
                var message = evt.data;

                PrintLog("Received new messeage from desktop application.");
                PrintLog(message);

                ReceivedWebSocketResponse(message);                
            };

            // Error - event
            websocket.onerror = function (evt)
            {                
                PrintLog("Error websocket");
                PrintLog(evt);

                websocket = null;
                ShowDisconnectionIcon();           
            };
        } catch (exception) {

        }
    }

    function SendMessage(message)
    {
        try{
            if ( websocket && websocket.readyState == 1 ) {
                websocket.send( message );
            }
        } catch(exception) {
            CloseWebSocket();
        }
    }

    // Close - function
    function CloseWebSocket()
    {
        if (websocket && websocket.readyState == 1 )
            websocket.close();
    }

    // Send WebSocket message
    function GetEntries(tab_id, url)
    {
        // "GetEntries" : send message to desktop application
        SendMessage(
            JSON.stringify({
                tab_id: tab_id,
                msg: ENPAST_WEBSOCKET_MESSAGE_GET_ENTRIES,
                data: JSON.stringify({
                    url : url
                })
            })
        );
    }

    // Send WebSocket message
    function GetContainerFolderList(tab_id)
    {
        // "GetContainerFolderList" : send message to desktop application
        SendMessage(
            JSON.stringify({
                tab_id: tab_id,
                msg: ENPAST_WEBSOCKET_MESSAGE_GET_CONTAINER_FOLDER_LIST,
                data: JSON.stringify({
                })
            })
        );
    }

    // Send WebSocket message
    function SaveEntry(tab_id, url, entryname, username, password, pcid, pfid)
    {
        // "SaveEntry" : send message to desktop application
        SendMessage(
            JSON.stringify({
                tab_id: tab_id,
                msg: ENPAST_WEBSOCKET_MESSAGE_SAVE_ENTRY,
                data: JSON.stringify({
                    url : url,
                    name : entryname,
                    username : username,
                    password : password,
                    pcid : pcid,
                    pfid : pfid
                })
            })
        );
    }

    return {
        Create: Create,
        GetEntries: GetEntries,
        GetContainerFolderList: GetContainerFolderList,
        SaveEntry: SaveEntry
    };
})();
