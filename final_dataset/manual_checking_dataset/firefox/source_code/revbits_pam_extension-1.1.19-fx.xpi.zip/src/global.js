/**
 * Created by RevBits on 1/5/2019.
 */

var gOpenedEntries;

// ex: https://www.facebook.com
var gHostName = window.location.origin;

// ex1: https://www.facebook.com/
// ex2: https://www.facebook.com/recover/initiate/?cuid=AYiNInCS4wHdAnQzR2M2JGZYvvOVIbT0XNjwQVgiyrvCX2Fi7VIS55YRiaoolBgwQ31i5IVUE2cdBZVr5t952g1Ot-zLtzxHIBIa_rbqteuxDLIUZ99ArCZl76n7EW45LQttPr8fZN5MF2d1E77i6OYFNmwCQiFMp0d-0Cy-Llq6bg&ars=device_based_login
var gUrlFullString = window.location.href;

// ex: "https://www.facebook.com" + "/recover/initiate/"
var gUrlString = window.location.origin + window.location.pathname;

var gMyBrowser = (typeof browser !== 'undefined') ? browser : window.chrome;

var gIsOpenedWebSocket = false;

// Extension Information
var gBrowserName = (function(agent){
    switch(true){
        case agent.indexOf("edge") > -1: return "edge";
        case agent.indexOf("opr") > -1: return "opera";
        case agent.indexOf("chrome") > -1 && !!window.chrome: return "chrome";
        case agent.indexOf("trident") > -1: return "ie";
        case agent.indexOf("firefox") > -1: return "firefox";
        case agent.indexOf("safari") > -1: return "safari";
        default: return "other";
    }
})(window.navigator.userAgent.toLowerCase()).toUpperCase();

var gExtensionId = gMyBrowser.i18n.getMessage("@@extension_id");
var gBrowserAgent = "REVBITS_PAM_" + gBrowserName + "_EXTENSION";

// Application Global Parameters
var gExtensionToken = "";
var gDesktopApplicationVersion = "Unknown";
var gDesktopApplicationIsLogined = false;

var gIsOpenedDialog = false;

if(typeof browser !== 'undefined')
    ENPAST_WEBSOCKET_URL = 'ws://127.0.0.1:59801';

var gEnpastSaveUrl = "";
var gEnpastSaveUsername = "";
var gEnpastSavePassword = "";

function PrintLog(msg){
    if(false){
        if(typeof msg === 'object'){
            console.log("Happ: >>");
            console.log(msg);
        }else{
            console.log("Happ: " + msg);
        }
    }
}