/**
 * Created by RevBits on 1/7/2019.
 */

// Enpast WebSocket URL
var ENPAST_WEBSOCKET_URL                                    = 'wss://local.revbits.com:59800';

// Enpast WebSocket messages
var ENPAST_WEBSOCKET_MESSAGE_CONNECT                        = 'Connect';
var ENPAST_WEBSOCKET_MESSAGE_APPLICATION_STATE              = 'ApplicationState';
var ENPAST_WEBSOCKET_MESSAGE_ALLOWED_CONNECTION             = 'AllowedConnection';
var ENPAST_WEBSOCKET_MESSAGE_GET_ENTRIES                    = 'GetEntries';
var ENPAST_WEBSOCKET_MESSAGE_GET_CONTAINER_FOLDER_LIST      = 'GetContainerFolderList';
var ENPAST_WEBSOCKET_MESSAGE_SAVE_ENTRY                     = 'SaveEntry';
var ENPAST_WEBSOCKET_MESSAGE_UPDATED_CONTAINER_FOLDER_LIST  = 'UpdatedContainerFolderList';

// Internal Messages
var MSG_SAVE_LOGIN_STATE                                    = "MSG_SAVE_LOGIN_STATE";       // send to background script
var MSG_SAVE_LOGIN_CONFIRM                                  = "MSG_SAVE_LOGIN_CONFIRM";     // send to background script
var MSG_CLEAR_LOGIN_STATE                                   = "MSG_CLEAR_LOGIN_STATE";      // send to background script
var MSG_RUN_SAVE_MODULE                                     = "MSG_RUN_SAVE_MODULE";        // send to content script
var MSG_WEBSOCKET_REQUEST                                   = "MSG_WEBSOCKET_REQUEST";
var MSG_ALLOWED_CONNECTION                                  = "MSG_ALLOWED_CONNECTION";
var MSG_APPLICATION_STATE                                   = "MSG_APPLICATION_STATE";
var MSG_ENTRY_LIST                                          = "MSG_ENTRY_LIST";
var MSG_CONTAINER_FOLDER_LIST                               = "MSG_CONTAINER_FOLDER_LIST";
var MSG_SAVE_ENTRY_RESULT                                   = "MSG_SAVE_ENTRY_RESULT";
var MSG_UPDATED_CONTAINER_FOLDER_LIST                       = "MSG_UPDATED_CONTAINER_FOLDER_LIST";

// Login Information Patterns
var USERNAME_PASSWORD_PATTERN = [
    "input[type='text']",
    "input[type='email']",
    "input[type='password']",
    "input:not([type])"
].join();

var USERNAME_ATTR_PATTERN =[
    {"type":"email"},
    {"name":"username"},
	{"name":"user"},
    {"name":"login"},
    {"name":"log_in"},
    {"name":"signin"},
    {"name":"sign_in"},
    {"name":"email"},
    {"name":"email-address"},
    {"name":"identifier"},
    {"name":"user[email]"},
    {"name":"user[login]"},
    {"name":"pma_username"},
    {"name":"reg_email__"},
    {"name":"yid"},
    {"name":"loginfmt"},
    {"name":"session_key"},
    {"id":"username"},
    {"id":"email"},
    {"id":"login-username"},
    {"id":"signin-username"},
    {"id":"id_username"},
    {"id":"user_login"},
    {"id":"user_signin"},
    {"id":"user_email"},
    {"id":"user[email]"},
    {"id":"identifier"},
    {"id":"identifierid"},
    {"id":"input_username"},
    {"id":"usernamereg-yid"},
    {"id":"ctl00_content_main_txtemail"},
    {"autocomplete":"username"},
    {"autocomplete":"email"},
    {"aria-label":"email"},
    {"aria-label":"username"},
    {"aria-label":"enter your email, phone, or skype."},
    {"aria-label":"type your email or phone number"},
    {"placeholder":"email"},
    {"placeholder":"e-mail"},
    {"placeholder":"username"},
    {"placeholder":"please enter email address"},
    {"placeholder":"email address"},
    {"placeholder":"your email"},
    {"placeholder":"email or username"},
    {"placeholder":"enter your email"},
    {"placeholder":"email, phone, or skype"},
    {"placeholder":"account number, email or phone"},
    {"placeholder":"email or phone"},
    {"placeholder":"userid"},
    {"placeholder":"phone, email or username"},
    {"placeholder":"user id (your email address)"},
    {"placeholder":"enter email"},
    {"placeholder":"you@example.com"},
    {"placeholder":"john@snow.com"},
    {"placeholder":"name@domain.eg"}
];

var PASSWORD_ATTR_PATTERN = [
    {"type":"password"},
    {"name":"password"},
    {"name":"password1"},
    {"name":"password2"},
    {"name":"passwd"},
    {"name":"session_password"},
    {"name":"user[password]"},
    {"name":"pma_password"},
    {"name":"session_password"},
    {"id":"password"},
    {"id":"password1"},
    {"id":"password2"},
    {"id":"pass"},
    {"id":"passwd"},
    {"id":"id_password"},
    {"id":"id_password1"},
    {"id":"id_password2"},
    {"id":"user_password"},
    {"id":"user[password]"},
    {"id":"input_password"},
    {"id":"ctl00_content_main_txtpassword"},
    {"aria-label":"password"},
    {"aria-label":"id_password"},
    {"aria-label":"user_password"},
    {"aria-label":"session_password"},
    {"aria-label":"input_password"},
    {"placeholder":"password"},
    {"placeholder":"please enter a password"},
    {"placeholder":"your password"},
    {"placeholder":"create a password"},
    {"placeholder":"create password"}
];

var SUBMIT_PATTERN = [
    ":button",
    "input[type='submit']",
    "div[id='passwordNext']",
    "div[id='identifierNext']",
    "div[id='accountDetailsNext']",
    "div[id='login_button']",
    "div[id='signin_button']",
    "div[id='signup_button']",
    "div[id='register_button']",
    "div[id='create_button']",
    "div[id='join_button']",
    "div[id='loginbutton']",
    "div[id='signinbutton']",
    "div[id='signupbutton']",
    "div[id='registerbutton']",
    "div[id='createbutton']",
    "div[id='joinbutton']",
    "div[id='button_login']",
    "div[id='button_signin']",
    "div[id='button_signup']",
    "div[id='button_register']",
    "div[id='button_create']",
    "div[id='button_join']",
    "div[id='buttonlogin']",
    "div[id='buttonsignin']",
    "div[id='buttonsignup']",
    "div[id='buttonregister']",
    "div[id='buttoncreate']",
    "div[id='buttonjoin']",
    "a[type='button']",
    "a[id='buttonsigningo']",
    "a[id='buttonsignin']",
    "a[id='buttonsignup']",
    "a[id='buttonregister']",
    "a[id='buttoncreate']",
    "a[id='buttonlogin']",
    "a[id='buttonjoin']",
    "a[id='button_signingo']",
    "a[id='button_signin']",
    "a[id='button_signup']",
    "a[id='button_register']",
    "a[id='button_create']",
    "a[id='button_login']",
    "a[id='button_join']",
    "a[id='signingo_button']",
    "a[id='signin_button']",
    "a[id='signup_button']",
    "a[id='register_button']",
    "a[id='create_button']",
    "a[id='login_button']",
    "a[id='join_button']",
    "a[id='login_button']",
    "a[id='signin_button']",
    "a[id='signup_button']",
    "a[id='register_button']",
    "a[id='create_button']",
    "a[id='join_button']"
].join();

var LOGIN_URL_PATTERN = [
    "signin",
    "sign_in",
    "login",
    "log_in"
];

var SIGNUP_URL_PATTERN = [
    "signup",
    "sign_up",
    "register",
    "create",
    "github.com/join"
];
